# Ag64 segment checkpoint

Immutable per-step bundle for global step 1000->2000.
The scientific source identity is preserved as provenance; this bundle's execution code hash is recorded separately.
No EAM potential bytes are included.
