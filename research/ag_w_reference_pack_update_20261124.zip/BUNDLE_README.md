Ag–W reference-pack update bundle — 2026-11-24

This is an overlay/update bundle, not a standalone replacement for research/ag_w_reference_pack_complete_20261123.zip. Extract it into the repository root; files under ag_w_reference_pack/ overlay the existing repository paths. It contains updated literature/readiness notes, the full-size static-failure audit and artifacts, the archived Ag–W papers, canonical XTANT-3 Ag/W tables and source notices, data-audit scripts/reports, and the W electron–phonon Ce/G time-scale comparison (Lin, XTANT-3, and low-temperature Daraszewicz anchors retained as separate branches).

The archive preserves source model branches. The time-scale ratio Ce/G is a fixed-lattice estimate, not a complete coupled TTM solution. It does not run or authorize a 300 K MD or TTM trajectory. The QSGS candidate still fails the static-start audit. XTANT usage notices are stored beside the source data.
