Ag–W reference-pack update bundle — 2026-11-24

This is an overlay/update bundle, not a standalone replacement for research/ag_w_reference_pack_complete_20261123.zip. Extract it into the repository root; files under ag_w_reference_pack/ overlay the existing repository paths. It contains updated literature/readiness notes, the full-size static-failure audit and artifacts, the archived Ag–W papers, the canonical XTANT-3 Ag/W tables with both source notices, and data-audit scripts/reports.

The archive preserves source model branches. It does not run or authorize a 300 K MD or TTM trajectory. The QSGS candidate still fails the static-start audit. XTANT usage notices are stored beside the source data.
