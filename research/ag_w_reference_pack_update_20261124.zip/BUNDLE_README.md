Ag–W reference-pack update bundle — 2026-11-24

This is an overlay/update bundle, not a standalone replacement for research/ag_w_reference_pack_complete_20261123.zip. Extract it into the existing repository root; the files under ag_w_reference_pack/ will overlay their repository paths. It contains updated literature/readiness notes, current full-size static-failure audit and candidate artifacts, the archived Ag–W papers, XTANT-3 Ag/W data tables with source README/license, and data-audit scripts/reports.

The archive preserves distinct source datasets. It does not run or authorize a 300 K MD or TTM trajectory. The QSGS candidate still fails the static-start audit. XTANT source terms in its README are preserved with the tables.
