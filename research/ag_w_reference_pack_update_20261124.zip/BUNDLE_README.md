Ag–W reference-pack update bundle — 2026-11-24

This is an overlay/update bundle, not a standalone replacement for research/ag_w_reference_pack_complete_20261123.zip. Extract it into the repository root; paths under ag_w_reference_pack/ overlay the existing repository files. It includes updated literature/readiness notes, Ag/W TTM source data and notices, full-size geometry audit artifacts, and selected AgW_TTM_baseline_v1 with its digitization inputs, validation report, and reproduction scripts.

Baseline v1 uses Lin 2008 Ag/W Ce and G curves, Daraszewicz 2014's W ke(Te,Tl) closure, and the Ag-specific XTANT kappa_tot(Te) table. Its W low-temperature G0 comparison remains outside the reported experimental 1σ range; the curve was not rescaled. The single W 0D energy-ledger pilot is a temporal energy-accounting check, not a melt/quench run or a 3D Ag/W TTM validation. Ag/W interface conductance, a mixed-cell transport rule, Ag lattice conductivity, and the target pulse envelope/absorbed energy remain open.

The full-size QSGS candidate still fails the static-start gate. This bundle contains the audit record and does not convert that geometry into a validated MD/TTM initial state. XTANT source notices remain beside the supplied tables.
