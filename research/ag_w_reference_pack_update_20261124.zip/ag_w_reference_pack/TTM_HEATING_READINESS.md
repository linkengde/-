# Ag-W TTM heating readiness

## Requested geometry and heating method

The candidate model uses x/y periodic boundaries and a free z surface (`p p f`), with fixed atoms at 0–20 Å, a thermostat layer at 20–40 Å, a Newton layer at 40–200 Å, and empty sputter/evaporation monitor regions at 200–250 Å and 250–300 Å. Laser heating is to be done with TTM; no direct thermostat pulse is substituted.

## Why there is no TTM trajectory yet

The installed LAMMPS build contains TTM styles, but the existing project preflight for `fix ttm/mod` found that its boundary assumptions reject nonperiodic z. Changing z to periodic would make atoms that leave the free surface wrap through the vacuum to the bottom, so that stock fix cannot be used with this geometry as-is.

There is an Ag-only finite-volume TTM reference solver in `models/ag_ti3sic2_qsgs_1to1_finer/ag_ttm_reference.py`. It supports periodic x/y and zero-flux open z faces and has been coupled to short LAMMPS Python API pilots. It is a custom numerical prototype, not a compiled LAMMPS fix, and it does not provide W parameters or a validated Ag–W mixture closure. It is a possible implementation starting point; the Ag-only table from that separate project must not be presented as an Ag–W parameter set.

The spatial heat-source formula and candidate values were migrated into an independent Ag–W static preflight. Its 10 Å Ag mask was built from the original, overlapping type-2 atom coordinates; at `S(t)=1`, the mapped Newton-layer Ag power was 9,784.984 eV/ps. This is a geometry-specific on-state power, not a pulse energy, and is **stale for any future reconstructed coordinates**. Do not reuse this power or mask: recalculate after a candidate passes static structural acceptance. The historical report, JSON, and mask/source arrays are in `models/ag_w_qsgs_200A/ttm_source_preflight/`. The legacy Ag–Ti₃SiC₂ files were not changed.

Numerical Ag and W tables have now been supplied from XTANT-3 and archived with the source README and license in `ttm_data/xtant3_ag_w_source/`. This includes standalone `Ce(Te)` and `G(Te)` tables and `K(Te)` tables through 50,000 K. The methods differ: the `Ce` embedded in the K tables is from ideal crystals on a 7×7×7 k-point mesh, while the standalone `Ce` files are from dynamical simulations at the gamma point. At sampled common temperatures, the XTANT W `G` curve is 3.8–17.9 times lower than the Lin et al. digitized curve; retain both as alternatives. Duffy et al. supplies a separate W low-temperature anchor and Drude-style conductivity closure. These are candidate inputs, not a validated Ag–W mixture parameterization. See `ttm_data/XTANT3_AG_W_DATA_AUDIT_20261124.md` and its machine-readable table audit.

A directly validated nonequilibrium `ke(Te,Tl)` surface and a measured Ag/W electronic interface conductance remain absent. The XTANT K tables depend on `Te` only; the W Duffy closure is a model with independent `Te` and `Tl`, but is not validated at high nonequilibrium. The supplied G tables likewise have no lattice-temperature column. The Ag/W interfacial conductance paper supplied for comparison studies Au/Pt and Au/Al, not Ag/W. The exploratory spatial source profile is specified, but `S(t)` has no pulse width or temporal envelope, and no Ag–W-specific absorbed fluence is specified. These choices need to be explicit before a TTM pilot and its energy ledger can be interpreted.

Next parameter work: (1) choose source-consistent Ag/W `Ce` tables and define lower/upper temperature handling; (2) preserve XTANT, Lin, and Duffy W `G` as distinct sensitivity cases; (3) choose a documented `ke` closure and interface-transport assumption, with sensitivity runs; and (4) set the laser wavelength, pulse duration, fluence, spot size, and absorptance or label them as an exploratory scenario. The Ag/W phase and melt/quench references are now archived, but the 1988 phase diagram is calculated rather than experimentally measured. A focused outstanding-source checklist is in `TTM_LITERATURE_REQUEST.md`.

For those reasons, TTM is `NOT_RUN`. V3 local slabs are mechanically relaxed, but the v3 full-size exploratory candidate also failed the static-start gate: after 10,000 EFS minimization steps it retained high maximum force and developed collapsed contacts and atoms above the material surface. The original perfect-lattice assignment still has a 0.08 Å Ag–W distance and must not be integrated directly. Qualitative use of the potential is accepted for graduate-level exploration, but the 3D candidate must first be rebuilt and pass static geometry, density, and connectivity checks. TTM also needs a documented mixed-phase/interface closure, temperature-boundary rules, and pulse definition. See `models/ag_w_qsgs_200A/interface_reconstruction_v3/LOCAL_INTERFACE_V3_AUDIT.md` and its `qsgs_candidate/FULL_SIZE_STATIC_AUDIT.md`.

## TTM acceptance inputs

Before a small laser-heating pilot, record:

1. Literature-backed `Ce(Te)`, `ke(Te)`, and `G(Te)` for Ag and W, with units and temperature ranges.
2. A coupling implementation that supports `p p f`, the selected atomistic potential, the Ag/W type distinction, and a free surface. The existing Ag-only finite-volume solver can inform this implementation but does not meet the Ag–W requirements yet.
3. Temporal envelope `S(t)` or absorbed fluence/total deposited energy, pulse duration, confirmation that the candidate lateral radius/depth are appropriate for Ag–W, and whether the 20–40 Å layer is a heat sink during the pulse.
4. Energy-accounting checks for source deposition and equal-and-opposite electron-lattice transfer before any trajectory is interpreted.

No full-size 3D structure has passed static acceptance. The original and v1/v2 candidates have not been equilibrated at 300 K, heated, or used for production MD. V3's small local slabs were zero-temperature EFS minimizations only.
