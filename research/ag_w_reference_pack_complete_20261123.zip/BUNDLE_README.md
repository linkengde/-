# Ag–W research bundle

This archive contains the complete `research/ag_w_reference_pack/` directory from the Ag–W research branch, including source papers, the EFS potential, model geometries, scripts, and v1/v2/v3 validation records. The separate Ag–Ti3SiC2 project is not included.

The original 3D QSGS model and all v1/v2 repair candidates failed full-size static acceptance. V3 completed 360 zero-temperature relaxations of low-strain, one-interface Ag/W slabs. They passed the mechanical and atom-retention checks, but the strict DFT energy screen failed, especially for Ag(111)/W(110). The project accepts the potential for qualitative graduate-level exploration with these limitations stated. No full 3D QSGS candidate has passed static acceptance; do not run dynamics on the raw geometry. TTM/laser heating is not ready. The old Ag-only source power is specific to the raw overlapping coordinates and must be recalculated after a future accepted 3D model.

See `ag_w_reference_pack/models/ag_w_qsgs_200A/interface_reconstruction_v3/LOCAL_INTERFACE_V3_AUDIT.md` for the results and scope limits. `MANIFEST_SHA256.txt` lists checksums for every file under `ag_w_reference_pack/` and excludes itself.
