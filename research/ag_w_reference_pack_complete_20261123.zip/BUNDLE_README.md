# Ag–W research bundle

This archive contains the complete `research/ag_w_reference_pack/` directory from the Ag–W research branch, including source documents, potential files, model geometries, scripts, and validation reports. The separate Ag–Ti3SiC2 project is not included.

The Ag–W QSGS geometry is still under structural validation. The raw geometry is preserved, and the latest overlap-repair audit found no acceptable MD initial structure. No 300 K MD or TTM laser-heating run has been performed. See `ag_w_reference_pack/models/ag_w_qsgs_200A/overlap_repair_v1/OVERLAP_REPAIR_AUDIT.md`.

`MANIFEST_SHA256.txt` lists checksums for every file under `ag_w_reference_pack/` and excludes itself.
