# Ag–W research bundle

This archive contains the complete `research/ag_w_reference_pack/` directory from the Ag–W research branch. It includes source documents, potential files, model geometries, scripts, and validation reports. The separate legacy Ag–Ti3SiC2 project is not included.
