# Ag–W research bundle

This archive contains the complete `research/ag_w_reference_pack/` directory from the Ag–W research branch, including source papers, potential files, model geometries, scripts, validation reports, and the v1/v2 structure-repair audit records. The separate Ag–Ti3SiC2 project is not included.

The raw QSGS geometry is preserved, but no Ag–W candidate has passed static structural acceptance. The v2 audit rejected the screened and projected reconstructions and the EFS minimization candidate. Do not start 300 K MD, TTM, or laser heating. The old Ag-only source power is tied to the raw overlapping coordinates and must be recalculated after a future accepted reconstruction. See `ag_w_reference_pack/models/ag_w_qsgs_200A/interface_reconstruction_v2/RECONSTRUCTION_V2_AUDIT.md`.

`MANIFEST_SHA256.txt` lists checksums for every file under `ag_w_reference_pack/` and excludes itself.
