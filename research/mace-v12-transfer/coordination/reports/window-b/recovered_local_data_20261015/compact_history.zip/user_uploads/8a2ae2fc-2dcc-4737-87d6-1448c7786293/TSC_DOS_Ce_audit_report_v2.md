# Ti3SiC2 DOS → Ce(Te) 复核报告 v2

## 结论
上一版的高温趋势基本正确，但有两处需要纠正/降级表述：

1. **低温 300–1000 K 的 DOS-derived Ce 不够可靠。**
   原因不是费米积分公式错误，而是原图的 E_F=0 水平轴覆盖了费米能附近的 DOS 曲线。
   对 36 组合理的数字化处理做敏感性测试后，300 K 离散很大，1000 K 仍明显敏感；
   1500–2000 K 后敏感性快速下降，3000 K 以上数字化误差已经很小。

2. **论文文字声称 DOS 横轴为 per atom per eV，但 Fig.4 的数值尺度和电子数闭合更像 total-cell DOS。**
   直接对 PDF 内嵌源图积分得到 E_F 以下 47.331076 个态，
   与 12 原子/晶胞、2 formula units/晶胞所对应的 48 个价电子只差 -1.394%。
   因此本表使用“effective cell scale inferred from electron-count closure”，
   但不能再写成“论文明确给的是 per unit cell”。

## 本次改进
- 直接从 PDF 内嵌的原始 Fig.4 二值图数字化，不再使用页面截图裁剪图。
- raw occupied integral = 47.331076
- 归一化到 48 个电子的比例因子 = 1.014132867
- a = 3.068 Å, c = 17.645 Å, Vcell = 143.834479 Å^3
- 由晶胞参数反算密度 = 4518.83 kg/m^3，与 4530 kg/m^3 很接近。
- 实验低温锚点 gamma = 5.21 mJ mol^-1 K^-2，对应 gamma_V = 120.594149 J m^-3 K^-2。
- 从数字化 D(E_F) 邻域估计的 gamma ≈ 3.949 mJ mol^-1 K^-2；
  与实验 5.21 的差异说明 1999 DFT DOS 不应替代实验低温锚点。

## 关键温度
 Te_K  Ce_DFTDOS_J_m3_K  Ce_exp_Sommerfeld_J_m3_K    ratio  DeltaU_DFTDOS_eV_A3  DeltaU_exp_Sommerfeld_eV_A3
  300      3.040639e+04              3.617824e+04 0.840461             0.000000                     0.000000
 1000      9.258908e+04              1.205941e+05 0.767774             0.000271                     0.000342
 1500      1.424784e+05              1.808912e+05 0.787647             0.000634                     0.000813
 2000      2.149960e+05              2.411883e+05 0.891403             0.001185                     0.001472
 3000      4.385213e+05              3.617824e+05 1.212113             0.003174                     0.003353
 5000      1.060183e+06              6.029707e+05 1.758267             0.012410                     0.009375
10000      2.388923e+06              1.205941e+06 1.980961             0.068193                     0.037601
14280      2.905881e+06              1.722084e+06 1.687421             0.140032                     0.076710
20000      3.054254e+06              2.411883e+06 1.266336             0.247607                     0.150504

## 数字化不确定性
 Te_K  Ce_min_J_m3_K  Ce_median_J_m3_K  Ce_max_J_m3_K  digitization_spread_percent_of_median                                                                 interpretation
  300   2.735618e+04      3.101698e+04   5.563746e+04                              91.179960              LOW-T DIGITIZATION UNRELIABLE (EF horizontal axis obscures curve)
  500   4.476479e+04      4.976803e+04   7.905475e+04                              68.899575              LOW-T DIGITIZATION UNRELIABLE (EF horizontal axis obscures curve)
  750   6.655597e+04      7.171868e+04   9.783952e+04                              43.619815              LOW-T DIGITIZATION UNRELIABLE (EF horizontal axis obscures curve)
 1000   8.816477e+04      9.276447e+04   1.127538e+05                              26.506945              LOW-T DIGITIZATION UNRELIABLE (EF horizontal axis obscures curve)
 1500   1.390253e+05      1.424003e+05   1.525106e+05                               9.470006                                              moderate digitization uncertainty
 2000   2.124721e+05      2.145934e+05   2.220859e+05                               4.479991                                              moderate digitization uncertainty
 2500   3.128343e+05      3.141437e+05   3.229368e+05                               3.215895                                              moderate digitization uncertainty
 3000   4.371730e+05      4.383954e+05   4.487718e+05                               2.645739 digitization-stable; remaining uncertainty dominated by DFT/frozen-DOS physics
 5000   1.057144e+06      1.060417e+06   1.068568e+06                               1.077277 digitization-stable; remaining uncertainty dominated by DFT/frozen-DOS physics
10000   2.370252e+06      2.385027e+06   2.392074e+06                               0.914971 digitization-stable; remaining uncertainty dominated by DFT/frozen-DOS physics
14280   2.883040e+06      2.901532e+06   2.910305e+06                               0.939673 digitization-stable; remaining uncertainty dominated by DFT/frozen-DOS physics
20000   3.035992e+06      3.050055e+06   3.059299e+06                               0.764149 digitization-stable; remaining uncertainty dominated by DFT/frozen-DOS physics

## 使用建议
- <1500 K：不要把数字化 DOS 的 Ce 当作低温锚点；用实验 Sommerfeld gamma 校验。
- 1500–3000 K：可作过渡诊断，但保留数字化不确定性。
- >=3000 K 到约10000 K：数字化结果对提取方法较稳定，可作为 Stage55B2 的 DFT-DOS diagnostic。
- >10000 K：仅作为灵敏度延伸；有限能量窗口与 frozen ground-state DOS 假设的重要性增加。
- 该表仍不是 finite-temperature DFT 最终物性。
- 如果用于 Stage55B2，必须重新做逐 cell 等能量反演和总能量审计，不能直接覆盖 Stage55B1。
