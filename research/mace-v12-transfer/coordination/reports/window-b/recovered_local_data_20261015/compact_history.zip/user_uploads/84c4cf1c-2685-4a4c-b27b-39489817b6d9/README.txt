Ag-Ti3SiC2 TTM interface parameter package

Purpose:
- Store the current TTM material/interface parameter summary.
- Used for Ag-Ti3SiC2 contact melt pool simulations.

Important note:
The interface thermal conductance/resistance is an AMM/Debye approximation,
not a direct experimental measurement.

Main result:
G_int ≈ 5.9e9 W/(m^2 K)
R_int ≈ 1.7e-10 m^2 K/W
