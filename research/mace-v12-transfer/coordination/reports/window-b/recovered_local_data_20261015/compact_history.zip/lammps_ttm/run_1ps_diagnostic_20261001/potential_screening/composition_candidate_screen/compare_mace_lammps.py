from pathlib import Path
import csv
import json

import numpy as np
from ase.io import read


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "candidate_mace_interface_check.json"
if OUT.exists():
    raise SystemExit(f"Refusing to overwrite existing file: {OUT}")

atoms = read(ROOT / "composition_candidate_c_pair_R6.extxyz")
orig_ids = atoms.arrays["lammps_id"].astype(int)
expected = {}
with (ROOT / "mace_forces_R6.csv").open() as f:
    for row in csv.DictReader(f):
        expected[int(row["lammps_id"])] = np.array(
            [float(row[f"f{axis}_eV_A"]) for axis in "xyz"]
        )

lines = (ROOT / "mace_candidate_forces.dump").read_text().splitlines()
header = next(i for i, line in enumerate(lines) if line.startswith("ITEM: ATOMS"))
actual = {}
for line in lines[header + 1 :]:
    fields = line.split()
    if len(fields) == 8:
        actual[int(fields[0])] = np.array([float(value) for value in fields[5:8]])

if len(actual) != len(atoms) or len(expected) != len(atoms):
    raise SystemExit("Unexpected atom count in MACE/LAMMPS comparison")
delta = np.array([actual[i] - expected[int(orig_ids[i - 1])] for i in range(1, len(atoms) + 1)])
summary_rows = list(csv.DictReader((ROOT / "model_summary.csv").open()))
summary = next(row for row in summary_rows if row["model"] == "MACE" and row["radius_A"] == "6")
log = (ROOT / "candidate_mace_run0.log").read_text().splitlines()
thermo_i = next(i for i, line in enumerate(log) if "PotEng" in line and "c_maxforce" in line)
thermo = log[thermo_i + 1].split()

result = {
    "atoms": len(atoms),
    "lammps_energy_eV": float(thermo[2]),
    "ase_mace_energy_eV": float(summary["energy_eV"]),
    "energy_abs_error_eV": abs(float(thermo[2]) - float(summary["energy_eV"])),
    "lammps_fmax_eV_per_A": float(thermo[3]),
    "ase_mace_fmax_eV_per_A": float(summary["max_force_norm_eV_per_A"]),
    "force_component_rmse_eV_per_A": float(np.sqrt(np.mean(delta**2))),
    "force_vector_max_error_eV_per_A": float(np.linalg.norm(delta, axis=1).max()),
    "force_vector_rmse_eV_per_A": float(np.sqrt(np.mean(np.sum(delta**2, axis=1)))),
    "note": "LAMMPS run 0 uses a nonperiodic, zero-ghost local fragment and the serial compatibility shim; dump output has default six-significant-digit formatting.",
}
OUT.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
