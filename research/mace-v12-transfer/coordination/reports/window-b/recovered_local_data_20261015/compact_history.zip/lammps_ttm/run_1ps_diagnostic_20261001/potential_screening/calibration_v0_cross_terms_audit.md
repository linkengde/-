# calibration v0 交叉项局部力审计

## 核对到的来源

原始 [potential.interface_calibration_v0.inc](/workspace/.local/lammps-ttm/composition_locked_candidate_20260930/potential.interface_calibration_v0.inc) 把 Ag–Ti、Ag–Si、Ag–C 写成 Morse pair，并注明参数由“single-plane HCP surrogate”拟合 Ag(111)/Ti₃SiC₂(0001) 报告黏附目标。该候选目录没有附 surrogate 的 DFT 输入/输出、拟合残差或独立验证数据；因此能核实它是单平面代理拟合，但不能复现拟合或证明跨环境有效。

审计时该文件 SHA256 为 `34deced5e08174ba369290b87f5c3bfd2b284b272991adf302b2b0d28c12815f`。

| 交叉项 | D0 (eV) | α (Å⁻¹) | r0 (Å) | 截断 (Å) |
|---|---:|---:|---:|---:|
| Ag–Ti | 0.94814194 | 2.0 | 2.33708864 | 8.0 |
| Ag–Si | 0.93944948 | 2.0 | 2.40407837 | 8.0 |
| Ag–C | 1.35077230 | 2.0 | 2.15255924 | 8.0 |

仅看单个 Ag–C Morse pair 的解析分离力投影，在 2.0、2.2026、2.4 Å 分别约为 +5.23、−0.93、−2.57 eV/Å。它不是整个簇的总力；实际体系会把所有 Ag–骨架 pair 力与 TSCBOP/EAM 力叠加。

## 相同距离、不同 Ag–C 环境

对组成锁定候选的两个独立 6 Å 局部簇，在原始坐标上分别运行 GPAW/PBE 单点与 LAMMPS run 0。两个 Ag–C 距离几乎相同，约 2.2026 Å。力的正值表示 Ag 与 C 分离，负值表示相互靠近。

| 局部簇 | Ag–C 距离 (Å) | PBE 分离力 | v0 全势 | 只置零 Ag–C Morse | 全部交叉项置零 | Ag–C Morse 分量 | Ag–Ti/Si Morse 合计 |
|---|---:|---:|---:|---:|---:|---:|---:|
| primary | 2.202561 | −0.864 | −2.522 | −0.938 | −0.105 | −1.584 | −0.834 |
| secondary | 2.202603 | −1.197 | +0.858 | +2.535 | +1.783 | −1.677 | +0.751 |

“只置零 Ag–C Morse”和“全部交叉项置零”都是力分解对照，不能当作修正后的势。Ag–C/Ag–TiSi 两列是成组删项前后的力差，分别合计该元素对之间所有 pair 对中心 Ag–C 分离力投影的贡献，并非只算标记的最近邻 pair。逐原子力和完整 LAMMPS 日志在 `composition_candidate_screen/interface_contact_scan/lammps_cross_contact_component_audit_v2/`；PBE 力与日志在 `composition_candidate_screen/interface_contact_scan/pbe/Ag_C/` 和 `AgC_secondary/pbe/`。

结果显示，v0 在 primary 簇把吸引力放大约 1.66 eV/Å；在几乎相同距离的 secondary 簇则预测错误方向。固定 α、r0 和 Ag–Ti/Si 项、只缩放 Ag–C 的 D0 时，匹配这两个 PBE 投影分别要求 D0 比例约 −0.05 和 2.23；不存在一个非负 D0 比例能同时匹配。Ag–C Morse 分量本身在两簇相近，主要环境差异还来自 Ag–Ti/Si 与内部势背景。单平面拟合未覆盖这些环境变化，需要联合验证整套交叉项和其余势的基线误差。

## 状态

- Ag–C 是当前已发现的主要交叉势风险；Ag–Ti/Ag–Si 目前只在各一个最近接触点与 PBE 对照，证据不足以宣布验证通过。
- 两种 Ag–C 环境的 2.0/2.4 Å PBE 距离扫描已完成；v0 与 MACE 的逐点对照见[Ag–C 环境距离扫描报告](composition_candidate_screen/interface_contact_scan/agc_environment_distance_scan_report.md)。第二轮 MACE 微调把 primary 扫描加入训练，并将 secondary 全环境留出，目前训练中。
- calibration v0 参数、组成锁定候选坐标及 Ag 质量分数均未修改。零交叉项对照不是生产方案；没有在该候选上做 MD。
