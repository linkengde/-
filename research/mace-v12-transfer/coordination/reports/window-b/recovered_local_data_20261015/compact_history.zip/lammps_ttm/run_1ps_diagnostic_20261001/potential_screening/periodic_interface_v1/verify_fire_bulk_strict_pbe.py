#!/usr/bin/env python3
"""Higher-k-point PBE check of the low-grid FIRE-screened Ti3SiC2 geometry."""
from pathlib import Path
import json
import os

import gpaw_data
import numpy as np
from ase.io import read

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "bulk_pbe_strict_fire_1x4x2"
OUT.mkdir(exist_ok=False)
os.environ["GPAW_SETUP_PATH"] = str(gpaw_data.datapath())
from gpaw import GPAW  # noqa: E402
from gpaw.mixer import Mixer  # noqa: E402
from gpaw.occupations import FermiDirac  # noqa: E402

atoms = read(ROOT / "bulk_pbe_fire_1x2x1" / "Ti3SiC2_PBE_Fire_1x2x1.extxyz")
atoms.calc = GPAW(
    mode="lcao",
    basis="dzp",
    xc="PBE",
    kpts=(1, 4, 2),
    occupations=FermiDirac(0.1),
    mixer=Mixer(0.1, 5, 100),
    convergence={"energy": 1e-4, "density": 1e-4, "eigenstates": 1e-4},
    maxiter=120,
    txt=str(OUT / "gpaw_strict.log"),
)
energy = float(atoms.get_potential_energy())
forces = np.asarray(atoms.get_forces())
norms = np.linalg.norm(forces, axis=1)
log = (OUT / "gpaw_strict.log").read_text(errors="replace").lower()
converged = "converged in" in log and "failed to converge" not in log
np.savetxt(
    OUT / "forces.csv",
    np.column_stack((np.arange(1, len(atoms) + 1), forces)),
    delimiter=",",
    header="atom_index,fx_eV_A,fy_eV_A,fz_eV_A",
    comments="",
)
atoms.calc.write(OUT / "state.gpw")
summary = {
    "status": "CONVERGED" if converged else "NOT_CONVERGED",
    "atoms": len(atoms),
    "cell_A": atoms.cell.array.tolist(),
    "kpts": [1, 4, 2],
    "basis": "LCAO-DZP",
    "xc": "PBE",
    "scf_thresholds": "1e-4",
    "extrapolated_energy_eV": energy,
    "max_force_eV_A": float(norms.max()),
    "max_force_atom_index": int(norms.argmax() + 1),
    "max_force_element": atoms[int(norms.argmax())].symbol,
    "force_RMS_eV_A": float(np.sqrt(np.mean(forces * forces))),
    "note": "Frozen-geometry higher-k-point confirmation of a model-derived bulk motif; the source structure is not independently CIF-validated.",
}
(OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2), flush=True)
