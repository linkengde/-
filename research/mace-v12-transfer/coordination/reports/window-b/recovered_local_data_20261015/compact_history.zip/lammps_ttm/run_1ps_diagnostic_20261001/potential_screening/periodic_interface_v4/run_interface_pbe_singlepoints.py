#!/usr/bin/env python3
"""PBE plane-wave single points for the three periodic interface gap scans."""
from pathlib import Path
import json
import os

import gpaw_data
import numpy as np
from ase.io import read, write

ROOT = Path(__file__).resolve().parent
STRUCTURES = ROOT / "structures"
OUT = ROOT / "pbe_singlepoints_500eV"
OUT.mkdir(exist_ok=False)
os.environ["GPAW_SETUP_PATH"] = str(gpaw_data.datapath())
from gpaw import GPAW, PW  # noqa: E402
from gpaw.mixer import Mixer  # noqa: E402
from gpaw.occupations import FermiDirac  # noqa: E402

records = []
for gap in (2.3, 2.6, 2.9):
    tag = f"d{gap:.1f}"
    atoms = read(STRUCTURES / f"Ag_Ti3SiC2_periodic_{tag}.extxyz")
    calc = GPAW(
        mode=PW(500),
        xc="PBE",
        kpts=(1, 4, 2),
        occupations=FermiDirac(0.1),
        mixer=Mixer(0.1, 5, 100),
        convergence={"energy": 1e-5, "density": 1e-5, "eigenstates": 1e-5},
        maxiter=160,
        txt=str(OUT / f"gpaw_{tag}.log"),
    )
    atoms.calc = calc
    energy = float(atoms.get_potential_energy())
    forces = np.asarray(atoms.get_forces())
    stress = np.asarray(atoms.get_stress(voigt=False))
    fmag = np.linalg.norm(forces, axis=1)
    symbols = atoms.get_chemical_symbols()
    imax = int(np.argmax(fmag))
    cross_min = {}
    from ase.neighborlist import neighbor_list

    ii, jj, dd = neighbor_list("ijd", atoms, cutoff=4.5, self_interaction=False)
    for i, j, d in zip(ii, jj, dd):
        pair = tuple(sorted((symbols[i], symbols[j])))
        if pair in (("Ag", "C"), ("Ag", "Si"), ("Ag", "Ti")):
            key = "-".join(pair)
            cross_min[key] = min(cross_min.get(key, float("inf")), float(d))
    write(OUT / f"Ag_Ti3SiC2_PBE_{tag}.extxyz", atoms, format="extxyz")
    rec = {
        "gap_A": gap,
        "atoms": len(atoms),
        "composition": {s: symbols.count(s) for s in sorted(set(symbols))},
        "energy_eV_cell": energy,
        "energy_eV_atom": energy / len(atoms),
        "scf_converged": bool(calc.scf.converged),
        "fmax_eV_A": float(fmag.max()),
        "rms_force_eV_A": float(np.sqrt(np.mean(np.sum(forces**2, axis=1)))),
        "max_force_atom_index_1based": imax + 1,
        "max_force_element": symbols[imax],
        "max_force_position_A": atoms.positions[imax].tolist(),
        "max_force_vector_eV_A": forces[imax].tolist(),
        "stress_eV_A3": stress.tolist(),
        "stress_GPa": (stress * 160.21766208).tolist(),
        "minimum_Ag_substrate_distances_A": cross_min,
        "method": {"xc": "PBE", "basis": "plane wave", "cutoff_eV": 500, "kpts": [1, 4, 2], "scf_thresholds": "1e-5", "smearing_eV": 0.1},
        "limitations": [
            "single-point forces only; interface atoms not relaxed",
            "32-atom coherent screening cell, not production-composition locked",
            "Ag film is about 4.8% laterally strained relative to the five-point PBE EOS",
            "substrate motif reconstructed from supplied model and not independently CIF-validated",
            "only Ti-terminated contacts sampled; Ag-Si and Ag-C force environments remain untested",
        ],
    }
    records.append(rec)
    (OUT / "summary.json").write_text(json.dumps(records, indent=2) + "\n")
    print(json.dumps(rec), flush=True)

