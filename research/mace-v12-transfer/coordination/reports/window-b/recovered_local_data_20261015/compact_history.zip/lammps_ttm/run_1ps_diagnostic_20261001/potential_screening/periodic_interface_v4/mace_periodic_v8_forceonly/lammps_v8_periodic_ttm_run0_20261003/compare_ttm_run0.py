from pathlib import Path
import json
import re
import numpy as np
import torch
from ase.io import read
from mace.calculators import MACECalculator

HERE = Path(__file__).resolve().parent
V8 = HERE.parent
atoms = read(HERE / "cluster_periodic.extxyz")
torch.set_default_dtype(torch.float64)
model = torch.load(V8 / "models/Ag_Ti_Si_C_MACE_periodic_v8_forceonly.model", map_location="cpu", weights_only=False).double().eval()
atoms.calc = MACECalculator(models=[model], device="cpu", default_dtype="float64")
ase_e = float(atoms.get_potential_energy())
ase_f = np.asarray(atoms.get_forces())
lines = (HERE / "forces.dump").read_text().splitlines()
start = next(i for i, line in enumerate(lines) if line.startswith("ITEM: ATOMS")) + 1
lmp_f = np.zeros_like(ase_f)
for line in lines[start : start + len(atoms)]:
    v = line.split()
    if len(v) == 8:
        lmp_f[int(v[0]) - 1] = [float(x) for x in v[5:8]]
if len(lines) < start + len(atoms):
    raise RuntimeError("Incomplete LAMMPS force dump")
log = (HERE / "log.mace_v8_periodic_ttm_run0").read_text().splitlines()
ti = next(i for i, line in enumerate(log) if re.search(r"\bPotEng\b", line) and "c_maxforce" in line)
thermo = log[ti + 1].split()
lmp_e, lmp_fmax, ttm_e, ttm_exchange = map(float, thermo[2:6])
delta = lmp_f - ase_f
summary = {
    "model": str(V8 / "models/Ag_Ti_Si_C_MACE_periodic_v8_forceonly.model"),
    "boundary": "periodic p p p; serial single rank; 28 A cubic box",
    "atoms": len(atoms), "LAMMPS_step": 0,
    "LAMMPS_PE_eV": lmp_e, "ASE_PE_eV": ase_e,
    "energy_abs_error_eV": abs(lmp_e - ase_e),
    "LAMMPS_Fmax_eV_A": lmp_fmax,
    "force_component_max_abs_error_eV_A": float(np.abs(delta).max()),
    "force_component_RMSE_eV_A": float(np.sqrt(np.mean(delta**2))),
    "TTM_electronic_energy_reported": ttm_e,
    "TTM_net_transfer_reported": ttm_exchange,
    "note": "Static run 0 only, TTM gamma=0 uniform property grid at 300 K. Confirms style/model coexistence and ghost map in one serial rank; no MD, heating, MPI, or physical TTM validation."
}
(HERE / "lammps_ase_ttm_run0_check.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
