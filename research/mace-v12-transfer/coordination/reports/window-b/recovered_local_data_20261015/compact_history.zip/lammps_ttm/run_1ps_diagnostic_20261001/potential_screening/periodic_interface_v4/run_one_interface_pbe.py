#!/usr/bin/env python3
"""Run and summarize one periodic Ag/Ti3SiC2 PBE interface single point."""
from pathlib import Path
import json
import os
import re
import sys

import gpaw_data
import numpy as np
from ase.io import read, write
from ase.neighborlist import neighbor_list

ROOT = Path(__file__).resolve().parent
gap = float(sys.argv[1])
tag = f"d{gap:.1f}"
run_label = sys.argv[2] if len(sys.argv) > 2 else "run1"
structure_set = sys.argv[3] if len(sys.argv) > 3 else "structures"
STRUCTURES = ROOT / structure_set
structure_stem = sys.argv[4] if len(sys.argv) > 4 else "Ag_Ti3SiC2_periodic"
out = ROOT / f"pbe_singlepoint_{tag}_500eV_{run_label}"
out.mkdir(exist_ok=False)
os.environ["GPAW_SETUP_PATH"] = str(gpaw_data.datapath())
from gpaw import GPAW, PW  # noqa: E402
from gpaw.mixer import Mixer  # noqa: E402
from gpaw.occupations import FermiDirac  # noqa: E402

atoms = read(STRUCTURES / f"{structure_stem}_{tag}.extxyz")
geometry_metadata = json.loads((STRUCTURES / f"{structure_stem}_{tag}.json").read_text())
log_path = out / "gpaw.log"
atoms.calc = GPAW(
    mode=PW(500),
    xc="PBE",
    kpts=(1, 4, 2),
    occupations=FermiDirac(0.1),
    mixer=Mixer(0.1, 5, 100),
    convergence={"energy": 1e-5, "density": 1e-5, "eigenstates": 1e-5},
    maxiter=160,
    txt=str(log_path),
)
energy = float(atoms.get_potential_energy())
forces = np.asarray(atoms.get_forces())
stress = np.asarray(atoms.get_stress(voigt=False))
force_mag = np.linalg.norm(forces, axis=1)
symbols = atoms.get_chemical_symbols()
imax = int(np.argmax(force_mag))
ii, jj, dd = neighbor_list("ijd", atoms, cutoff=4.5, self_interaction=False)
cross_min = {}
for i, j, dist in zip(ii, jj, dd):
    if i >= j:
        continue
    pair = tuple(sorted((symbols[i], symbols[j])))
    if pair in (("Ag", "C"), ("Ag", "Si"), ("Ag", "Ti")):
        key = "-".join(pair)
        cross_min[key] = min(cross_min.get(key, float("inf")), float(dist))

structure_path = out / f"Ag_Ti3SiC2_PBE_{tag}.extxyz"
write(structure_path, atoms, format="extxyz")
log_text = log_path.read_text(errors="replace")
scf_steps = re.findall(r"Converged in (\d+) steps", log_text)
summary = {
    "gap_A": gap,
    "nominal_top_gap_A": geometry_metadata["nominal_top_gap_A"],
    "nominal_bottom_gap_A": geometry_metadata["nominal_bottom_gap_A"],
    "atoms": len(atoms),
    "composition": {s: symbols.count(s) for s in sorted(set(symbols))},
    "energy_eV_cell": energy,
    "energy_eV_atom": energy / len(atoms),
    "scf_converged": bool(scf_steps),
    "scf_steps": int(scf_steps[-1]) if scf_steps else None,
    "fmax_eV_A": float(force_mag.max()),
    "rms_force_eV_A": float(np.sqrt(np.mean(force_mag**2))),
    "force_magnitude_quantiles_eV_A": {
        str(q): float(v)
        for q, v in zip((0, 0.25, 0.5, 0.75, 0.9, 0.95, 0.99, 1), np.quantile(force_mag, (0, 0.25, 0.5, 0.75, 0.9, 0.95, 0.99, 1)))
    },
    "max_force_atom_1based": imax + 1,
    "max_force_element": symbols[imax],
    "max_force_position_A": atoms.positions[imax].tolist(),
    "max_force_vector_eV_A": forces[imax].tolist(),
    "stress_eV_A3": stress.tolist(),
    "stress_GPa": (stress * 160.21766208).tolist(),
    "minimum_Ag_substrate_distances_A": cross_min,
    "method": {
        "xc": "PBE",
        "basis": "plane wave",
        "cutoff_eV": 500,
        "kpts": [1, 4, 2],
        "scf_thresholds": "1e-5",
        "smearing_eV": 0.1,
    },
    "evidence": {"log": str(log_path), "structure_forces": str(structure_path)},
    "limitations": [
        "single-point forces only; interface atoms not relaxed",
        "32-atom coherent screening cell, not production-composition locked",
        "Ag film is about 4.8% laterally strained relative to the five-point PBE EOS",
        "substrate motif reconstructed from supplied model and not independently CIF-validated",
        "only Ti-terminated contacts sampled; Ag-Si and Ag-C force environments remain untested",
        "the PBE EOS has not been cutoff/k-point convergence tested",
    ],
}
(out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2), flush=True)
if not summary["scf_converged"]:
    raise SystemExit("SCF did not converge; do not use this structure as a fitting label")
