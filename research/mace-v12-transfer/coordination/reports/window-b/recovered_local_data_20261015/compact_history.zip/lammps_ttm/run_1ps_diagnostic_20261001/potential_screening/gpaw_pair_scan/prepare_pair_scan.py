from pathlib import Path

import numpy as np
from ase.io import read, write


ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
SOURCE = ROOT / "c_pair_step0_R6.extxyz"
ID_A, ID_B = 520183, 520177

for target in (1.8, 1.5):
    name = f"pair_d{target:.1f}".replace(".", "p")
    destination = OUT / f"{name}_R6.extxyz"
    if destination.exists():
        raise SystemExit(f"Refusing to overwrite existing file: {destination}")
    atoms = read(SOURCE)
    ids = atoms.arrays["lammps_id"].astype(int)
    ia, ib = (int(np.flatnonzero(ids == atom_id)[0]) for atom_id in (ID_A, ID_B))
    vector = atoms.positions[ib] - atoms.positions[ia]
    distance = float(np.linalg.norm(vector))
    unit = vector / distance
    half_shift = 0.5 * (distance - target) * unit
    atoms.positions[ia] += half_shift
    atoms.positions[ib] -= half_shift
    write(destination, atoms, format="extxyz")
    print(f"{destination.name}: {distance:.6f} -> {target:.6f} Angstrom")
