#!/usr/bin/env python3
"""Converged periodic PBE static check for the reconstructed Ti3SiC2 bulk cell."""
from pathlib import Path
import csv
import json
import os
import numpy as np
import gpaw_data
from ase.io import read
os.environ["GPAW_SETUP_PATH"] = str(gpaw_data.datapath())
from gpaw import GPAW
from gpaw.mixer import Mixer
from gpaw.occupations import FermiDirac

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "bulk_reference"
OUT.mkdir(exist_ok=False)
atoms = read(ROOT / "structures/Ti3SiC2_bulk_orthorhombic.extxyz")
atoms.calc = GPAW(
    mode="lcao", basis="dzp", xc="PBE", kpts=(1, 4, 2),
    occupations=FermiDirac(0.1), mixer=Mixer(0.1, 5, 100),
    convergence={"energy": 1e-4, "density": 1e-4, "eigenstates": 1e-4},
    maxiter=120, txt=str(OUT / "gpaw.log"),
)
energy = float(atoms.get_potential_energy())
forces = np.asarray(atoms.get_forces())
log = (OUT / "gpaw.log").read_text(errors="replace").lower()
if "converged" not in log or "failed to converge" in log:
    raise RuntimeError("Periodic bulk PBE convergence not confirmed")
np.savetxt(OUT / "forces.csv", np.column_stack((np.arange(1, len(atoms)+1), forces)),
           delimiter=",", header="index,fx_eV_A,fy_eV_A,fz_eV_A", comments="")
atoms.calc.write(OUT / "state.gpw")
summary = {
    "status": "periodic_pbe_static_converged",
    "atoms": len(atoms),
    "formula": "Ti3SiC2 x 2",
    "cell_A": atoms.cell.array.tolist(),
    "kpts": [1, 4, 2],
    "energy_eV": energy,
    "energy_eV_atom": energy / len(atoms),
    "force_RMS_eV_A": float(np.sqrt(np.mean(forces**2))),
    "max_force_eV_A": float(np.linalg.norm(forces, axis=1).max()),
    "max_force_atom_index": int(np.linalg.norm(forces, axis=1).argmax()+1),
    "note": "Fixed-cell static PBE; basis and positions reconstructed from the repeated fixed-layer motif. Not a bulk relaxation or literature-validated structure."
}
(OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2), flush=True)
