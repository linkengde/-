#!/usr/bin/env python3
"""Plane-wave PBE stress check for the high-grid relaxed substrate geometry."""
from pathlib import Path
import json
import os

import gpaw_data
import numpy as np
from ase.io import read

ROOT = Path(__file__).resolve().parent
RELAX = ROOT / "bulk_pbe_fire_1x4x2_relax"
OUT = RELAX / "stress_check_pw"
OUT.mkdir(exist_ok=False)
os.environ["GPAW_SETUP_PATH"] = str(gpaw_data.datapath())
from gpaw import GPAW, PW  # noqa: E402
from gpaw.mixer import Mixer  # noqa: E402
from gpaw.occupations import FermiDirac  # noqa: E402

atoms = read(RELAX / "Ti3SiC2_PBE_Fire_1x4x2.extxyz")
atoms.calc = GPAW(
    mode=PW(500),
    xc="PBE",
    kpts=(1, 4, 2),
    occupations=FermiDirac(0.1),
    mixer=Mixer(0.1, 5, 100),
    convergence={"energy": 1e-4, "density": 1e-4, "eigenstates": 1e-4},
    maxiter=120,
    txt=str(OUT / "gpaw_stress_pw.log"),
)
energy = float(atoms.get_potential_energy())
forces = np.asarray(atoms.get_forces())
stress = np.asarray(atoms.get_stress(voigt=False))
log = (OUT / "gpaw_stress_pw.log").read_text(errors="replace").lower()
summary = {
    "status": "SCF_CONVERGED" if "converged in" in log and "failed to converge" not in log else "SCF_NOT_CONFIRMED",
    "atoms": len(atoms),
    "cell_A": atoms.cell.array.tolist(),
    "kpts": [1, 4, 2],
    "xc": "PBE",
    "basis": "plane wave",
    "cutoff_eV": 500,
    "stress_tensor_eV_A3": stress.tolist(),
    "stress_trace_mean_eV_A3": float(np.trace(stress) / 3),
    "stress_trace_mean_GPa": float(np.trace(stress) / 3 * 160.21766208),
    "energy_eV": energy,
    "max_force_eV_A": float(np.linalg.norm(forces, axis=1).max()),
    "note": "Static plane-wave PBE stress check of geometry relaxed with LCAO-DZP; a stress value is not an independent validation of the model-derived crystal structure.",
}
(OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2), flush=True)
