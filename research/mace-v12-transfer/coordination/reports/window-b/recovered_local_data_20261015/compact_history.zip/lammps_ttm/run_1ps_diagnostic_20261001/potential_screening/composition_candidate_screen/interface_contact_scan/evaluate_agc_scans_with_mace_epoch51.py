#!/usr/bin/env python3
"""Compare PBE Ag-C scan points to pretrained and epoch-51 fine-tuned MACE."""
from pathlib import Path
import csv
import json

import numpy as np
import torch
from ase.io import read
from mace.calculators import MACECalculator

ROOT = Path(__file__).resolve().parent
SCAN = ROOT / "AgC_environment_distance_scans_PBE_v1"
PILOT = ROOT.parent / "mace_finetune_pilot"
BASE_MODEL = Path("/workspace/.local/cache/mace/mace-mp-0b3-medium.model")
FINE_MODEL = PILOT / "checkpoints_export_epoch51/Ag_Ti_Si_C_MACE_finetune_pilot_run-42.model"
OUT = SCAN / "mace_model_comparison_epoch51_full.csv"
if OUT.exists():
    raise FileExistsError(OUT)

torch.set_default_dtype(torch.float64)
baseline = torch.load(BASE_MODEL, map_location="cpu", weights_only=False).double().eval()
fine = torch.load(FINE_MODEL, map_location="cpu", weights_only=False).double().eval()
calculators = {
    "mace_mp0b3": MACECalculator(models=[baseline], device="cpu", default_dtype="float64"),
    "mace_finetuned_epoch51": MACECalculator(models=[fine], device="cpu", default_dtype="float64"),
}
pair_ids = {"primary": (732149, 197404), "secondary": (688433, 604804)}
rows = []

for env, (ag_id, c_id) in pair_ids.items():
    contact_dir = ROOT / ("AgC_secondary/pbe" if env == "secondary" else "pbe/Ag_C")
    contact_xyz = ROOT / ("AgC_secondary/candidate_Ag_C_R6.extxyz" if env == "secondary" else "candidate_Ag_C_R6.extxyz")
    items = [("d2.2_contact", contact_xyz, contact_dir / "summary.json", contact_dir / "forces.csv")]
    items += [(f"d{distance:.1f}", SCAN / env / f"d{distance:.1f}/input.extxyz",
               SCAN / env / f"d{distance:.1f}/summary.json", SCAN / env / f"d{distance:.1f}/forces.csv")
              for distance in (2.0, 2.4)]
    for tag, xyz_path, summary_path, forces_path in items:
        atoms = read(xyz_path)
        summary = json.loads(summary_path.read_text())
        pbe_by_id = {}
        with forces_path.open() as f:
            for row in csv.DictReader(f):
                pbe_by_id[int(row["lammps_id"])] = np.array([float(row["fx_eV_A"]), float(row["fy_eV_A"]), float(row["fz_eV_A"])])
        ids = np.asarray(atoms.arrays["lammps_id"], dtype=int)
        ref_f = np.asarray([pbe_by_id[int(i)] for i in ids])
        ia, ic = int(np.flatnonzero(ids == ag_id)[0]), int(np.flatnonzero(ids == c_id)[0])
        u = atoms.positions[ia] - atoms.positions[ic]
        u /= np.linalg.norm(u)
        ref_pair_force = float(np.dot(ref_f[ia] - ref_f[ic], u))
        distance_value = summary.get("calculated_distance_A", summary.get("distance_A"))
        pbe_pair_force = summary.get("Ag_C_separating_force_eV_A", summary.get("PBE_pair_separating_force_eV_per_A"))
        row = {"environment": env, "point": tag, "distance_A": float(distance_value),
               "PBE_energy_eV": float(summary["PBE_energy_eV"]),
               "PBE_pair_separating_force_eV_A": ref_pair_force if pbe_pair_force is None else float(pbe_pair_force),
               "PBE_force_RMS_eV_A": float(np.sqrt(np.mean(ref_f ** 2)))}
        for name, calc in calculators.items():
            trial = atoms.copy()
            trial.calc = calc
            energy = float(trial.get_potential_energy())
            force = np.asarray(trial.get_forces())
            row[f"{name}_force_RMSE_eV_A"] = float(np.sqrt(np.mean((force - ref_f) ** 2)))
            row[f"{name}_energy_error_eV_atom"] = (energy - row["PBE_energy_eV"]) / len(atoms)
            row[f"{name}_pair_separating_force_eV_A"] = float(np.dot(force[ia] - force[ic], u))
        rows.append(row)

with OUT.open("w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=rows[0].keys())
    w.writeheader()
    w.writerows(rows)
print(json.dumps(rows, indent=2))
