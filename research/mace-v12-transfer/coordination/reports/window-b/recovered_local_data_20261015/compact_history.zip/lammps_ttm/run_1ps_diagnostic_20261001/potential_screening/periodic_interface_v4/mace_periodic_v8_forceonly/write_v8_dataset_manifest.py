#!/usr/bin/env python3
from pathlib import Path
import csv,hashlib,json
from ase.io import read
ROOT=Path(__file__).resolve().parent; PROJECT=ROOT.parent
PREV=PROJECT/'mace_periodic_v7_forceonly/data'
SCAN=PROJECT.parent/'composition_candidate_screen/interface_contact_scan/AgTi_AgSi_environment_distance_scans_PBE_v1'
DATA=ROOT/'data'; DEST=DATA/'dataset_manifest.json'
if DEST.exists(): raise SystemExit(f'Refusing to overwrite {DEST}')
train=read(DATA/'train.extxyz',index=':');valid=read(DATA/'valid.extxyz',index=':');test=read(DATA/'test.extxyz',index=':')
if (len(train),len(valid),len(test))!=(17,2,2): raise SystemExit('Unexpected saved v8 frame counts')
if sum('REF_energy' in a.info for a in train)!=9 or sum('REF_forces' in a.arrays for a in train)!=17: raise SystemExit('Label count mismatch')
added=[]
for env,distances in [('AgSi',('2.2','2.8')),('AgTi',('2.1','2.7'))]:
 for tag in distances:
  folder=SCAN/env/f'd{tag}'; summary=json.loads((folder/'summary.json').read_text())
  force_rows=list(csv.DictReader((folder/'forces.csv').open()))
  added.append({'config_type':f'{env}_{tag.replace(".","p")}A_LCAO','target_distance_A':float(summary['target_distance_A']),
    'contact':'Si' if env=='AgSi' else 'Ti','PBE_energy_eV_excluded':float(summary['PBE_energy_eV']),
    'atom_force_rows':len(force_rows),'source_input':str(folder/'input.extxyz'),'source_forces':str(folder/'forces.csv'),'source_summary':str(folder/'summary.json')})
if len(added)!=4: raise SystemExit('Expected four AgSi/AgTi force frames')
heldout=PROJECT/'pbe_cluster_transfer_pw_20261002_run3_mixer_retry2/AgC_cluster_PW_PBE.extxyz'
manifest={'purpose':'MACE v8 interface force screening; PW energies and supplementary local-cluster forces.',
 'parent_forceonly_dataset':str(PREV),'added_force_only_frames':added,
 'final_counts':{'train':len(train),'valid':len(valid),'test':len(test)},
 'train_label_audit':{'frames_with_energy':9,'frames_with_forces':17,'energy_labels':'9 periodic PW-PBE configurations only','LCAO energy labels':'excluded'},
 'unseen_contact_checks':{'AgSi_nearest_distance_A':2.454117131713038,'AgTi_nearest_distance_A':2.3870911918314524,'source':'existing GPAW PBE/LCAO labels, excluded from the v8 scan endpoints'},
 'external_PW_holdout':str(heldout),'caveats':['All eight Ag-C/Ag-Si/Ag-Ti supplemental LCAO scan frames contribute forces only.',
 'AgSi/AgTi nearest-contact tests are midpoint/interpolation checks within the scanned motifs.',
 'No liquid Ag, thermal disorder, production-size periodic interfaces, or TTM labels are included.'],'sha256':{}}
inputs=[PREV/'train.extxyz',PREV/'valid.extxyz',PREV/'test.extxyz',heldout]+[Path(x[k]) for x in added for k in ('source_input','source_forces','source_summary')]
for p in inputs:manifest['sha256'][str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
DEST.write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'manifest':str(DEST),'counts':manifest['final_counts'],'sha256_entries':len(manifest['sha256'])},indent=2))
