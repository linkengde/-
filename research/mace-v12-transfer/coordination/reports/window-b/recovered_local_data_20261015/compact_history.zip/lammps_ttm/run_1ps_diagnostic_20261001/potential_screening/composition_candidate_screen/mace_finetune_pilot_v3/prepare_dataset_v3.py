#!/usr/bin/env python3
"""Construct an expanded, still local-cluster-only DFT fine-tuning data split."""
from pathlib import Path
import json
from ase.io import read, write

ROOT = Path(__file__).resolve().parent
V2 = ROOT.parent / "mace_finetune_pilot_v2/data"
OUT = ROOT / "data"
OUT.mkdir(parents=True, exist_ok=True)

train = read(V2 / "train.extxyz", index=":")
valid = read(V2 / "valid.extxyz", index=":")
test = read(V2 / "test.extxyz", index=":")
selected = {"original_ag_layout_step0", "original_ag_layout_cc_d1p8",
            "AgC_secondary_d2.0_PBE", "AgC_secondary_d2.4_PBE"}
train_added, test_kept = [], []
for atoms in test:
    name = atoms.info.get("config_type", "")
    if name in selected:
        train_added.append(atoms)
    else:
        test_kept.append(atoms)
found = {a.info.get("config_type", "") for a in train_added}
if found != selected:
    raise RuntimeError(f"Expected selected test configurations {selected}, found {found}")

all_train = train + train_added
write(OUT / "train.extxyz", all_train, format="extxyz")
write(OUT / "valid.extxyz", valid, format="extxyz")
write(OUT / "test.extxyz", test_kept, format="extxyz")
manifest = {
    "purpose": "Expanded MACE calibration pilot using local nonperiodic PBE clusters; not a production potential dataset.",
    "training_additions_from_v2_test": sorted(selected),
    "train": [a.info.get("config_type", "unknown") for a in all_train],
    "valid": [a.info.get("config_type", "unknown") for a in valid],
    "test": [a.info.get("config_type", "unknown") for a in test_kept],
    "split_note": "Secondary Ag-C distance scan points and one target-layout frame are training; secondary d2.2 target contact and step1000 remain held out. This is not independent periodic-interface validation.",
    "counts": {"train": len(all_train), "valid": len(valid), "test": len(test_kept)},
}
(OUT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps(manifest["counts"], indent=2))
