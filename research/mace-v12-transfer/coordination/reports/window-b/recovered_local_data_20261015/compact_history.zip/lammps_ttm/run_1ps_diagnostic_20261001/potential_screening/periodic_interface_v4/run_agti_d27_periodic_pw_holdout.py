#!/usr/bin/env python3
"""Method-matched periodic PW-PBE check at the Ag-Ti 2.7 Å scan endpoint."""
from pathlib import Path
import hashlib
import json
import os
import time

import numpy as np
from ase.io import read, write

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "composition_candidate_screen/interface_contact_scan/AgTi_AgSi_environment_distance_scans_PBE_v1/AgTi/d2.7/input.extxyz"
OUT = ROOT / "pbe_external_v9_holdouts/AgTi_d2p7/retry1"
OUT.mkdir(parents=True, exist_ok=False)
os.environ["GPAW_SETUP_PATH"] = str(__import__("gpaw_data").datapath())
from gpaw import GPAW, PW
from gpaw.mixer import Mixer
from gpaw.occupations import FermiDirac

atoms = read(SOURCE)
atoms.pbc = True
ids = np.asarray(atoms.arrays["lammps_id"], dtype=int)
central = np.asarray(atoms.arrays["central_pair"], dtype=bool)
symbols = np.asarray(atoms.get_chemical_symbols())
ag_idx = int(np.flatnonzero(central & (symbols == "Ag"))[0])
ti_idx = int(np.flatnonzero(central & (symbols == "Ti"))[0])
vec = atoms.positions[ti_idx] - atoms.positions[ag_idx]
distance = float(np.linalg.norm(vec))
if len(atoms) != 49 or abs(distance - 2.7) > 1e-5:
    raise SystemExit(f"Unexpected structure: n={len(atoms)} Ag-Ti={distance}")
write(OUT / "input.extxyz", atoms, format="extxyz")
started = time.time()

calc = GPAW(
    mode=PW(500),
    xc="PBE",
    kpts=(1, 1, 1),
    occupations=FermiDirac(0.1),
    mixer=Mixer(0.05, 8, 100),
    convergence={"energy": 1e-5, "density": 1e-5, "eigenstates": 1e-5},
    maxiter=160,
    txt=str(OUT / "gpaw.log"),
)
atoms.calc = calc


def checkpoint(ctx):
    niter = int(ctx.niter)
    if niter == 30:
        calc.write(str(OUT / "checkpoint_iter030.gpw"), mode="all")
    if niter % 5 == 0:
        (OUT / "progress.json").write_text(json.dumps({
            "contact": "AgTi_d2p7", "iteration": niter,
            "elapsed_s": time.time() - started,
        }, indent=2) + "\n")


calc.hooks["scf_step"] = checkpoint
energy = float(atoms.get_potential_energy())
forces = np.asarray(atoms.get_forces())
norms = np.linalg.norm(forces, axis=1)
write(OUT / "AgTi_d2p7_cluster_PW_PBE.extxyz", atoms, format="extxyz")
summary = {
    "source": str(SOURCE),
    "source_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    "contact": "AgTi_d2p7",
    "atoms": len(atoms),
    "formula": atoms.get_chemical_formula(),
    "pbc": atoms.pbc.tolist(),
    "cell_A": atoms.cell.lengths().tolist(),
    "central_pair_ids": {"Ag": int(ids[ag_idx]), "Ti": int(ids[ti_idx])},
    "central_pair_distance_A": distance,
    "energy_eV_cell": energy,
    "scf_converged": bool(calc.scf.converged),
    "scf_iterations": int(calc.scf.niter),
    "central_pair_separating_force_eV_A": float(np.dot(forces[ti_idx] - forces[ag_idx], vec / distance)),
    "fmax_eV_A": float(norms.max()),
    "rms_force_eV_A": float(np.sqrt(np.mean(norms**2))),
    "max_force_source_id": int(ids[int(norms.argmax())]),
    "method": {
        "xc": "PBE", "basis": "plane wave", "cutoff_eV": 500,
        "kpts": [1, 1, 1], "smearing_eV": 0.1,
        "scf_thresholds": "energy/density/eigenstates 1e-5",
        "mixer": "Pulay beta=0.05, nmaxold=8, weight=100",
        "maxiter": 160, "GPAW_version": __import__("gpaw").__version__,
    },
    "elapsed_s": time.time() - started,
    "note": "Periodic PW-PBE single point on the existing Ag-Ti 2.7 Å scan geometry. The geometry is an LCAO training point, so this specifically tests PW-vs-LCAO method transfer; it is not a novel coordination motif.",
}
# Write the compact result before the large state file so a runtime limit cannot
# discard a completed force calculation while the final restart is being saved.
(OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2), flush=True)
calc.write(str(OUT / "state.gpw"), mode="all")
