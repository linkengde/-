#!/usr/bin/env bash
set -u

d26_pid="${1:?pass the active d=2.6 Python PID}"
root="/workspace/.local/lammps-ttm/run_1ps_diagnostic_20261001/potential_screening/periodic_interface_v4"
summary="$root/pbe_singlepoint_d2.6_500eV_run2/summary.json"
status_log="$root/d2.9_serial_launcher.log"
python="/workspace/.local/venvs/gpaw/bin/python"

while kill -0 "$d26_pid" 2>/dev/null; do
  sleep 20
done

if [[ ! -s "$summary" ]]; then
  echo "STOP: d=2.6 process ended without summary.json; d=2.9 was not launched." >> "$status_log"
  exit 1
fi

if ! "$python" -c 'import json,sys; sys.exit(0 if json.load(open(sys.argv[1]))["scf_converged"] else 1)' "$summary"; then
  echo "STOP: d=2.6 SCF did not converge; d=2.9 was not launched." >> "$status_log"
  exit 1
fi

echo "d=2.6 converged; launching d=2.9 with the same PBE settings." >> "$status_log"
"$python" -u "$root/run_one_interface_pbe.py" 2.9 run1 > /tmp/pbe_d2.9_run1.stdout 2>&1
status=$?
cp /tmp/pbe_d2.9_run1.stdout "$root/pbe_singlepoint_d2.9_500eV_run1/run.stdout" 2>/dev/null || true
echo "d=2.9 completed with exit status $status." >> "$status_log"
exit "$status"
