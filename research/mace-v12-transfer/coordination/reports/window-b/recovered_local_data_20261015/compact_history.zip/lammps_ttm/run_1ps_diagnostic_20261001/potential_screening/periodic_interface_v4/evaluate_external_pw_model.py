#!/usr/bin/env python3
"""Score a MACE model against a converged external periodic PW-PBE frame."""
from pathlib import Path
import argparse
import json

import numpy as np
import torch
from ase.io import read
from mace.calculators import MACECalculator

parser = argparse.ArgumentParser()
parser.add_argument("--contact", required=True)
parser.add_argument("--out", required=True, type=Path)
parser.add_argument("--model", required=True, type=Path)
args = parser.parse_args()
if args.contact not in {"AgTi_d2p7"}:
    raise SystemExit("unsupported contact label")
out = args.out
summary = json.loads((out / "summary.json").read_text())
if summary.get("scf_converged") is not True:
    raise SystemExit("Refusing to score non-converged DFT forces")
label = read(out / "AgTi_d2p7_cluster_PW_PBE.extxyz")
label.pbc = True
ref_energy = float(label.get_potential_energy())
ref_forces = np.asarray(label.get_forces())
ids = np.asarray(label.arrays["lammps_id"], dtype=int)
symbols = np.asarray(label.get_chemical_symbols())
central = np.asarray(label.arrays["central_pair"], dtype=bool)
ag_idx = int(np.flatnonzero(central & (symbols == "Ag"))[0])
ti_idx = int(np.flatnonzero(central & (symbols == "Ti"))[0])
vec = label.positions[ti_idx] - label.positions[ag_idx]
distance = float(np.linalg.norm(vec))
unit = vec / distance
ref_pair = float(np.dot(ref_forces[ti_idx] - ref_forces[ag_idx], unit))

torch.set_default_dtype(torch.float64)
model = torch.load(args.model, map_location="cpu", weights_only=False).double().eval()
label.calc = MACECalculator(models=[model], device="cpu", default_dtype="float64")
model_energy = float(label.get_potential_energy())
model_forces = np.asarray(label.get_forces())
delta = model_forces - ref_forces
vector_errors = np.linalg.norm(delta, axis=1)
model_pair = float(np.dot(model_forces[ti_idx] - model_forces[ag_idx], unit))
hotspots = []
for idx in np.argsort(vector_errors)[::-1][:8]:
    hotspots.append({
        "id": int(ids[idx]), "element": str(symbols[idx]),
        "position_A": label.positions[idx].tolist(),
        "reference_force_eV_A": ref_forces[idx].tolist(),
        "model_force_eV_A": model_forces[idx].tolist(),
        "vector_error_eV_A": float(vector_errors[idx]),
    })
result = {
    "contact": args.contact,
    "scf_converged": True,
    "scf_iterations": int(summary["scf_iterations"]),
    "reference_method": "periodic PBE plane-wave, 500 eV, Gamma, 0.1 eV Fermi smearing",
    "atoms": len(label), "formula": label.get_chemical_formula(),
    "central_pair_ids": {"Ag": int(ids[ag_idx]), "Ti": int(ids[ti_idx])},
    "central_pair_distance_A": distance,
    "full_force_component_RMSE_eV_A": float(np.sqrt(np.mean(delta**2))),
    "full_force_vector_max_abs_error_eV_A": float(vector_errors.max()),
    "reference_pair_separating_force_eV_A": ref_pair,
    "model_pair_separating_force_eV_A": model_pair,
    "pair_force_error_eV_A": model_pair - ref_pair,
    "absolute_energy_error_meV_atom": (model_energy - ref_energy) * 1000.0 / len(label),
    "max_force_error_hotspots": hotspots,
    "model": str(args.model),
    "note": "Method-transfer check at a PW-labeled geometry also present in the LCAO scan; not an unseen coordination motif or thermal structure.",
}
target = out / f"{args.model.stem}_comparison.json"
target.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
