#!/usr/bin/env python3
"""Repeat Ag-C 48-atom PW-PBE reference, seeded from converged LCAO density."""
from pathlib import Path
import json, os
import numpy as np
from ase.io import read, write
import gpaw_data

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'pbe_cluster_transfer_pw_20261002_run2_lcao_seed_retry1'
OUT.mkdir(exist_ok=False)
SOURCE=ROOT.parent/'composition_candidate_screen/interface_contact_scan/AgC_secondary/candidate_Ag_C_R6.extxyz'
SEED=ROOT.parent/'composition_candidate_screen/interface_contact_scan/AgC_secondary/pbe/state.gpw'
os.environ['GPAW_SETUP_PATH']=str(gpaw_data.datapath())
from gpaw import GPAW, PW
from gpaw.mixer import Mixer
from gpaw.occupations import FermiDirac

atoms=read(SOURCE)
atoms.pbc=True
ids=np.asarray(atoms.arrays['lammps_id'],dtype=int)
central=np.asarray(atoms.arrays['central_pair'],dtype=bool)
symbols=np.asarray(atoms.get_chemical_symbols())
ag=int(np.flatnonzero(central & (symbols=='Ag'))[0])
ci=int(np.flatnonzero(central & (symbols=='C'))[0])
vec=atoms.positions[ci]-atoms.positions[ag]
distance=float(np.linalg.norm(vec))
calc=GPAW(str(SEED), mode=PW(500), legacy_gpaw=True, xc='PBE', kpts=(1,1,1),
          occupations=FermiDirac(0.1), mixer=Mixer(0.05,8,100),
          convergence={'energy':1e-5,'density':1e-5,'eigenstates':1e-5},
          maxiter=160, txt=str(OUT/'gpaw.log'))
atoms.calc=calc
checkpoint_index=[0]
def save_checkpoint():
    checkpoint_index[0]+=1
    path=OUT/f'checkpoint_{checkpoint_index[0]:02d}.gpw'
    calc.write(str(path),mode='all')
calc.attach(save_checkpoint,10)
energy=float(atoms.get_potential_energy())
forces=np.asarray(atoms.get_forces())
norms=np.linalg.norm(forces,axis=1)
pair_force=float(np.dot(forces[ci]-forces[ag],vec/distance))
write(OUT/'AgC_cluster_PW_PBE.extxyz',atoms,format='extxyz')
calc.write(str(OUT/'state.gpw'),mode='all')
summary={'source':str(SOURCE),'seed_restart':str(SEED),'atoms':len(atoms),
 'formula':atoms.get_chemical_formula(),'composition':{e:symbols.tolist().count(e) for e in sorted(set(symbols.tolist()))},
 'pbc':atoms.pbc.tolist(),'cell_A':atoms.cell.lengths().tolist(),
 'central_pair_ids':{'Ag':int(ids[ag]),'C':int(ids[ci])},'central_Ag_C_distance_A':distance,
 'energy_eV_cell':energy,'scf_converged':bool(calc.scf.converged),
 'central_pair_separating_force_eV_A':pair_force,'fmax_eV_A':float(norms.max()),
 'max_force_id':int(ids[int(norms.argmax())]),
 'method':{'xc':'PBE','basis':'plane wave','cutoff_eV':500,'kpts':[1,1,1],
 'smearing_eV':0.1,'scf_thresholds':'1e-5','mixer':'Pulay beta=0.05, nmaxold=8, weight=100',
 'initial_guess':'converged LCAO PBE state on the same local cluster; final calculation is PW-PBE'},
 'note':'A separate SCF rerun to compare convergence using a more conservative Pulay mixer and LCAO-seeded initial density. The original PW run is preserved independently.'}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2),flush=True)
