#!/usr/bin/env python3
"""After v9 training, run an Ag-Ti PW holdout and score v8/v9."""
from pathlib import Path
import json
import os
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent
OUT = ROOT / "pbe_external_v9_holdouts/AgTi_d2p7/retry1"
STATUS_PATH = ROOT / "mace_periodic_v9_forceonly/workflow_status.json"
REPORT = ROOT / "periodic_DFT_MACE_progress_20261002.md"
TRAIN_LOG = ROOT / "mace_periodic_v9_forceonly/train.stdout"
TRAIN_PID = 215115
TRAIN_MODEL = ROOT / "mace_periodic_v9_forceonly/models/Ag_Ti_Si_C_MACE_periodic_v9_forceonly.model"
V8_MODEL = ROOT / "mace_periodic_v8_forceonly/models/Ag_Ti_Si_C_MACE_periodic_v8_forceonly.model"
GPAW_PY = Path("/workspace/.local/venvs/gpaw/bin/python")
MACE_PY = Path("/workspace/.local/venvs/mace/bin/python")
DFT_RUNNER = ROOT / "run_agti_d27_periodic_pw_holdout.py"
EVALUATOR = ROOT / "evaluate_external_pw_model.py"


def save(status: dict) -> None:
    temp = STATUS_PATH.with_suffix(".tmp")
    temp.write_text(json.dumps(status, indent=2) + "\n")
    os.replace(temp, STATUS_PATH)


def training_process_active() -> bool:
    try:
        args = Path(f"/proc/{TRAIN_PID}/cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace")
    except FileNotFoundError:
        return False
    return "mace_run_train" in args and "v9_forceonly" in args


def latest_epoch() -> tuple[int | None, str | None]:
    if not TRAIN_LOG.exists():
        return None, None
    lines = TRAIN_LOG.read_text(errors="replace").splitlines()
    epochs = re.findall(r"Epoch\s+(\d+):", "\n".join(lines))
    return (int(epochs[-1]) if epochs else None, lines[-1] if lines else None)


def append_report(status: dict) -> None:
    marker = "## Ag–Ti 2.7 Å PW-PBE cross-method holdout after v9"
    current = REPORT.read_text()
    if marker in current:
        return
    lines = [
        f"\n{marker} (2026-10-03 UTC)\n",
        "\nThis independent PW-PBE single point uses the existing Ag-Ti 2.7 Å LCAO scan geometry. It checks method transfer at an already represented geometry, not a new coordination motif. The Ag-Ti 2.387 Å PW-PBE force frame was added force-only to v9; its energy was excluded.\n",
    ]
    for label, key in (("v8 baseline", "v8"), ("v9 candidate", "v9")):
        c = status.get("comparisons", {}).get(key)
        if not c:
            lines.append(f"\n{label}: not scored ({status.get('reason', 'model unavailable')}).\n")
            continue
        lines.append(
            f"\n{label}: component force RMSE `{c['full_force_component_RMSE_eV_A']:.6f}` eV/Å; "
            f"maximum force-vector error `{c['full_force_vector_max_abs_error_eV_A']:.6f}` eV/Å; "
            f"Ag–Ti pair force error `{c['pair_force_error_eV_A']:+.6f}` eV/Å; "
            f"absolute energy offset `{c['absolute_energy_error_meV_atom']:+.3f}` meV/atom (not calibrated).\n"
        )
    if status.get("dft_summary"):
        d = status["dft_summary"]
        lines.append(f"\nReference converged: `{d['scf_converged']}` in `{d['scf_iterations']}` SCF steps.\n")
    lines.append("\nInterpretation: this is a small local-cluster force screen only. It does not clear production transfer, thermal disorder, MPI/TTM dynamics, or long MD.\n")
    with REPORT.open("a") as f:
        f.write("".join(lines))


def main() -> None:
    status = {"state": "WAITING_FOR_V9_TRAINING", "started_utc": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime())}
    save(status)
    while training_process_active():
        epoch, line = latest_epoch()
        status.update({"state": "V9_TRAINING", "last_epoch": epoch, "last_log_line": line})
        save(status)
        time.sleep(60)

    if not TRAIN_MODEL.exists():
        status.update({"state": "V9_TRAINING_FAILED", "reason": "expected v9 model file was not produced"})
        save(status)
        append_report(status)
        return

    status.update({"state": "AGTI_D2P7_DFT_RUNNING", "v9_model": str(TRAIN_MODEL)})
    save(status)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with (OUT.parent / "runner.stdout").open("w") as stdout:
        proc = subprocess.Popen([str(GPAW_PY), str(DFT_RUNNER)], cwd=ROOT, stdout=stdout, stderr=subprocess.STDOUT)
        status["dft_pid"] = proc.pid
        while proc.poll() is None:
            progress_path = OUT / "progress.json"
            progress = json.loads(progress_path.read_text()) if progress_path.exists() else None
            status.update({"state": "AGTI_D2P7_DFT_RUNNING", "progress": progress})
            save(status)
            time.sleep(60)
        status["dft_returncode"] = proc.returncode

    summary_path = OUT / "summary.json"
    if not summary_path.exists():
        status.update({"state": "AGTI_D2P7_DFT_INCONCLUSIVE", "reason": "DFT runner exited without writing summary.json"})
        save(status)
        append_report(status)
        return
    dft_summary = json.loads(summary_path.read_text())
    status["dft_summary"] = dft_summary
    if not dft_summary.get("scf_converged"):
        status.update({"state": "AGTI_D2P7_DFT_INCONCLUSIVE", "reason": "GPAW SCF did not converge"})
        save(status)
        append_report(status)
        return

    env = os.environ.copy()
    env["MPLCONFIGDIR"] = "/tmp/mpl-v9-eval"
    env["XDG_CACHE_HOME"] = "/tmp/mace-v9-eval"
    Path(env["MPLCONFIGDIR"]).mkdir(parents=True, exist_ok=True)
    Path(env["XDG_CACHE_HOME"]).mkdir(parents=True, exist_ok=True)
    comparisons = {}
    for label, model_path in (("v8", V8_MODEL), ("v9", TRAIN_MODEL)):
        proc = subprocess.run(
            [str(MACE_PY), str(EVALUATOR), "--contact", "AgTi_d2p7", "--out", str(OUT), "--model", str(model_path)],
            cwd=ROOT, env=env, text=True, capture_output=True, timeout=1800, check=False,
        )
        status[f"{label}_evaluator_returncode"] = proc.returncode
        if proc.returncode:
            status[f"{label}_evaluator_stderr"] = proc.stderr[-8000:]
            status.update({"state": "SCORING_FAILED", "reason": f"{label} evaluator returned nonzero"})
            save(status)
            append_report(status)
            return
        result_path = OUT / f"{model_path.stem}_comparison.json"
        comparisons[label] = json.loads(result_path.read_text())
    status["comparisons"] = comparisons
    status["state"] = "DFT_CONVERGED_V8_V9_SCORED"
    status["completed_utc"] = time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime())
    save(status)
    append_report(status)


if __name__ == "__main__":
    main()
