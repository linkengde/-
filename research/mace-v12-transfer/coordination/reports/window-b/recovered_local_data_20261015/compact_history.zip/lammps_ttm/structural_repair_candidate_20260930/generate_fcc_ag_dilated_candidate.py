#!/usr/bin/env python3
"""Build a denser FCC Ag infill near the original Ag mask; freeze Ti/Si/C geometry."""
from pathlib import Path
import hashlib, json, shutil
import numpy as np
from scipy.spatial import cKDTree

SRC = Path('/workspace/.local/lammps-ttm/run-upload-20260930/stage65_model_150x300x300.data')
SRC_DIR = SRC.parent
OUT = Path(__file__).resolve().parent
OUT_DATA = OUT / 'stage65_model_fcc_ag_dilated2p2_clearance2p1.data'
BOX = np.array([150.1, 300.0, 300.0])
MASK_RADIUS_A = 2.2
MIN_CLEARANCE_A = 2.1
PHASE = np.array([0.25, 0.0, 0.25])

rows=[]; reading=False
for line in SRC.open():
    if line.startswith('Atoms #'):
        reading=True; continue
    if reading:
        q=line.split()
        if len(q)<5: continue
        try: rows.append((int(q[0]),int(q[1]),*map(float,q[2:5])))
        except ValueError: break
A=np.asarray(rows,dtype=np.float64)
ids=A[:,0].astype(np.int64); types=A[:,1].astype(np.int64); xyz=A[:,2:5]
back=types!=4; skeleton=xyz[back]; ag_old=xyz[types==4]
assert len(A)==682587 and len(skeleton)==469683 and len(ag_old)==212904

# Same 37 x 74 x 74 periodic fcc lattice selected by an 8-phase static scan.
lat=BOX/np.array([37,74,74],dtype=float)
I,J,K=np.indices((37,74,74))
base=np.stack((I.ravel()*lat[0],J.ravel()*lat[1],K.ravel()*lat[2]),axis=1)
basis=np.array([[0,0,0],[0,.5,.5],[.5,0,.5],[.5,.5,0]])
points=(base[:,None,:]+lat*(PHASE[None,None,:]+basis[None,:,:])).reshape(-1,3)%BOX
mask_tree=cKDTree(ag_old,boxsize=BOX)
skel_tree=cKDTree(skeleton,boxsize=BOX)
dmask,_=mask_tree.query(points,k=1,workers=-1)
dskel,_=skel_tree.query(points,k=1,workers=-1)
keep=(dmask<=MASK_RADIUS_A)&(dskel>=MIN_CLEARANCE_A)
ag_new=points[keep]
assert len(ag_new)>50000

# The model scaffold is copied exactly; new Ag IDs are allocated above the old max.
sc_rows=A[back]
new_ids=np.arange(int(ids.max())+1,int(ids.max())+len(ag_new)+1,dtype=np.int64)
out_ids=np.r_[sc_rows[:,0].astype(np.int64),new_ids]
out_types=np.r_[sc_rows[:,1].astype(np.int64),np.full(len(ag_new),4,dtype=np.int64)]
out_xyz=np.vstack((sc_rows[:,2:5],ag_new))
order=np.argsort(out_ids);out_ids=out_ids[order];out_types=out_types[order];out_xyz=out_xyz[order]
with OUT_DATA.open('w') as f:
    f.write('LAMMPS data file: FCC Ag infill expanded 2.2 A around original Ag mask; Ti/Si/C copied exactly\n\n')
    f.write(f'{len(out_ids)} atoms\n4 atom types\n\n')
    f.write(f'0 {BOX[0]:.10f} xlo xhi\n0 {BOX[1]:.10f} ylo yhi\n0 {BOX[2]:.10f} zlo zhi\n\n')
    f.write('Masses\n\n1 47.867\n2 28.0855\n3 12.0107\n4 107.87\n\nAtoms # atomic\n\n')
    for aid,typ,r in zip(out_ids,out_types,out_xyz):
        f.write(f'{aid:d} {typ:d} {r[0]:.12f} {r[1]:.12f} {r[2]:.12f}\n')

for filename in ['potential.interface_calibration_v0.inc']:
    shutil.copy2(SRC_DIR/filename,OUT/filename)
for filename in ['Ag_u3.eam','TSCBOP.tersoff']:
    shutil.copy2(SRC_DIR/'potentials'/filename,OUT/'potentials'/filename)

# Periodic nearest-neighbor distance of the retained FCC sites.
at=cKDTree(ag_new,boxsize=BOX); nearest,_=at.query(ag_new,k=2,workers=-1)
summary={
 'source':str(SRC),'source_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),
 'candidate_data':OUT_DATA.name,'source_atoms':len(A),'candidate_atoms':len(out_ids),
 'source_type_counts':{str(t):int((types==t).sum()) for t in (1,2,3,4)},
 'candidate_type_counts':{str(t):int((out_types==t).sum()) for t in (1,2,3,4)},
 'skeleton_coordinates_copied_verbatim':True,'box_A':BOX.tolist(),
 'Ag_EAM_reference_lattice_parameter_A':4.09,'candidate_lattice_A':lat.tolist(),
 'candidate_strain_vs_4p09':(lat/4.09-1).tolist(),'selected_fcc_phase':PHASE.tolist(),
 'original_Ag_mask_radius_A':MASK_RADIUS_A,'minimum_Ag_to_skeleton_A':float(dskel[keep].min()),
 'minimum_Ag_to_skeleton_gate_A':MIN_CLEARANCE_A,'median_Ag_to_skeleton_A':float(np.median(dskel[keep])),
 'fcc_Ag_nearest_neighbor_min_A':float(nearest[:,1].min()),'fcc_Ag_nearest_neighbor_median_A':float(np.median(nearest[:,1])),
 'Ag_sites_in_expanded_mask_before_clearance':int((dmask<=MASK_RADIUS_A).sum()),'Ag_sites_after_clearance':len(ag_new),
 'potential_status':'Inherited cross Morse calibration v0; not production-validated.',
 'scope':'Geometry candidate; one-step TTM smoke is separate; no long MD.'}
(OUT/'dilated_candidate_geometry_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
