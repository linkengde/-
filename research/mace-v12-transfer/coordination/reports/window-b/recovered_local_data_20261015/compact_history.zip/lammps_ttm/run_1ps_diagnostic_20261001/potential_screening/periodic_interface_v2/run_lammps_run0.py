#!/usr/bin/env python3
from pathlib import Path
import csv, json, subprocess
import numpy as np
from ase.io import read
ROOT=Path(__file__).resolve().parent
BASE=Path('/workspace/.local/lammps-ttm/composition_locked_candidate_20260930')
LMP=Path('/workspace/.local/lammps-ttm/bin/lmp_mpi')
MAP={'Ti':1,'Si':2,'C':3,'Ag':4}
MASS={1:47.867,2:28.0855,3:12.0107,4:107.8682}
MORSE={(1,4):(.94814194,2.,2.33708864),(2,4):(.93944948,2.,2.40407837),(3,4):(1.35077230,2.,2.15255924)}
results=[]
for tag in ('d2.3','d2.6','d2.9'):
 src=ROOT/'structures'/f'Ti_term_Ag111_periodic_{tag}.extxyz'; atoms=read(src); sy=atoms.get_chemical_symbols(); types=[MAP[x] for x in sy]
 work=ROOT/'lammps_run0'/tag;work.mkdir(parents=True,exist_ok=False)
 cell=atoms.cell.lengths(); data=work/'system.data'
 with data.open('w') as f:
  f.write('Periodic Ag/Ti3SiC2 interface\n\n28 atoms\n4 atom types\n\n')
  f.write(f'0 {cell[0]:.12f} xlo xhi\n0 {cell[1]:.12f} ylo yhi\n0 {cell[2]:.12f} zlo zhi\n\nMasses\n\n')
  for k,v in MASS.items():f.write(f'{k} {v}\n')
  f.write('\nAtoms # atomic\n\n')
  for i,(t,p) in enumerate(zip(types,atoms.positions),1):f.write(f'{i} {t} {p[0]:.12f} {p[1]:.12f} {p[2]:.12f}\n')
 variants={}
 for label,scale in [('calibration_v0',1.),('all_cross_zero',0.)]:
  d=work/label;d.mkdir(); dump=d/'forces.dump'
  lines=['units metal','atom_style atomic','boundary p p p',f'read_data {data}','pair_style hybrid eam tersoff morse 8.0',
    f'pair_coeff 4 4 eam {BASE}/potentials/Ag_u3.eam',f'pair_coeff * * tersoff {BASE}/potentials/TSCBOP.tersoff Ti Si C NULL']
  for (i,j),(d0,a,r0) in MORSE.items():lines.append(f'pair_coeff {i} {j} morse {d0*scale:.12g} {a:.12g} {r0:.12g} 8.0')
  lines+=['neighbor 2.0 nsq','neigh_modify every 1 delay 0 check yes','variable fnorm atom sqrt(fx*fx+fy*fy+fz*fz)','compute fmax all reduce max v_fnorm','thermo 1','thermo_style custom step atoms pe c_fmax','thermo_modify flush yes lost error',f'dump f all custom 1 {dump} id type x y z fx fy fz','dump_modify f sort id','run 0','']
  inp=d/'in.run0';inp.write_text('\n'.join(lines));log=d/'log.lammps'
  with (d/'run.stdout').open('w') as fo:subprocess.run([str(LMP),'-in',str(inp),'-log',str(log)],cwd=d,check=True,stdout=fo,stderr=subprocess.STDOUT)
  vals=[x.split() for x in log.read_text().splitlines() if x.strip().startswith('0 ') and len(x.split())==4]
  arr=np.loadtxt(dump,comments='#',skiprows=9); f=arr[:,5:8]; n=np.linalg.norm(f,axis=1)
  variants[label]={'PE_eV':float(vals[-1][2]),'Fmax_eV_A':float(n.max()),'Fmax_atom_id':int(arr[n.argmax(),0])}
 result={'geometry':tag,'nominal_gap_A':float(tag[1:]),'PBC':'ppp','variants':variants}
 (work/'summary.json').write_text(json.dumps(result,indent=2)+'\n');results.append(result);print(json.dumps(result),flush=True)
(ROOT/'lammps_run0'/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
