#!/usr/bin/env python3
"""Recover holdout summaries from completed GPAW logs and force-labelled extxyz."""
from pathlib import Path
import json
import re

import numpy as np
from ase.io import read

ROOT = Path(__file__).resolve().parent
BASE = ROOT / "pbe_external_v8_motif_holdouts"


def recover(contact: str) -> dict:
    out = BASE / contact / "retry1"
    summary_path = out / "summary.json"
    if summary_path.exists():
        raise SystemExit(f"Refusing to overwrite existing summary: {summary_path}")
    log = (out / "gpaw.log").read_text()
    converged = re.findall(r"Converged in\s+(\d+)\s+steps", log)
    if not converged:
        raise SystemExit(f"No explicit GPAW convergence marker in {out / 'gpaw.log'}")
    niter = int(converged[-1])
    scf_duration = re.findall(r"SCF loop duration:\s*([0-9.]+)\s*s", log)
    total_duration = re.findall(r"^\s*Total:\s*([0-9.]+)\s*#", log, flags=re.MULTILINE)
    if not scf_duration or not total_duration:
        raise SystemExit(f"Missing timing footer in {out / 'gpaw.log'}")
    extxyz = out / f"{contact}_cluster_PW_PBE.extxyz"
    if not extxyz.exists() or not (out / "state.gpw").exists():
        raise SystemExit(f"Missing completed force or GPAW state file in {out}")
    atoms = read(extxyz)
    atoms.pbc = True
    symbols = np.asarray(atoms.get_chemical_symbols())
    ids = np.asarray(atoms.arrays["lammps_id"], dtype=int)
    central = np.asarray(atoms.arrays["central_pair"], dtype=bool)
    element = contact[2:]
    ag_idx = int(np.flatnonzero(central & (symbols == "Ag"))[0])
    partner_idx = int(np.flatnonzero(central & (symbols == element))[0])
    vec = atoms.positions[partner_idx] - atoms.positions[ag_idx]
    distance = float(np.linalg.norm(vec))
    forces = np.asarray(atoms.get_forces())
    norms = np.linalg.norm(forces, axis=1)
    source = ROOT.parent / "composition_candidate_screen" / "interface_contact_scan" / f"candidate_{contact[:2]}_{contact[2:]}_R6.extxyz"
    info = atoms.info
    summary = {
        "source": str(source),
        "contact": contact,
        "atoms": len(atoms),
        "formula": atoms.get_chemical_formula(),
        "composition": {e: int(np.count_nonzero(symbols == e)) for e in sorted(set(symbols.tolist()))},
        "pbc": atoms.pbc.tolist(),
        "cell_A": atoms.cell.lengths().tolist(),
        "periodic_image_gap_A": float(np.min(atoms.cell.lengths() - (atoms.positions.max(axis=0) - atoms.positions.min(axis=0)))),
        "central_pair_ids": {"Ag": int(ids[ag_idx]), element: int(ids[partner_idx])},
        "central_pair_distance_A": distance,
        "energy_eV_cell": float(atoms.get_potential_energy()),
        "scf_converged": True,
        "scf_iterations": niter,
        "central_pair_separating_force_eV_A": float(np.dot(forces[partner_idx] - forces[ag_idx], vec / distance)),
        "fmax_eV_A": float(norms.max()),
        "rms_force_eV_A": float(np.sqrt(np.mean(norms**2))),
        "max_force_source_id": int(ids[int(norms.argmax())]),
        "method": {
            "xc": "PBE", "basis": "plane wave", "cutoff_eV": 500,
            "kpts": [1, 1, 1], "smearing_eV": 0.1,
            "scf_thresholds": "energy/density/eigenstates 1e-5",
            "mixer": "Pulay beta=0.05, nmaxold=8, weight=100",
            "maxiter": 160, "GPAW_version": __import__("gpaw").__version__,
        },
        "elapsed_s": float(total_duration[-1]),
        "scf_elapsed_s": float(scf_duration[-1]),
        "recovered_from": ["explicit GPAW 'Converged in N steps' log marker", str(extxyz), str(out / "state.gpw")],
        "note": "Summary reconstructed because the process ended after writing the converged force-labelled extxyz and GPAW state but before writing summary.json. Forces are an independent periodic PW-PBE single point on a local motif, not a production or thermal configuration.",
    }
    summary_path.write_text(json.dumps(summary, indent=2) + "\n")
    return summary


if __name__ == "__main__":
    print(json.dumps({contact: recover(contact) for contact in ("AgTi", "AgSi")}, indent=2))
