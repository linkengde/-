#!/usr/bin/env python3
"""Compare a converged PW-PBE local-cluster holdout against MACE v8."""
from pathlib import Path
import json
import sys
import numpy as np
import torch
from ase.io import read
from mace.calculators import MACECalculator

if len(sys.argv) != 2 or sys.argv[1] not in {"AgSi", "AgTi"}:
    raise SystemExit("usage: evaluate_pw_mace_holdout.py AgSi|AgTi")
root = Path(__file__).resolve().parent
contact = sys.argv[1]
out = root / "pbe_external_v8_motif_holdouts" / contact / "retry1"
scf = json.loads((out / "summary.json").read_text())
if not scf.get("scf_converged", False):
    raise SystemExit(f"Refusing to score unconverged PW-PBE forces: {contact}")
label = read(out / f"{contact}_cluster_PW_PBE.extxyz")
label.pbc = True
reference_energy = float(label.get_potential_energy())
reference_forces = np.asarray(label.get_forces())
central = np.asarray(label.arrays["central_pair"], dtype=bool)
symbols = np.asarray(label.get_chemical_symbols())
ids = np.asarray(label.arrays["lammps_id"], dtype=int)
ag_idx = int(np.flatnonzero(central & (symbols == "Ag"))[0])
element = contact[2:]
partner_idx = int(np.flatnonzero(central & (symbols == element))[0])
vec = label.positions[partner_idx] - label.positions[ag_idx]
distance = float(np.linalg.norm(vec))
unit = vec / distance
reference_pair = float(np.dot(reference_forces[partner_idx] - reference_forces[ag_idx], unit))

torch.set_default_dtype(torch.float64)
model_path = root / "mace_periodic_v8_forceonly/models/Ag_Ti_Si_C_MACE_periodic_v8_forceonly.model"
model = torch.load(model_path, map_location="cpu", weights_only=False).double().eval()
label.calc = MACECalculator(models=[model], device="cpu", default_dtype="float64")
mace_energy = float(label.get_potential_energy())
mace_forces = np.asarray(label.get_forces())
delta = mace_forces - reference_forces
mace_pair = float(np.dot(mace_forces[partner_idx] - mace_forces[ag_idx], unit))
comparison = {
    "contact": contact,
    "scf_converged": bool(scf["scf_converged"]),
    "scf_iterations": int(scf["scf_iterations"]),
    "reference_method": "periodic PBE plane-wave, 500 eV, Gamma, 0.1 eV Fermi smearing",
    "atoms": len(label), "formula": label.get_chemical_formula(),
    "central_pair_ids": {"Ag": int(ids[ag_idx]), element: int(ids[partner_idx])},
    "central_pair_distance_A": distance,
    "full_force_component_RMSE_eV_A": float(np.sqrt(np.mean(delta**2))),
    "full_force_vector_max_abs_error_eV_A": float(np.linalg.norm(delta, axis=1).max()),
    "reference_pair_separating_force_eV_A": reference_pair,
    "MACE_pair_separating_force_eV_A": mace_pair,
    "pair_force_error_eV_A": mace_pair - reference_pair,
    "absolute_energy_error_meV_atom": (mace_energy - reference_energy) * 1000.0 / len(label),
    "MACE_model": str(model_path),
    "note": "External single-point motif holdout; forces are the main transfer metric. Not a thermally disordered environment or proof for production MD.",
}
(out / "mace_v8_comparison.json").write_text(json.dumps(comparison, indent=2) + "\n")
print(json.dumps(comparison, indent=2))
