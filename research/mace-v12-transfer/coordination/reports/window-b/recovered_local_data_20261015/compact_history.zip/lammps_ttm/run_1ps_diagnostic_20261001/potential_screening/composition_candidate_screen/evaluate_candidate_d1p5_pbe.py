from pathlib import Path
import csv
import json
import os

import numpy as np
from ase.io import read
import gpaw_data


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "pbe_pair_d1p5"
START = ROOT / "pbe_pair_d1p8" / "state.gpw"
SOURCE = ROOT / "candidate_pair_scan_mace" / "pair_d1p5.extxyz"
SETUP = Path(gpaw_data.datapath())
os.environ["GPAW_SETUP_PATH"] = str(SETUP)

from gpaw import GPAW

if OUT.exists():
    raise SystemExit(f"Refusing to reuse existing output directory: {OUT}")
if not START.is_file() or not SOURCE.is_file():
    raise SystemExit("Missing converged 1.8 A PBE checkpoint or MACE 1.5 A geometry")

OUT.mkdir()
atoms = read(SOURCE)
ids = atoms.arrays["lammps_id"].astype(int)
ia, ib = (int(np.flatnonzero(ids == atom_id)[0]) for atom_id in (520183, 520177))
vector = atoms.positions[ib] - atoms.positions[ia]
distance = float(np.linalg.norm(vector))
unit = vector / distance
atoms.calc = GPAW(str(START), maxiter=120, txt=str(OUT / "gpaw.log"))
energy = float(atoms.get_potential_energy())
forces = atoms.get_forces()
norms = np.linalg.norm(forces, axis=1)
separating = float(np.dot(forces[ib] - forces[ia], unit))

with (OUT / "forces.csv").open("x", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["lammps_id", "symbol", "fx_eV_A", "fy_eV_A", "fz_eV_A", "force_norm_eV_A"])
    for atom_id, atom, force, norm in zip(ids, atoms, forces, norms):
        writer.writerow([int(atom_id), atom.symbol, *map(float, force), float(norm)])
atoms.calc.write(str(OUT / "state.gpw"), mode="all")
summary = {
    "atoms": len(atoms),
    "GPAW_energy_eV": energy,
    "C_pair_distance_A": distance,
    "C_pair_separating_force_eV_per_A": separating,
    "C520183_force_norm_eV_per_A": float(norms[ia]),
    "C520177_force_norm_eV_per_A": float(norms[ib]),
    "max_force_norm_eV_per_A": float(norms.max()),
    "max_force_lammps_id": int(ids[int(norms.argmax())]),
}
(OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2), flush=True)
