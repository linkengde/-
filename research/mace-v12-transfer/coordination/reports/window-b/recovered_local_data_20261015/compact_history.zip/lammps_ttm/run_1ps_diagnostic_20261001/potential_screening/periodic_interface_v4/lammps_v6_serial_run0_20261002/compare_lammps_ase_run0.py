from pathlib import Path
import json
import re
import numpy as np
import torch
from ase.io import read
from mace.calculators import MACECalculator

here = Path(__file__).resolve().parent
root = here.parent
source = root.parent / 'composition_candidate_screen/interface_contact_scan/AgC_secondary/candidate_Ag_C_R6.extxyz'
model_path = root / 'mace_periodic_v6/models/Ag_Ti_Si_C_MACE_periodic_v6.model'
atoms = read(source)
atoms.pbc = False  # Match this LAMMPS run's fixed, nonperiodic boundaries.
torch.set_default_dtype(torch.float64)
model = torch.load(model_path, map_location='cpu', weights_only=False).double().eval()
atoms.calc = MACECalculator(models=[model], device='cpu', default_dtype='float64')
ase_e = float(atoms.get_potential_energy())
ase_f = np.asarray(atoms.get_forces())
lines = (here/'forces.dump').read_text().splitlines()
start = next(i for i, line in enumerate(lines) if line.startswith('ITEM: ATOMS')) + 1
lmp_f = np.zeros_like(ase_f)
for line in lines[start:]:
    v = line.split()
    if len(v) == 8:
        aid = int(v[0])
        lmp_f[aid-1] = [float(x) for x in v[5:8]]
if len(lines) < start + len(atoms):
    raise RuntimeError('Incomplete LAMMPS force dump')
log = (here/'log.mace_v6_run0_serial_retry3').read_text().splitlines()
thermo_i = next(i for i,x in enumerate(log) if re.search(r'\bPotEng\b',x) and 'c_maxforce' in x)
thermo = log[thermo_i+1].split()
lmp_e, lmp_fmax = float(thermo[2]), float(thermo[3])
delta = lmp_f - ase_f
summary = {
  'model': str(model_path), 'source_structure': str(source), 'boundary': 'fixed/nonperiodic',
  'atoms': len(atoms), 'LAMMPS_step': 0, 'LAMMPS_PE_eV': lmp_e, 'ASE_PE_eV': ase_e,
  'energy_abs_error_eV': abs(lmp_e-ase_e), 'LAMMPS_Fmax_eV_A': lmp_fmax,
  'ASE_Fmax_eV_A': float(np.linalg.norm(ase_f,axis=1).max()),
  'force_component_max_abs_error_eV_A': float(np.abs(delta).max()),
  'force_component_RMSE_eV_A': float(np.sqrt(np.mean(delta**2))),
  'force_vector_max_abs_error_eV_A': float(np.linalg.norm(delta,axis=1).max()),
  'force_vector_RMSE_eV_A': float(np.sqrt(np.mean(np.sum(delta**2,axis=1)))),
  'note': 'LAMMPS dump has default six-significant-digit force formatting; validates interface parity only, not physical model accuracy.'
}
out = here/'lammps_ase_force_check.json'
with out.open('x') as f: json.dump(summary,f,indent=2); f.write('\n')
print(json.dumps(summary,indent=2))
