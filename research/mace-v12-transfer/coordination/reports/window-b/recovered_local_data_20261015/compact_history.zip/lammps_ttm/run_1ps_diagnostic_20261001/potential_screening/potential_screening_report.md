# Ag–Ti–Si–C 势函数局部筛查报告

日期：2026-10-01  
基准结构：原始 Ag 排布的 step 0/step 1000 局部 C520183–C520177 对；另对组成锁定候选做独立复核。  
性质：静态力/能量筛查；没有运行 MD，也没有修改候选结构或势文件。

## 原始 Ag 排布的局部筛查

三个互相独立的模型——MACE-MP-0b3、CHGNet 和 GPAW/PBE——在 step 0 都预测这对 C 原子应相互分离；当前周期 LAMMPS 混合势却预测净靠近。力分解显示 Ag–C Morse 项单独贡献 **−2.15 eV/Å**，把关闭交叉项后的向外力 **+1.18 eV/Å** 翻成完整势的 **−0.97 eV/Å**。

这是 calibration v0 的强烈反证，尤其指向 Ag–C 交叉作用；但当前 DFT 比较采用截取的非周期局部簇，不是周期 Ag/Ti₃SiC₂ 界面，因此结果属于局部筛查，不能替代界面黏附能、终止面和应变的正式验证。**当前势函数仍不应继续用于 1 ps 或更长模拟。**

## 软件和模型

- MACE：`mace-torch 0.3.16`，CPU PyTorch `2.5.1+cpu`，安装在 `/workspace/.local/venvs/mace`。
- MACE 权重：官方 `mace-mp-0b3-medium.model`，76 MiB，SHA256 `2f2be696351ac9e94fbe01cdfb6f017679acdbd2db7645209ef55fec9826b012`；路径 `/workspace/.local/cache/mace/mace-mp-0b3-medium.model`。该模型已成功对 Ag、Ti、Si、C 局部簇计算能量和力。
- CHGNet：`chgnet 0.4.2`，wheel 内置预训练 `CHGNet v0.3.0` checkpoint。它作为第二个通用模型交叉检查，不表示其 Ag/Ti₃SiC₂ 界面已经验证。
- DFT：GPAW `26.7.0`、ASE `3.29.0`、`gpaw-data 1.2.1`，在 `/workspace/.local/venvs/gpaw`。Ag、Ti、Si、C 的 PBE PAW 数据可用。GPAW 是为当前云环境编成单进程版本；Ag fcc 的 PBE 参考单点正常完成。
- LAMMPS 接口：在干净导出的源码副本 `/workspace/.local/src/lammps-mace-source` 中隔离编译了启用 ML-IAP/Python 的 CPU 版 LAMMPS。原源码树中的 TTM 文件和 make 生成文件都保留未动。

## 构型与计算

从 step 0 和 step 1000 dump 中按原子 ID 提取 C 对附近的局部结构。力比较使用相同的 73 个原子（以 C 对中心半径 6 Å 取两帧 ID 并集），放进 28 Å 立方真空盒，`pbc=False`。另外以 109 原子、7 Å 半径重复了 MACE 与 CHGNet 的力计算，用于检查截断半径敏感性。

GPAW 对 73 原子簇做静态 PBE/LCAO/DZP 单点，0.1 eV Fermi 展宽，密度/能量/本征态收敛阈值为 `1e-4`。step 0 在 40 次迭代收敛，step 1000 从 step 0 收敛波函数重启后在 34 次迭代收敛。两个 cluster 结构未优化，计算只取固定坐标的力和能量。

定义分离力：`(F_C520177 − F_C520183) · u`，其中 `u` 从 C520183 指向 C520177。正数表示把 C 对推开，负数表示拉近。详细数值见 [model_force_comparison.csv](model_force_comparison.csv)；原始逐原子力见 `mace_forces_*.csv`、`chgnet_forces_*.csv` 和 `gpaw_step*_R6*/forces.csv`。

## 结果

| 构型 | C–C 距离 | LAMMPS 完整周期势 | Ag–C Morse 分量 | MACE R6 / R7 | CHGNet R6 / R7 | PBE R6 |
|---|---:|---:|---:|---:|---:|---:|
| step 0 | 2.2647 Å | **−0.970** | **−2.150** | +4.388 / +4.073 | +2.253 / +2.232 | +2.661 |
| step 1000 | 1.2469 Å | +45.656 | +2.425 | +19.866 / +20.382 | +21.176 / +21.591 | +21.009 |

三种独立模型在 step 0 的力方向一致，均与当前完整势相反。MACE、CHGNet 对半径从 6 Å 扩到 7 Å 的分离力变化很小：step 0 分别变化约 7% 和 1%；step 1000 变化约 3% 和 2%。因此正向趋势不是由 6 Å 选簇半径单独造成的。

在已压缩的 step 1000 构型上，所有模型都预测强烈向外恢复力。当前完整 LAMMPS 势的相对分离力约为 PBE 局部簇的 2.2 倍。每个模型各自计算的 step 1000 簇能量都高于 step 0：PBE +6.501 eV，MACE +6.651 eV，CHGNet +5.887 eV。不同模型的绝对能量基准不同，不能横向比较绝对值。

除 C 对的投影力外，也对 73 个共同原子逐一比较了 MACE/CHGNet 与 PBE 的全力向量。MACE 的全原子力向量 RMSE 为 step 0 **0.911 eV/Å**、step 1000 **1.075 eV/Å**，分别约为 PBE 力 RMS 的 21.7% 和 21.1%；CHGNet 对应为 0.856/1.157 eV/Å（20.4%/22.7%）。这组全簇误差包含未钝化边缘原子，只能用于这两个局部构型的交叉核对。逐元素统计与完整指标见 [force_error_analysis.json](force_error_analysis.json)。

另做了一个固定几何的 C–C 距离扫描：在原始 Ag 环境下，2.265 Å 时 MACE/PBE 分离力为 +4.388/+2.661 eV/Å；只把这两颗 C 原子对称移至 1.8 Å 后，两者分别为 −0.218/−0.877 eV/Å，力方向都转为吸引。到 1.5 Å，MACE/PBE 分离力分别为 −2.270/−0.156 eV/Å；PBE 仍略有吸引，但幅度远小于 MACE。实际 step 1000 的 1.247 Å 构型（周围原子也已改变）MACE/PBE 又都预测强烈排斥 +19.866/+21.009 eV/Å。结果显示力随压缩路径可能反转，且 1.5 Å 点的 MACE 力定量偏差明显；固定双原子扫描不等于真实结构演化。

## LAMMPS 数值接口核验

MACE 的官方 `--format mliap` 转换在当前 MACE 0.3.16 中因 Cuequivariance 转换状态键不兼容而失败。为核验数值实现，直接序列化模型并用本地兼容层在非周期、单 MPI rank、零 ghost 的局部簇静态 `run 0` 上调用；兼容层在发现 ghost 原子时会停止。原始 Ag 的 73 原子簇与 ASE 直接调用 MACE 一致：势能差 `4.44e-6 eV`、逐原子力向量 RMSE `4.08e-6 eV/Å`。composition_locked_candidate 的 63 原子簇也一致：势能差 `4.20e-6 eV`、力向量 RMSE `3.64e-6 eV/Å`（差异主要来自 LAMMPS dump 默认只输出 6 位有效数字）。细节分别在 `lammps_mace_integration/lammps_ase_force_check.json` 和 `composition_candidate_screen/candidate_mace_interface_check.json`。

这只证明本次非周期单进程测试中模型接口数值相符；当前兼容层不支持周期 ghost/MPI，因此不能用于大模型或生产运行，也未接入 TTM。

结合此前逐势项分解，当前最可能的失稳机制是：Ag–C Morse 交叉项在初态附近对 C 对产生了不合理的净吸引，触发向内移动；压缩后 Ti–Si–C 势再给出很强排斥。TTM 力不属于本次静态簇 DFT 计算范围。

## composition_locked_candidate 的实际局部环境

对质量分数锁定候选 `/workspace/.local/lammps-ttm/composition_locked_candidate_20260930/stage65_model_fcc_ag_59p8775wt_candidate.data` 重新提取了中心 C 对附近结构。该候选骨架坐标不变，但 FCC Ag 重排后 6 Å 内只有 3 个 Ag；C520183–C520177 距离为 2.264625 Å。候选中两颗 C 最近 Ag 距离为 3.887/3.203 Å；原始 Ag 排布下最近距离为 2.156/2.171 Å。R6/R7 局部簇分别为 63/90 个原子。

对候选运行的完整周期、682,587 原子 LAMMPS calibration v0 `run 0`，C 对分离力为 **+1.718 eV/Å**（排斥），PE = −3,288,546 eV，Fmax = 11.637214 eV/Å。候选局部非周期簇 PBE/LCAO/DZP 单点已收敛，PBE 分离力为 **−1.790 eV/Å**；MACE R6/R7 为 **−0.344/−0.513 eV/Å**，CHGNet R6/R7 为 **−1.825/−1.926 eV/Å**。因此候选起始 C 对上 PBE 与两个机器学习模型都预测吸引，符号与完整周期 calibration v0 相反；数值上 CHGNet 更接近这一个点，MACE 明显低估吸引强度。63 个共同原子的全力向量 RMSE 则为 MACE **0.816 eV/Å**（PBE 力 RMS 的 32.4%）、CHGNet **0.987 eV/Å**（39.1%）；中心 C 对投影力误差分别为 1.446 和 0.034 eV/Å。细项见 `composition_candidate_screen/candidate_force_error_analysis.json`。这仍是单个未钝化非周期簇的局部比较。

这说明更换 Ag 布局后，中心力对具体局部 Ag 环境与周期边界很敏感；原始 Ag 排布上 MACE/PBE 的力曲线不能直接移用到组成锁定候选。候选抽簇清单在 `composition_candidate_screen/cluster_manifest.json`，完整周期 `run 0` 证据和模型力比较在 `composition_candidate_screen/`。

在同一候选 R6 簇上只移动 C520183/C520177 的 MACE 扫描显示更强的内聚：距离 2.265、2.0、1.8、1.5 Å 时，分离力依次为 −0.344、−2.994、−5.816、−9.046 eV/Å，模型能量随压缩降低。起始 2.265 Å 的 PBE 为 −1.790 eV/Å；MACE 与 CHGNet 同样预测吸引，但 MACE 低估该对吸引力。候选 1.8 Å PBE 已收敛：分离力为 −7.100 eV/Å，MACE 为 −5.816 eV/Å；相对起点，PBE/MACE 能量分别下降 0.965/0.640 eV。候选 1.5 Å PBE 也已收敛：分离力 −8.395 eV/Å，MACE 为 −9.046 eV/Å；相对起点，能量分别下降 2.212/1.898 eV。63 原子全簇力向量 RMSE 在起点、1.8、1.5 Å 分别为 0.816、0.823、0.820 eV/Å（约为各自 PBE 力 RMS 的 31–32%）。MACE 捕捉到这条候选局部 C–C 压缩曲线的方向和总体趋势，但中心对力与相对能量仍有误差；这不是交叉势或周期界面的验证。完整周期 v0 则在起始位置预测 +1.718 eV/Å 向外。

## 限制

- 对候选两个不同 Ag–C 局部簇做同坐标对照时，Ag–C 距离都约 2.2026 Å；LAMMPS calibration v0 的分离力分别为 −2.522 和 +0.858 eV/Å，PBE 分别为 −0.864 和 −1.197 eV/Å。拆项后，Ag–C Morse 对投影的贡献近似（−1.584/−1.677），而 Ag–Ti/Si 合计分量分别为 −0.834/+0.751 eV/Å。只缩放 Ag–C D0 时两环境所需比例约 −0.05/2.23，不能同时匹配。详细参数、力分解和日志见[交叉项审计](calibration_v0_cross_terms_audit.md)。
- primary 和 secondary Ag–C 簇新增 2.0/2.4 Å PBE 力扫描后，v0 secondary 的 2.2026 Å 点仍错方向；epoch-51 微调模型在训练过的 primary 曲线上接近 PBE，但在完整留出的 secondary 环境仍有约 0.44 eV/Å 的全原子力 RMSE。逐点表见[Ag–C 环境距离扫描报告](composition_candidate_screen/interface_contact_scan/agc_environment_distance_scan_report.md)，使用 primary 扫描训练、secondary 全环境留出的第二轮微调正在进行。
- 原始 Ag 排布和 composition_locked_candidate 的 DFT/机器学习簇都没有周期边界，边缘未钝化，也没有把远处周期镜像以嵌入势或电荷环境表示；候选的完整周期 LAMMPS 与非周期局部簇已给出不同力符号，必须进一步做周期界面 DFT。
- 组成锁定候选最近 Ag–Ti、Ag–Si、Ag–C 接触分别为 2.387、2.454、2.203 Å。48–51 原子非周期簇的分离力 MACE/PBE 分别为 Ag–Ti +6.053/+5.361、Ag–Si +2.088/+2.030、Ag–C +0.519/−0.864 eV/Å。Ag–Ti 与 Ag–Si 的中心对力幅值接近；最短 Ag–C 点的方向相反，说明通用 MACE 在此 Ag–C 环境未通过局部筛查。另一个 2.203 Å 的 Ag–C 接触已独立计算 PBE：MACE/PBE 分离力为 −0.040/−1.197 eV/Å，表明 Ag–C 响应依赖局部环境。基于 5 个训练构型做的微调，在独立 Ag–C 留出点把力方向改对，但分离力仍低估；5 个留出簇的加权全原子力 RMSE 仅从 0.549 降至 0.502 eV/Å，C–C 1.5 Å 留出点还出现回退。完整数值见 [微调试验报告](composition_candidate_screen/mace_finetune_pilot/evaluation_epoch51/mace_finetune_pilot_report.md)。所有这些仍是非周期小簇；尚未计算 Ag(111)/Ti₃SiC₂(0001) 周期界面黏附能、平衡间距或多种表面终止/堆垛。
- MACE-MP-0b3 与 CHGNet 是通用预训练模型，不因覆盖元素就自动成为该界面的已验证势。
- 没有将新势接入 LAMMPS TTM，也没有跑 MD。

## 下一步

1. 构造小型周期 Ag/Ti₃SiC₂ 界面胞，比较表面终止、吸附/堆垛和界面距离，计算 PBE 结合能、间距和力。
2. 扩充覆盖体相、表面、压缩接触与界面的 DFT 训练/验证集，再重新拟合四元素势；对不同接触环境和 C–C 压缩路径做独立留出测试。
3. 解决 LAMMPS 正式周期/MPI 接口，再验证力误差、界面能和短距离排斥；全部静态检查通过后才做极短 TTM 烟测。

当前原候选及 calibration v0 文件未改动。
