#!/usr/bin/env bash
set -u

ti_pid="${1:?pass the active d=2.6 Python PID}"
root="/workspace/.local/lammps-ttm/run_1ps_diagnostic_20261001/potential_screening/periodic_interface_v4"
python="/workspace/.local/venvs/gpaw/bin/python"
log="$root/alt_termination_serial_launcher.log"
d26_summary="$root/pbe_singlepoint_d2.6_500eV_run2/summary.json"
d29_summary="$root/pbe_singlepoint_d2.9_500eV_run1/summary.json"
d29_status="$root/d2.9_serial_launcher.log"

while kill -0 "$ti_pid" 2>/dev/null; do
  sleep 20
done

if [[ ! -s "$d26_summary" ]] || ! "$python" -c 'import json,sys; sys.exit(0 if json.load(open(sys.argv[1]))["scf_converged"] else 1)' "$d26_summary"; then
  echo "STOP: d=2.6 did not produce a converged summary; alternate terminations were not run." >> "$log"
  exit 1
fi

# The existing serial launcher owns the d=2.9 side-swap job. Wait until it
# produces a summary or a terminal status before starting additional DFT.
while [[ ! -s "$d29_summary" ]] && ! rg -q 'STOP:|completed with exit status' "$d29_status" 2>/dev/null; do
  sleep 20
done

if ! rg -q 'completed with exit status 0\.' "$d29_status" 2>/dev/null; then
  echo "STOP: d=2.9 PBE check failed; alternate terminations were not run." >> "$log"
  exit 1
fi

echo "Starting PBE checks for Si- and C-terminated contact cells." >> "$log"
for element in Si C; do
  outtag="${element}_terminated"
  "$python" -u "$root/run_one_interface_pbe.py" 2.6 "$outtag" structures_alt_terminations_thin "Ag_${element}_terminated" > "/tmp/pbe_${element}_terminated.stdout" 2>&1
  status=$?
  cp "/tmp/pbe_${element}_terminated.stdout" "$root/pbe_singlepoint_d2.6_500eV_${outtag}/run.stdout" 2>/dev/null || true
  if [[ "$status" -ne 0 ]]; then
    echo "STOP: ${element}-terminated PBE check ended with status $status; later cases were not run." >> "$log"
    exit "$status"
  fi
  echo "${element}-terminated PBE check converged." >> "$log"
done
echo "All queued alternate-termination PBE checks completed." >> "$log"
