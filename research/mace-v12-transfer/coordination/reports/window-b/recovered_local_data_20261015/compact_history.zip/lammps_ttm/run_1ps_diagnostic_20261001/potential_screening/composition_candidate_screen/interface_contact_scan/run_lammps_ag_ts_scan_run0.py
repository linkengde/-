#!/usr/bin/env python3
"""Run v0 and zero-cross-term LAMMPS run 0 on Ag-Ti/Ag-Si PBE scan geometries."""
from pathlib import Path
import csv
import json
import subprocess
import numpy as np
from ase.io import read
ROOT = Path(__file__).resolve().parent
SCAN = ROOT / "AgTi_AgSi_environment_distance_scans_PBE_v1"
OUT = ROOT / "AgTi_AgSi_environment_distance_scans_LAMMPS_v0_v1"
BASE = Path("/workspace/.local/lammps-ttm/composition_locked_candidate_20260930")
LMP = Path("/workspace/.local/lammps-ttm/bin/lmp_mpi")
SPECS = {
    "AgTi": {"ids": (687247, 479027), "morse": (1, 4)},
    "AgSi": {"ids": (683609, 366934), "morse": (2, 4)},
}
MORSE = {(1, 4): (0.94814194, 2.0, 2.33708864), (2, 4): (0.93944948, 2.0, 2.40407837), (3, 4): (1.35077230, 2.0, 2.15255924)}
MASS = {1: 47.8670000, 2: 28.0855000, 3: 12.0107000, 4: 107.8682000}
OUT.mkdir(exist_ok=True)
all_rows = []
for env, spec in SPECS.items():
    for xyz in sorted((SCAN / env).glob("d*/input.extxyz")):
        tag = xyz.parent.name
        if not (xyz.parent / "summary.json").exists():
            print(json.dumps({"env": env, "tag": tag, "status": "skipped_no_completed_PBE_summary"}), flush=True)
            continue
        target = OUT / env / tag
        target.mkdir(parents=True, exist_ok=False)
        atoms = read(xyz)
        types = np.asarray(atoms.arrays["lammps_type"], dtype=int)
        ids = np.asarray(atoms.arrays["lammps_id"], dtype=int)
        ia = int(np.flatnonzero(ids == spec["ids"][0])[0]); ib = int(np.flatnonzero(ids == spec["ids"][1])[0])
        u = atoms.positions[ia] - atoms.positions[ib]; u /= np.linalg.norm(u)
        data = target / "cluster.data"
        with data.open("w") as f:
            f.write("Ag-Ti-Si PBE scan cluster\n\n")
            f.write(f"{len(atoms)} atoms\n4 atom types\n\n0 28 xlo xhi\n0 28 ylo yhi\n0 28 zlo zhi\n\nMasses\n\n")
            for typ, mass in MASS.items(): f.write(f"{typ} {mass}\n")
            f.write("\nAtoms # atomic\n\n")
            for i, (typ, pos) in enumerate(zip(types, atoms.positions), 1): f.write(f"{i} {int(typ)} {pos[0]:.12f} {pos[1]:.12f} {pos[2]:.12f}\n")
        pbe = json.loads((xyz.parent / "summary.json").read_text())
        variants = {}
        forces = {}
        target_pair = spec["morse"]
        variants_to_run = (("calibration_v0", "all"), ("cross_terms_zero", "none"),
                           (f"{env}_cross_zero", "target"))
        for label, mode in variants_to_run:
            d = target / label; d.mkdir(); dump = d / "forces.dump"
            lines = ["units metal", "atom_style atomic", "boundary f f f", f"read_data {data}", "pair_style hybrid eam tersoff morse 8.0",
                     f"pair_coeff 4 4 eam {BASE}/potentials/Ag_u3.eam", f"pair_coeff * * tersoff {BASE}/potentials/TSCBOP.tersoff Ti Si C NULL"]
            for pair, (d0, alpha, r0) in MORSE.items():
                scale = 1.0 if mode == "all" or (mode == "target" and pair != target_pair) else 0.0
                lines.append(f"pair_coeff {pair[0]} {pair[1]} morse {d0*scale:.12g} {alpha:.12g} {r0:.12g} 8.0")
            lines += ["neighbor 2.0 bin", "neigh_modify every 1 delay 0 check yes", "variable fnorm atom sqrt(fx*fx+fy*fy+fz*fz)", "compute fmax all reduce max v_fnorm", "thermo 1", "thermo_style custom step atoms pe c_fmax", "thermo_modify flush yes lost error", f"dump f all custom 1 {dump} id type x y z fx fy fz", "dump_modify f sort id", "run 0", ""]
            inp = d / "in.run0"; inp.write_text("\n".join(lines)); log = d / "log.lammps"
            with (d / "run.stdout").open("w") as stdout: subprocess.run([str(LMP), "-in", str(inp), "-log", str(log)], cwd=d, check=True, stdout=stdout, stderr=subprocess.STDOUT)
            rows = np.loadtxt(dump, comments="#", skiprows=9); f = rows[:, 5:8]
            thermo = [line.split() for line in log.read_text().splitlines() if line.strip().startswith("0 ") and len(line.split()) == 4]
            variants[label] = {"PE_eV": float(thermo[-1][2]), "pair_separating_force_eV_A": float(np.dot(f[ia]-f[ib], u)), "Fmax_eV_A": float(np.linalg.norm(f, axis=1).max())}
            forces[label] = f
        cross = forces["calibration_v0"] - forces["cross_terms_zero"]
        target_cross = forces["calibration_v0"] - forces[f"{env}_cross_zero"]
        result = {"environment": env, "distance_A": float(np.linalg.norm(atoms.positions[ia]-atoms.positions[ib])),
                  "PBE": pbe, "calibration_v0": variants["calibration_v0"], "cross_terms_zero": variants["cross_terms_zero"],
                  f"{env}_cross_zero": variants[f"{env}_cross_zero"],
                  "Morse_cross_component_projection_eV_A": float(np.dot(cross[ia]-cross[ib], u)),
                  f"{env}_cross_component_projection_eV_A": float(np.dot(target_cross[ia]-target_cross[ib], u))}
        (target / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
        all_rows.append(result)
        pbe_force = pbe.get("pair_separating_force_eV_A", pbe.get("PBE_pair_separating_force_eV_per_A"))
        print(json.dumps({"env": env, "tag": tag, "PBE_pair_force": pbe_force,
                          "v0_pair_force": variants["calibration_v0"]["pair_separating_force_eV_A"]}), flush=True)
(OUT / "summary.json").write_text(json.dumps(all_rows, indent=2) + "\n")
