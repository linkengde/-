#!/usr/bin/env python3
import json, os, sys
from pathlib import Path
import numpy as np
import gpaw_data
from ase.io import read
os.environ['GPAW_SETUP_PATH']=str(gpaw_data.datapath())
from gpaw import GPAW
from gpaw.mixer import Mixer
from gpaw.occupations import FermiDirac
ROOT=Path(__file__).resolve().parent
if len(sys.argv)!=2: raise SystemExit('usage: run_pbe_point.py d2.3')
tag=sys.argv[1]; src=ROOT/'structures'/f'Ti_term_Ag111_periodic_{tag}.extxyz'
out=ROOT/'pbe'/tag; out.mkdir(parents=True,exist_ok=False)
a=read(src)
a.calc=GPAW(mode='lcao',basis='dzp',xc='PBE',kpts=(1,4,2),occupations=FermiDirac(.1),mixer=Mixer(.08,5,100),convergence={'energy':1e-4,'density':1e-4,'eigenstates':1e-4},maxiter=120,txt=str(out/'gpaw.log'))
e=float(a.get_potential_energy()); f=np.asarray(a.get_forces()); log=(out/'gpaw.log').read_text(errors='replace').lower()
if 'converged' not in log or 'failed to converge' in log: raise RuntimeError('PBE SCF convergence not confirmed')
np.savetxt(out/'forces.csv',np.column_stack((np.arange(1,len(a)+1),f)),delimiter=',',header='atom_index,fx_eV_A,fy_eV_A,fz_eV_A',comments='')
a.calc.write(out/'state.gpw')
n=np.linalg.norm(f,axis=1); sy=np.array(a.get_chemical_symbols())
r={'nominal_gap_A':float(tag[1:]),'atoms':len(a),'elements':{s:int(np.sum(sy==s)) for s in sorted(set(sy))},'cell_A':a.cell.array.tolist(),'energy_eV':e,'energy_eV_atom':e/len(a),'force_RMS_eV_A':float(np.sqrt(np.mean(f*f))),'Fmax_eV_A':float(n.max()),'Fmax_atom_index':int(n.argmax()+1),'Fmax_element':str(sy[n.argmax()]),'status':'periodic_PBE_fixed_cell_static_converged','caveat':'TSC geometry is derived from model frozen-layer motif; Ag film is laterally strained by about 5 percent.'}
(out/'summary.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
