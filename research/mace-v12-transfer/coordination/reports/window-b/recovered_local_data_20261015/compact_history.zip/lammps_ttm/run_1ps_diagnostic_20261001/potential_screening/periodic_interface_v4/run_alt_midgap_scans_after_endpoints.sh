#!/usr/bin/env bash
set -u

endpoint_pid="${1:?pass the active endpoint gap-scan queue PID}"
root="/workspace/.local/lammps-ttm/run_1ps_diagnostic_20261001/potential_screening/periodic_interface_v4"
python="/workspace/.local/venvs/gpaw/bin/python"
endpoint_log="$root/alt_gap_scan_serial_launcher.log"
mid_log="$root/alt_midgap_scan_serial_launcher.log"

while :; do
  if rg -q 'All Si/C gap scans completed and converged\.' "$endpoint_log" 2>/dev/null; then
    break
  fi
  if rg -q 'STOP:' "$endpoint_log" 2>/dev/null; then
    echo "STOP: endpoint Si/C gap scan failed; intermediate scans were not launched." >> "$mid_log"
    exit 1
  fi
  if ! kill -0 "$endpoint_pid" 2>/dev/null; then
    echo "STOP: endpoint gap-scan queue ended without a completion marker." >> "$mid_log"
    exit 1
  fi
  sleep 20
done

echo "Endpoint gap scans converged; starting intermediate 2.4/2.8 A scans." >> "$mid_log"
for element in Si C; do
  for gap in 2.4 2.8; do
    label="${element}_midgap_scan"
    stdout="$root/alt_midgap_scan_${element}_d${gap}.stdout"
    "$python" -u "$root/run_one_interface_pbe.py" "$gap" "$label" \
      structures_alt_terminations_gap_scan_mid "Ag_${element}_terminated" > "$stdout" 2>&1
    status=$?
    if [[ "$status" -ne 0 ]]; then
      echo "STOP: ${element} gap ${gap} A PBE calculation ended with status $status." >> "$mid_log"
      exit "$status"
    fi
    echo "${element} gap ${gap} A PBE calculation converged." >> "$mid_log"
  done
done
echo "All intermediate Si/C gap scans completed and converged." >> "$mid_log"
