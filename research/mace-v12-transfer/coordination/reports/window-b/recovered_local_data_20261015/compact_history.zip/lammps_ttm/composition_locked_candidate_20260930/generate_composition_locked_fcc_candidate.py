#!/usr/bin/env python3
"""Rebuild Ag as FCC while retaining target composition and fixed TSC scaffold."""
from pathlib import Path
import hashlib
import json
import shutil

import numpy as np
from scipy.spatial import cKDTree


ROOT = Path(__file__).resolve().parent
SRC_DIR = Path('/workspace/.local/lammps-ttm/run-upload-20260930')
SRC = SRC_DIR / 'stage65_model_150x300x300.data'
OUT = ROOT / 'stage65_model_fcc_ag_59p8775wt_candidate.data'
BOX = np.array([150.1, 300.0, 300.0])
REPEATS = np.array([37, 73, 73])
PHASE = np.array([0.25, 0.0, 0.25])
TARGET_AG = 212_904
MORSE_R0 = {1: 2.33708864, 2: 2.40407837, 3: 2.15255924}
MIN_CROSS = {t: r + 0.05 for t, r in MORSE_R0.items()}
MASSES = {1: 47.867, 2: 28.0855, 3: 12.0107, 4: 107.8682}


def read_atoms(path):
    rows = []
    in_atoms = False
    for line in path.open():
        if line.startswith('Atoms #'):
            in_atoms = True
            continue
        if not in_atoms:
            continue
        fields = line.split()
        if len(fields) < 5:
            continue
        try:
            rows.append((int(fields[0]), int(fields[1]), *map(float, fields[2:5])))
        except ValueError:
            break
    return np.asarray(rows, dtype=float)


source_rows = read_atoms(SRC)
source_ids = source_rows[:, 0].astype(np.int64)
source_types = source_rows[:, 1].astype(np.int64)
source_xyz = source_rows[:, 2:5]
scaffold_mask = source_types != 4
scaffold_rows = source_rows[scaffold_mask]
scaffold_xyz = source_xyz[scaffold_mask]
old_ag = source_xyz[source_types == 4]
source_counts = {int(t): int(np.count_nonzero(source_types == t)) for t in (1, 2, 3, 4)}

assert len(source_rows) == 682_587
assert len(scaffold_rows) == 469_683
assert len(old_ag) == TARGET_AG

lat = BOX / REPEATS
ii, jj, kk = np.indices(tuple(REPEATS))
base = np.stack((ii.ravel() * lat[0], jj.ravel() * lat[1], kk.ravel() * lat[2]), axis=1)
basis = np.array([[0, 0, 0], [0, 0.5, 0.5], [0.5, 0, 0.5], [0.5, 0.5, 0]])
points = (base[:, None, :] + lat * (PHASE[None, None, :] + basis[None, :, :])).reshape(-1, 3) % BOX

# Only place Ag at FCC sites outside the geometric clearance of every scaffold type.
clearances = {}
eligible = np.ones(len(points), dtype=bool)
for atom_type, cutoff in MIN_CROSS.items():
    distances, _ = cKDTree(source_xyz[source_types == atom_type], boxsize=BOX).query(points, workers=-1)
    clearances[atom_type] = distances
    eligible &= distances >= cutoff - 1e-10

# Expand outward from the original Ag-filled region only as much as required to
# retain the target Ag count after eliminating incompatible contacts.
old_ag_distance, _ = cKDTree(old_ag, boxsize=BOX).query(points, workers=-1)
available_indices = np.flatnonzero(eligible)
if len(available_indices) < TARGET_AG:
    raise RuntimeError(f'Only {len(available_indices)} clearance-safe FCC sites; need {TARGET_AG}')
ranking = np.argsort(old_ag_distance[available_indices], kind='stable')
chosen = available_indices[ranking[:TARGET_AG]]
ag_xyz = points[chosen]
mask_dilation = float(old_ag_distance[chosen].max())

ids = np.arange(int(source_ids.max()) + 1, int(source_ids.max()) + TARGET_AG + 1, dtype=np.int64)
out_ids = np.concatenate((scaffold_rows[:, 0].astype(np.int64), ids))
out_types = np.concatenate((scaffold_rows[:, 1].astype(np.int64), np.full(TARGET_AG, 4, dtype=np.int64)))
out_xyz = np.vstack((scaffold_rows[:, 2:5], ag_xyz))
order = np.argsort(out_ids)
out_ids, out_types, out_xyz = out_ids[order], out_types[order], out_xyz[order]

with OUT.open('w') as f:
    f.write('LAMMPS data: FCC Ag, target mass fraction 59.8775 wt%; TSC scaffold coordinates retained\n\n')
    f.write(f'{len(out_ids)} atoms\n4 atom types\n\n')
    f.write(f'0 {BOX[0]:.10f} xlo xhi\n0 {BOX[1]:.10f} ylo yhi\n0 {BOX[2]:.10f} zlo zhi\n\n')
    f.write('Masses\n\n')
    for t in (1, 2, 3, 4):
        f.write(f'{t} {MASSES[t]:.7f}\n')
    f.write('\nAtoms # atomic\n\n')
    for aid, atom_type, xyz in zip(out_ids, out_types, out_xyz):
        f.write(f'{aid:d} {atom_type:d} {xyz[0]:.12f} {xyz[1]:.12f} {xyz[2]:.12f}\n')

# Independent geometry and composition audit values for the report.
ag_tree = cKDTree(ag_xyz, boxsize=BOX)
ag_nn = ag_tree.query(ag_xyz, k=2, workers=-1)[0][:, 1]
out_counts = {int(t): int(np.count_nonzero(out_types == t)) for t in (1, 2, 3, 4)}
matrix_mass = sum(out_counts[t] * MASSES[t] for t in (1, 2, 3))
ag_mass = out_counts[4] * MASSES[4]
wt_pct = 100 * ag_mass / (matrix_mass + ag_mass)
scaffold_xyz_out = out_xyz[out_types != 4]
scaffold_rows_out = out_ids[out_types != 4]
source_scaffold_order = np.argsort(scaffold_rows[:, 0])
out_scaffold_order = np.argsort(scaffold_rows_out)
max_scaffold_delta = float(np.max(np.abs(
    scaffold_xyz_out[out_scaffold_order] - scaffold_rows[source_scaffold_order, 2:5]
)))

summary = {
    'source_data': str(SRC),
    'source_sha256': hashlib.sha256(SRC.read_bytes()).hexdigest(),
    'candidate_data': OUT.name,
    'source_type_counts': {str(k): v for k, v in source_counts.items()},
    'candidate_type_counts': {str(k): v for k, v in out_counts.items()},
    'candidate_total_atoms': int(len(out_ids)),
    'atomic_masses_u': {str(k): v for k, v in MASSES.items()},
    'Ag_mass_fraction_wt_percent': wt_pct,
    'Ag_mass_fraction_round_4dp': round(wt_pct, 4),
    'skeleton_atom_ids_types_and_coordinates_preserved': max_scaffold_delta == 0.0,
    'maximum_skeleton_coordinate_delta_A': max_scaffold_delta,
    'box_A': BOX.tolist(),
    'fcc_repeat_counts': REPEATS.tolist(),
    'fcc_cell_dimensions_A': lat.tolist(),
    'Ag_EAM_reference_lattice_A': 4.09,
    'fcc_axis_strain_vs_Ag_EAM_percent': ((lat / 4.09 - 1) * 100).tolist(),
    'Ag_fill_expansion_from_original_sites_A': mask_dilation,
    'Ag_scaffold_minimum_distances_A': {
        str(t): float(clearances[t][chosen].min()) for t in (1, 2, 3)
    },
    'Ag_scaffold_minimum_required_distances_A': {str(t): v for t, v in MIN_CROSS.items()},
    'Ag_Ag_nearest_neighbor_min_A': float(ag_nn.min()),
    'Ag_Ag_nearest_neighbor_median_A': float(np.median(ag_nn)),
    'note': 'Geometry candidate only; inherited cross-interface Morse parameters remain calibration v0.'
}
(ROOT / 'composition_geometry_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
(ROOT / 'candidate_SHA256.txt').write_text(
    f"{hashlib.sha256(OUT.read_bytes()).hexdigest()}  {OUT.name}\n"
)
print(json.dumps(summary, indent=2))
