#!/usr/bin/env python3
"""FCC Ag infill with type-specific separation from the fixed Ti3SiC2 scaffold."""
from pathlib import Path
import hashlib, json, shutil
import numpy as np
from scipy.spatial import cKDTree

SRC=Path('/workspace/.local/lammps-ttm/run-upload-20260930/stage65_model_150x300x300.data')
SRC_DIR=SRC.parent; OUT=Path(__file__).resolve().parent
OUT_DATA=OUT/'stage65_model_fcc_ag_interface_clearance.data'
BOX=np.array([150.1,300.0,300.0]); MASK_RADIUS_A=2.2; MARGIN_A=0.05
PHASE=np.array([0.25,0.0,0.25])
MORSE_R0={1:2.33708864,2:2.40407837,3:2.15255924}
THRESH={t:r+MARGIN_A for t,r in MORSE_R0.items()}
rows=[];inside=False
for line in SRC.open():
    if line.startswith('Atoms #'):inside=True;continue
    if inside:
        q=line.split()
        if len(q)<5:continue
        try:rows.append((int(q[0]),int(q[1]),*map(float,q[2:5])))
        except ValueError:break
A=np.asarray(rows,float); ids=A[:,0].astype(np.int64); types=A[:,1].astype(np.int64); xyz=A[:,2:5]
back=types!=4; skeleton=xyz[back];ag_old=xyz[types==4];sc_rows=A[back]
assert len(A)==682587 and len(skeleton)==469683 and len(ag_old)==212904

lat=BOX/np.array([37.,74.,74.]);I,J,K=np.indices((37,74,74))
base=np.stack((I.ravel()*lat[0],J.ravel()*lat[1],K.ravel()*lat[2]),axis=1)
basis=np.array([[0,0,0],[0,.5,.5],[.5,0,.5],[.5,.5,0]])
points=(base[:,None,:]+lat*(PHASE[None,None,:]+basis[None,:,:])).reshape(-1,3)%BOX
maskd,_=cKDTree(ag_old,boxsize=BOX).query(points,workers=-1)
keep=maskd<=MASK_RADIUS_A
clearance_by_type={}
for t,cut in THRESH.items():
    d,_=cKDTree(xyz[types==t],boxsize=BOX).query(points,workers=-1)
    clearance_by_type[t]=d
    keep &= d>=cut
ag_new=points[keep]
assert len(ag_new)>50000

new_ids=np.arange(int(ids.max())+1,int(ids.max())+len(ag_new)+1,dtype=np.int64)
out_ids=np.r_[sc_rows[:,0].astype(np.int64),new_ids]
out_types=np.r_[sc_rows[:,1].astype(np.int64),np.full(len(ag_new),4,dtype=np.int64)]
out_xyz=np.vstack((sc_rows[:,2:5],ag_new));order=np.argsort(out_ids)
out_ids=out_ids[order];out_types=out_types[order];out_xyz=out_xyz[order]
with OUT_DATA.open('w') as f:
    f.write('LAMMPS data: FCC Ag infill with type-specific interface clearance; Ti/Si/C copied exactly\n\n')
    f.write(f'{len(out_ids)} atoms\n4 atom types\n\n')
    f.write(f'0 {BOX[0]:.10f} xlo xhi\n0 {BOX[1]:.10f} ylo yhi\n0 {BOX[2]:.10f} zlo zhi\n\n')
    f.write('Masses\n\n1 47.867\n2 28.0855\n3 12.0107\n4 107.87\n\nAtoms # atomic\n\n')
    for aid,typ,r in zip(out_ids,out_types,out_xyz):f.write(f'{aid:d} {typ:d} {r[0]:.12f} {r[1]:.12f} {r[2]:.12f}\n')
shutil.copy2(SRC_DIR/'potential.interface_calibration_v0.inc',OUT/'potential.interface_calibration_v0.inc')
for name in ['Ag_u3.eam','TSCBOP.tersoff']:shutil.copy2(SRC_DIR/'potentials'/name,OUT/'potentials'/name)
at=cKDTree(ag_new,boxsize=BOX);nn,_=at.query(ag_new,k=2,workers=-1)
summary={'source':str(SRC),'source_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),'candidate_data':OUT_DATA.name,
 'source_atoms':len(A),'candidate_atoms':len(out_ids),'source_type_counts':{str(t):int((types==t).sum()) for t in [1,2,3,4]},
 'candidate_type_counts':{str(t):int((out_types==t).sum()) for t in [1,2,3,4]},'skeleton_coordinates_copied_verbatim':True,
 'box_A':BOX.tolist(),'Ag_EAM_reference_a_A':4.09,'candidate_fcc_lattice_A':lat.tolist(),'strain_vs_Ag_EAM':(lat/4.09-1).tolist(),
 'selected_fcc_phase':PHASE.tolist(),'original_Ag_mask_dilation_A':MASK_RADIUS_A,'Morse_r0_A':{str(t):r for t,r in MORSE_R0.items()},
 'Ag_to_skeleton_minimum_threshold_A':{str(t):d for t,d in THRESH.items()},
 'Ag_to_skeleton_observed_minimum_A':{str(t):float(clearance_by_type[t][keep].min()) for t in [1,2,3]},
 'FCC_Ag_nearest_neighbor_minimum_A':float(nn[:,1].min()),'FCC_Ag_nearest_neighbor_median_A':float(np.median(nn[:,1])),
 'Ag_sites_within_dilated_mask_before_clearance':int((maskd<=MASK_RADIUS_A).sum()),'Ag_sites_after_clearance':int(keep.sum()),
 'cross_potential_status':'Inherited single-interface calibration v0; still not validated as a production potential.',
 'scope':'Static candidate. LAMMPS/TTM validation below uses run 0 only; no additional MD steps.'}
(OUT/'interface_clearance_geometry_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
