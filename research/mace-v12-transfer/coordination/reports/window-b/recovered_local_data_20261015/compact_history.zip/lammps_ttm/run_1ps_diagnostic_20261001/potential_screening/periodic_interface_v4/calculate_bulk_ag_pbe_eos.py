#!/usr/bin/env python3
"""Small plane-wave PBE equation of state for fcc Ag, to quantify interface strain."""
from pathlib import Path
import json
import os

import gpaw_data
import numpy as np
from ase.build import bulk
from ase.eos import EquationOfState

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "bulk_ag_pbe_eos"
OUT.mkdir(exist_ok=False)
os.environ["GPAW_SETUP_PATH"] = str(gpaw_data.datapath())
from gpaw import GPAW, PW  # noqa: E402
from gpaw.mixer import Mixer  # noqa: E402
from gpaw.occupations import FermiDirac  # noqa: E402

lattice_constants = np.asarray([3.98, 4.04, 4.10, 4.16, 4.22])
volumes, energies = [], []
records = []
for a0 in lattice_constants:
    atoms = bulk("Ag", "fcc", a=float(a0), cubic=True)
    atoms.calc = GPAW(
        mode=PW(500),
        xc="PBE",
        kpts=(6, 6, 6),
        occupations=FermiDirac(0.1),
        mixer=Mixer(0.1, 5, 100),
        convergence={"energy": 1e-5, "density": 1e-5, "eigenstates": 1e-5},
        maxiter=120,
        txt=str(OUT / f"gpaw_a{a0:.2f}.log"),
    )
    energy = float(atoms.get_potential_energy())
    volumes.append(float(atoms.get_volume()))
    energies.append(energy)
    records.append({"a_A": float(a0), "volume_A3": float(atoms.get_volume()), "energy_eV_cell": energy, "atoms": len(atoms)})
    print(json.dumps(records[-1]), flush=True)

eos = EquationOfState(volumes, energies, eos="birchmurnaghan")
v0, e0, B = eos.fit()
a0_pbe = float(v0 ** (1.0 / 3.0))
result = {
    "status": "PBE_EOS_FIT",
    "xc": "PBE",
    "basis": "plane wave",
    "cutoff_eV": 500,
    "kpts": [6, 6, 6],
    "scf_thresholds": "1e-5",
    "lattice_points": records,
    "equilibrium_cubic_a_A": a0_pbe,
    "equilibrium_volume_A3_cell": float(v0),
    "equilibrium_energy_eV_cell": float(e0),
    "bulk_modulus_eV_A3": float(B),
    "bulk_modulus_GPa": float(B * 160.21766208),
    "screen_substrate_b_A": 3.0777657856,
    "screen_substrate_c_A": 5.3325594490,
    "screening_misfit_percent_to_rectangular_Ag111": [
        100 * (3.0777657856 / (a0_pbe / np.sqrt(2.0)) - 1),
        100 * (5.3325594490 / (a0_pbe * np.sqrt(3.0 / 2.0)) - 1),
    ],
    "note": "Bulk PBE EOS is used to replace the experimental Ag lattice-parameter assumption in the strain audit; the EOS fit is based on a finite five-point grid and is not yet k-point/cutoff convergence tested.",
}
(OUT / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2), flush=True)
