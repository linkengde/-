from pathlib import Path

import numpy as np
from ase import Atoms
from ase.io import write

ROOT = Path(__file__).resolve().parent
SOURCES = {
    "step0": Path(
        "/workspace/.local/lammps-ttm/run_1ps_diagnostic_20261001/"
        "cause_attribution_step0/dumps/conservative_step0.dump"
    ),
    "step1000": Path(
        "/workspace/.local/lammps-ttm/run_1ps_diagnostic_20261001/"
        "cause_attribution_step1000/dumps/conservative_only.dump"
    ),
}
BOX = np.array([150.1, 300.0, 300.0])
PAIR_IDS = (520183, 520177)
RADIUS = 6.0
CELL = np.eye(3) * 28.0
CELL_CENTER = np.array([14.0, 14.0, 14.0])
SYMBOL = {1: "Ti", 2: "Si", 3: "C", 4: "Ag"}


def read_dump(path):
    rows = []
    in_atoms = False
    with path.open() as stream:
        for line in stream:
            if line.startswith("ITEM: ATOMS"):
                in_atoms = True
                continue
            if not in_atoms:
                continue
            fields = line.split()
            if len(fields) < 5:
                continue
            rows.append(
                (
                    int(fields[0]),
                    int(fields[1]),
                    float(fields[2]),
                    float(fields[3]),
                    float(fields[4]),
                )
            )
    data = np.asarray(rows)
    return data[:, 0].astype(np.int64), data[:, 1].astype(np.int64), data[:, 2:5]


frames = {}
selected = set()
pair_coords = {}
for label, path in SOURCES.items():
    ids, types, xyz = read_dump(path)
    index = {int(atom_id): i for i, atom_id in enumerate(ids)}
    ia, ib = (index[i] for i in PAIR_IDS)
    delta = xyz[ib] - xyz[ia]
    delta -= BOX * np.rint(delta / BOX)
    center = (xyz[ia] + 0.5 * delta) % BOX
    relative = xyz - center
    relative -= BOX * np.rint(relative / BOX)
    chosen = np.linalg.norm(relative, axis=1) <= RADIUS
    selected.update(int(i) for i in ids[chosen])
    frames[label] = (ids, types, xyz)
    pair_coords[label] = (xyz[ia].copy(), xyz[ib].copy(), delta.copy())

selected = np.asarray(sorted(selected), dtype=np.int64)
index = {int(atom_id): i for i, atom_id in enumerate(frames["step0"][0])}
types0 = np.asarray([frames["step0"][1][index[int(i)]] for i in selected])

for label, (ids, types, xyz) in frames.items():
    index = {int(atom_id): i for i, atom_id in enumerate(ids)}
    type_now = np.asarray([types[index[int(i)]] for i in selected])
    if not np.array_equal(type_now, types0):
        raise RuntimeError("Atom types changed between diagnostic frames")
    a, b, delta = pair_coords[label]
    center = (a + 0.5 * delta) % BOX
    rel = xyz[[index[int(i)] for i in selected]] - center
    rel -= BOX * np.rint(rel / BOX)
    positions = rel + CELL_CENTER
    symbols = [SYMBOL[int(t)] for t in types0]
    atoms = Atoms(symbols, positions=positions, cell=CELL, pbc=False)
    atoms.new_array("lammps_id", selected)
    atoms.new_array("lammps_type", types0)
    atoms.new_array("central_pair", np.isin(selected, PAIR_IDS).astype(np.int32))
    path = ROOT / f"c_pair_{label}_R{int(RADIUS)}.extxyz"
    write(path, atoms, format="extxyz")
    print(
        f"{label}: atoms={len(atoms)} types="
        f"{dict(zip(*np.unique(types0, return_counts=True)))} "
        f"Cpair_distance={np.linalg.norm(delta):.6f} A -> {path}"
    )
