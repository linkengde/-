#!/usr/bin/env python3
"""Static PBE Ag-C distance scans in two independently selected candidate environments."""
from pathlib import Path
import csv
import json
import os
import sys

import numpy as np
import gpaw_data
from ase.io import read, write

os.environ["GPAW_SETUP_PATH"] = str(gpaw_data.datapath())
from gpaw import GPAW
from gpaw.mixer import Mixer
from gpaw.occupations import FermiDirac

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "AgC_environment_distance_scans_PBE_v1"
TARGETS = (2.0, 2.4)  # Angstrom; the converged parent snapshots are at ~2.2026 A.
ENVIRONMENTS = {
    "primary": {
        "atoms": ROOT / "candidate_Ag_C_R6.extxyz",
        "restart": ROOT / "pbe/Ag_C/state.gpw",
        "ag_id": 732149,
        "c_id": 197404,
        "base_distance_A": 2.202560950462983,
    },
    "secondary": {
        "atoms": ROOT / "AgC_secondary/candidate_Ag_C_R6.extxyz",
        "restart": ROOT / "AgC_secondary/pbe/state.gpw",
        "ag_id": 688433,
        "c_id": 604804,
        "base_distance_A": 2.202603164364853,
    },
}

env_name = sys.argv[1]
if env_name not in ENVIRONMENTS:
    raise SystemExit("usage: run_agc_environment_pbe_scan.py primary|secondary")
spec = ENVIRONMENTS[env_name]
env_out = OUT / env_name
env_out.mkdir(parents=True, exist_ok=True)
ids_written = []
rows = []

for target_distance in TARGETS:
    tag = f"d{target_distance:.1f}"
    calc_dir = env_out / tag
    calc_dir.mkdir(exist_ok=False)
    atoms = read(spec["atoms"])
    ids = np.asarray(atoms.arrays["lammps_id"], dtype=int)
    ia = int(np.flatnonzero(ids == spec["ag_id"])[0])
    ic = int(np.flatnonzero(ids == spec["c_id"])[0])
    original_ag = atoms.positions[ia].copy()
    original_c = atoms.positions[ic].copy()
    midpoint = 0.5 * (original_ag + original_c)
    direction = original_ag - original_c
    direction /= np.linalg.norm(direction)
    atoms.positions[ia] = midpoint + 0.5 * target_distance * direction
    atoms.positions[ic] = midpoint - 0.5 * target_distance * direction
    write(calc_dir / "input.extxyz", atoms, format="extxyz")

    atoms.calc = GPAW(
        str(spec["restart"]),
        maxiter=120,
        txt=str(calc_dir / "gpaw.log"),
    )
    energy = float(atoms.get_potential_energy())
    forces = np.asarray(atoms.get_forces())
    separation_force = float(np.dot(forces[ia] - forces[ic], direction))
    norms = np.linalg.norm(forces, axis=1)
    with (calc_dir / "forces.csv").open("w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["lammps_id", "symbol", "x_A", "y_A", "z_A", "fx_eV_A", "fy_eV_A", "fz_eV_A", "force_norm_eV_A"])
        for i, (aid, pos, force, norm) in enumerate(zip(ids, atoms.positions, forces, norms)):
            writer.writerow([int(aid), atoms[i].symbol, *map(float, pos), *map(float, force), float(norm)])
    row = {
        "environment": env_name,
        "Ag_id": spec["ag_id"],
        "C_id": spec["c_id"],
        "target_distance_A": target_distance,
        "calculated_distance_A": float(np.linalg.norm(atoms.positions[ia] - atoms.positions[ic])),
        "PBE_energy_eV": energy,
        "Ag_C_separating_force_eV_A": separation_force,
        "max_force_eV_A": float(norms.max()),
        "max_force_id": int(ids[int(norms.argmax())]),
    }
    (calc_dir / "summary.json").write_text(json.dumps(row, indent=2) + "\n")
    rows.append(row)
    ids_written.append(tag)
    print(json.dumps(row), flush=True)

with (env_out / "summary.csv").open("w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=rows[0].keys())
    writer.writeheader()
    writer.writerows(rows)
print(f"completed {env_name}: {', '.join(ids_written)}", flush=True)
