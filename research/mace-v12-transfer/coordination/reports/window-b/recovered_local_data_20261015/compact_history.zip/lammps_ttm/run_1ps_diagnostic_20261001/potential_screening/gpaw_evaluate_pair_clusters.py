from pathlib import Path
import csv
import os

import numpy as np
from ase.io import read
import gpaw_data

os.environ["GPAW_SETUP_PATH"] = str(gpaw_data.datapath())

from gpaw import GPAW
from gpaw.mixer import Mixer
from gpaw.occupations import FermiDirac

ROOT = Path(__file__).resolve().parent
PAIR_IDS = (520183, 520177)
summary = []

for frame in ("step1000",):
    atoms = read(ROOT / f"c_pair_{frame}_R6.extxyz")
    calc_dir = ROOT / f"gpaw_{frame}_R6_restart"
    calc_dir.mkdir(exist_ok=True)
    if frame == "step1000":
        atoms.calc = GPAW(
            str(ROOT / "gpaw_step0_R6" / "state.gpw"),
            maxiter=120,
            txt=str(calc_dir / "gpaw.log"),
        )
    else:
        atoms.calc = GPAW(
            mode="lcao",
            basis="dzp",
            xc="PBE",
            occupations=FermiDirac(0.1),
            mixer=Mixer(beta=0.05, nmaxold=8, weight=100.0),
            convergence={"energy": 1e-4, "density": 1e-4, "eigenstates": 1e-4},
            maxiter=120,
            txt=str(calc_dir / "gpaw.log"),
        )
    energy = atoms.get_potential_energy()
    forces = atoms.get_forces()
    ids = atoms.arrays["lammps_id"]
    ia = int(np.flatnonzero(ids == PAIR_IDS[0])[0])
    ib = int(np.flatnonzero(ids == PAIR_IDS[1])[0])
    vec = atoms.positions[ib] - atoms.positions[ia]
    distance = np.linalg.norm(vec)
    separating = float(np.dot(forces[ib] - forces[ia], vec / distance))
    force_norms = np.linalg.norm(forces, axis=1)
    row = {
        "frame": frame,
        "atoms": len(atoms),
        "xc": "PBE",
        "basis": "dzp",
        "GPAW_energy_eV": energy,
        "C_pair_distance_A": distance,
        "C_pair_separating_force_eV_per_A": separating,
        "C520183_force_norm_eV_per_A": force_norms[ia],
        "C520177_force_norm_eV_per_A": force_norms[ib],
        "max_force_norm_eV_per_A": force_norms.max(),
        "max_force_lammps_id": int(ids[int(force_norms.argmax())]),
    }
    summary.append(row)
    with (calc_dir / "forces.csv").open("w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(
            ["lammps_id", "type", "symbol", "x_A", "y_A", "z_A", "fx_eV_A", "fy_eV_A", "fz_eV_A", "force_norm_eV_A"]
        )
        for i, (aid, typ, pos, force, norm) in enumerate(
            zip(ids, atoms.arrays["lammps_type"], atoms.positions, forces, force_norms)
        ):
            writer.writerow([int(aid), int(typ), atoms[i].symbol, *map(float, pos), *map(float, force), float(norm)])
    atoms.calc.write(str(calc_dir / "state.gpw"), mode="all")
    print(row, flush=True)

with (ROOT / "gpaw_pair_summary.csv").open("w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=summary[0].keys())
    writer.writeheader()
    writer.writerows(summary)
