from pathlib import Path
import csv, json
import numpy as np

root = Path(__file__).resolve().parent
run = root / 'mace_periodic_v5'
eval_dir = run / 'evaluation_retry2'
data = json.loads((eval_dir / 'summary.json').read_text())['records']
model = 'finetuned_v5'
train = [r for r in data if r['split'] == 'train']
test = [r for r in data if r['split'] == 'test']
valid = [r for r in data if r['split'] == 'valid']

def cell_err(r):
    return r[f'{model}_energy_error_eV_atom'] * r['atoms']

# Calibrate only a constant energy offset for each contact/composition family
# using training rows; this does not alter forces.
offsets = {}
for contact in sorted(set(r['contact'] for r in train)):
    rows = [r for r in train if r['contact'] == contact]
    offsets[contact] = float(np.mean([cell_err(r) for r in rows]))
calibrated = []
for r in test:
    residual = cell_err(r) - offsets[r['contact']]
    calibrated.append({'config_type': r['config_type'], 'contact': r['contact'],
                       'train_only_mean_energy_bias_eV_cell': offsets[r['contact']],
                       'raw_energy_error_eV_cell': cell_err(r),
                       'raw_energy_error_eV_atom': r[f'{model}_energy_error_eV_atom'],
                       'offset_corrected_energy_error_eV_cell': residual,
                       'offset_corrected_energy_error_eV_atom': residual / r['atoms']})

def get(contact, gap, split=None):
    name = f'{contact}_gap_{gap.replace(".", "p")}'
    hits = [r for r in data if r['config_type'] == name and (split is None or r['split'] == split)]
    if len(hits) != 1:
        raise RuntimeError(f'{name} split={split} hits={len(hits)}')
    return hits[0]

profiles = []
for contact in ('Si', 'C'):
    for gap_a, split_a, gap_b, split_b, label in [
        ('2.4', 'train', '2.3', 'valid', 'short_gap_holdout'),
        ('2.8', 'train', '2.9', 'test', 'long_gap_holdout'),
    ]:
        a, b = get(contact, gap_a, split_a), get(contact, gap_b, split_b)
        ref_delta = b['reference_energy_eV_cell'] - a['reference_energy_eV_cell']
        pred_delta = (b['reference_energy_eV_cell'] + cell_err(b)) - (a['reference_energy_eV_cell'] + cell_err(a))
        profiles.append({'contact': contact, 'comparison': label,
                         'reference_gap_A': float(gap_a), 'target_gap_A': float(gap_b),
                         'reference_split': split_a, 'target_split': split_b,
                         'DFT_delta_energy_eV_cell': float(ref_delta),
                         'MACE_delta_energy_eV_cell': float(pred_delta),
                         'delta_energy_error_eV_cell': float(pred_delta - ref_delta),
                         'delta_energy_error_eV_atom': float((pred_delta - ref_delta)/b['atoms'])})

summary = {
    'note': 'Composition/contact-specific constant energy bias estimated from TRAIN rows only. It changes energy reference only and does not change forces or trajectories.',
    'train_only_mean_energy_bias_eV_cell_by_contact': offsets,
    'raw_test_energy_MAE_eV_atom': float(np.mean([abs(r[f'{model}_energy_error_eV_atom']) for r in test])),
    'train_offset_corrected_test_energy_MAE_eV_atom': float(np.mean([abs(x['offset_corrected_energy_error_eV_atom']) for x in calibrated])),
    'offset_corrected_test_records': calibrated,
    'heldout_relative_energy_profile_checks': profiles,
    'limitations': [
        'The calibration is a diagnostic only and does not modify the MACE model.',
        'Only two held-out contact structures are available, one per termination.',
        'These checks test fixed-composition gap dependence within the constructed cells, not transfer to liquid Ag or production geometry.'
    ]
}
(eval_dir / 'energy_profile_analysis.json').write_text(json.dumps(summary, indent=2) + '\n')
with (eval_dir / 'energy_profile_analysis.csv').open('w', newline='') as f:
    rows = calibrated + profiles
    fields = list(dict.fromkeys(k for r in rows for k in r))
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader(); w.writerows(rows)
print(json.dumps({k: summary[k] for k in ['raw_test_energy_MAE_eV_atom', 'train_offset_corrected_test_energy_MAE_eV_atom', 'offset_corrected_test_records', 'heldout_relative_energy_profile_checks']}, indent=2))
