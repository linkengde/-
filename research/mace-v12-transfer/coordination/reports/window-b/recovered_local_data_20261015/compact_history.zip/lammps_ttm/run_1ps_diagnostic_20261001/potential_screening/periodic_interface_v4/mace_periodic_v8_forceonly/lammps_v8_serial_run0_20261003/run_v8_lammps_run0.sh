#!/usr/bin/env bash
set -euo pipefail
cd /workspace/.local/lammps-ttm/run_1ps_diagnostic_20261001/potential_screening/periodic_interface_v4/mace_periodic_v8_forceonly/lammps_v8_serial_run0_20261003
export PYTHONPATH=/workspace/.local/src/lammps-mace-source/python:/workspace/.local/venvs/mace/lib/python3.12/site-packages:/workspace/.local/lammps-ttm/run_1ps_diagnostic_20261001/potential_screening/lammps_mace_integration
export LD_LIBRARY_PATH=/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib:/workspace/.local/venvs/mace/lib:/workspace/.local/venvs/mace/lib/python3.12/site-packages/torch/lib
if [[ -e log.mace_v8_run0_serial ]]; then echo 'Refusing to overwrite existing log'; exit 2; fi
/workspace/.local/lammps-ttm/build_mace_v6_serial/lmp -in in.run0 -log log.mace_v8_run0_serial
