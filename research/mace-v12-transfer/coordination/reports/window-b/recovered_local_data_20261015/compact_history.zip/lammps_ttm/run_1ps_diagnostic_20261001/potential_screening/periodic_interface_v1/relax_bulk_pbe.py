#!/usr/bin/env python3
"""Relax model-derived Ti3SiC2 unit cell with periodic PBE, preserving orthorhombic axes."""
from pathlib import Path
import json, os
import numpy as np
import gpaw_data
from ase.io import read,write
from ase.optimize import BFGS
from gpaw.mixer import Mixer
os.environ['GPAW_SETUP_PATH']=str(gpaw_data.datapath())
from gpaw import GPAW
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'bulk_pre_relax_pbe_loose_v4';OUT.mkdir(exist_ok=False)
a=read(ROOT/'structures/Ti3SiC2_bulk_orthorhombic.extxyz')
restart=GPAW(str(ROOT/'bulk_reference/state.gpw'),legacy_gpaw=True,txt=None)
calc=restart.new(txt=str(OUT/'gpaw_relax.log'),mixer=Mixer(.15,5,100),
    convergence={'energy':1e-3,'density':1e-3,'eigenstates':1e-3},maxiter=50)
a.calc=calc
opt=BFGS(a,trajectory=str(OUT/'relax.traj'),logfile=str(OUT/'opt.log'),maxstep=.12)
converged=opt.run(fmax=.1,steps=40)
f=np.asarray(a.get_forces());e=float(a.get_potential_energy());norm=np.linalg.norm(f,axis=1)
write(OUT/'Ti3SiC2_relaxed.extxyz',a,format='extxyz')
a.calc.write(OUT/'state.gpw')
r={'optimizer_converged':bool(converged),'atoms':len(a),'cell_A':a.cell.array.tolist(),'energy_eV':e,'energy_eV_atom':e/len(a),'max_atomic_force_eV_A':float(norm.max()),'force_RMS_eV_A':float(np.sqrt(np.mean(f*f))),'optimizer_steps':sum(1 for _ in open(OUT/'opt.log'))-1,'electronic_convergence':'1e-3 eV/electron loose geometry-search stage; must be checked by a strict 1e-4 PBE static run','note':'PBE atomic-position relaxation at fixed orthorhombic cell; lattice motif initialized from supplied model. This is a first-principles relaxed reference, not yet checked against an independently sourced CIF.'}
(OUT/'summary.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
