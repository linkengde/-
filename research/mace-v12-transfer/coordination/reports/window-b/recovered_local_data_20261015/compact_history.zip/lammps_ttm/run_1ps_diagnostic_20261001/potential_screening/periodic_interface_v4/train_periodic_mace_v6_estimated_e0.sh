#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")" && pwd)"
run="$root/mace_periodic_v6"
mace_train=/workspace/.local/venvs/mace/bin/mace_run_train
mace_python=/workspace/.local/venvs/mace/bin/python
mkdir -p "$run/models" "$run/checkpoints" "$run/results" "$run/logs" "$run/train_work"
export MPLCONFIGDIR=/tmp/mplconfig
export XDG_CACHE_HOME=/tmp/xdg-cache
export OMP_NUM_THREADS=4
export MKL_NUM_THREADS=4
export OPENBLAS_NUM_THREADS=1
"$mace_train" \
  --name=Ag_Ti_Si_C_MACE_periodic_v6 \
  --seed=42 \
  --work_dir="$run/train_work" \
  --log_dir="$run/logs" \
  --model_dir="$run/models" \
  --checkpoints_dir="$run/checkpoints" \
  --results_dir="$run/results" \
  --device=cpu \
  --default_dtype=float64 \
  --train_file="$root/mace_periodic_v5/data/train.extxyz" \
  --valid_file="$root/mace_periodic_v5/data/valid.extxyz" \
  --test_file="$root/mace_periodic_v5/data/test.extxyz" \
  --energy_key=REF_energy \
  --forces_key=REF_forces \
  --foundation_model=/workspace/.local/cache/mace/mace-mp-0b3-medium.model \
  --E0s=estimated \
  --multiheads_finetuning=True \
  --batch_size=1 \
  --valid_batch_size=1 \
  --lr=0.0001 \
  --energy_weight=1.0 \
  --forces_weight=1000.0 \
  --max_num_epochs=80 \
  --patience=20 \
  --eval_interval=1 \
  --num_workers=0 \
  --plot=False > "$run/train.stdout" 2>&1
model="$run/models/Ag_Ti_Si_C_MACE_periodic_v6.model"
test -s "$model"
"$mace_python" "$root/evaluate_periodic_mace_v6.py" > "$run/evaluation.stdout" 2>&1
