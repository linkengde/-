#!/usr/bin/env python3
"""Fixed-geometry GPAW/PBE distance points for candidate Ag-Ti and Ag-Si contacts."""
from pathlib import Path
import csv
import json
import os
import sys
import numpy as np
import gpaw_data
from ase.io import read, write
os.environ["GPAW_SETUP_PATH"] = str(gpaw_data.datapath())
from gpaw import GPAW

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "AgTi_AgSi_environment_distance_scans_PBE_v1"
SPECS = {
    "AgTi": {"input": ROOT / "candidate_Ag_Ti_R6.extxyz", "restart": ROOT / "pbe/Ag_Ti/state.gpw",
             "ag_id": 687247, "scaffold_id": 479027, "targets": (2.1, 2.7)},
    "AgSi": {"input": ROOT / "candidate_Ag_Si_R6.extxyz", "restart": ROOT / "pbe/Ag_Si/state.gpw",
             "ag_id": 683609, "scaffold_id": 366934, "targets": (2.2, 2.8)},
}
if len(sys.argv) != 2 or sys.argv[1] not in SPECS:
    raise SystemExit("usage: run_ag_ts_pbe_scan.py AgTi|AgSi")
name = sys.argv[1]
spec = SPECS[name]
out = OUT / name
out.mkdir(parents=True, exist_ok=True)
rows = []
for distance in spec["targets"]:
    tag = f"d{distance:.1f}"
    d = out / tag
    d.mkdir(exist_ok=False)
    atoms = read(spec["input"])
    ids = np.asarray(atoms.arrays["lammps_id"], dtype=int)
    ia = int(np.flatnonzero(ids == spec["ag_id"])[0])
    ib = int(np.flatnonzero(ids == spec["scaffold_id"])[0])
    midpoint = 0.5 * (atoms.positions[ia] + atoms.positions[ib])
    u = atoms.positions[ia] - atoms.positions[ib]
    u /= np.linalg.norm(u)
    atoms.positions[ia] = midpoint + 0.5 * distance * u
    atoms.positions[ib] = midpoint - 0.5 * distance * u
    write(d / "input.extxyz", atoms, format="extxyz")
    atoms.calc = GPAW(str(spec["restart"]), maxiter=120, txt=str(d / "gpaw.log"))
    energy = float(atoms.get_potential_energy())
    forces = np.asarray(atoms.get_forces())
    log_text = (d / "gpaw.log").read_text(errors="replace").lower()
    if "converged" not in log_text or "failed to converge" in log_text:
        raise RuntimeError(f"GPAW convergence not confirmed for {name}/{tag}")
    norms = np.linalg.norm(forces, axis=1)
    with (d / "forces.csv").open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["lammps_id", "symbol", "x_A", "y_A", "z_A", "fx_eV_A", "fy_eV_A", "fz_eV_A", "force_norm_eV_A"])
        for i, (aid, pos, force, norm) in enumerate(zip(ids, atoms.positions, forces, norms)):
            w.writerow([int(aid), atoms[i].symbol, *map(float, pos), *map(float, force), float(norm)])
    row = {"environment": name, "Ag_id": spec["ag_id"], "scaffold_id": spec["scaffold_id"],
           "target_distance_A": distance, "calculated_distance_A": float(np.linalg.norm(atoms.positions[ia] - atoms.positions[ib])),
           "PBE_energy_eV": energy, "pair_separating_force_eV_A": float(np.dot(forces[ia] - forces[ib], u)),
           "max_force_eV_A": float(norms.max()), "max_force_id": int(ids[int(norms.argmax())])}
    (d / "summary.json").write_text(json.dumps(row, indent=2) + "\n")
    rows.append(row)
    print(json.dumps(row), flush=True)
with (out / "summary.csv").open("w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
