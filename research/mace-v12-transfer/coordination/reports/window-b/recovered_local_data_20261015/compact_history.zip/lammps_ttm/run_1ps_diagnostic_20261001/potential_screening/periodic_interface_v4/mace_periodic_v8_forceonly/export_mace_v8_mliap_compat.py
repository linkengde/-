#!/usr/bin/env python3
from pathlib import Path
import sys,torch
ROOT=Path(__file__).resolve().parent
PROJECT=ROOT.parent
INTEGRATION=PROJECT.parent/'lammps_mace_integration'
sys.path.insert(0,str(INTEGRATION))
from mliap_serial_compat import LAMMPS_MLIAP_MACE_SerialCompat
MODEL=ROOT/'models/Ag_Ti_Si_C_MACE_periodic_v8_forceonly.model'
OUT=ROOT/'lammps_v8_serial_run0_20261003/mace_v8_forceonly_mliap_serial_compat.pt'
if OUT.exists():raise SystemExit(f'Refusing to overwrite {OUT}')
model=torch.load(MODEL,map_location='cpu',weights_only=False).double().cpu();model.lammps_mliap=True
wrapper=LAMMPS_MLIAP_MACE_SerialCompat(model,head='Default')
torch.save(wrapper,OUT)
print('model=',MODEL);print('wrapper=',OUT);print('elements=',wrapper.element_types);print('cutoff_A=',float(model.r_max))
