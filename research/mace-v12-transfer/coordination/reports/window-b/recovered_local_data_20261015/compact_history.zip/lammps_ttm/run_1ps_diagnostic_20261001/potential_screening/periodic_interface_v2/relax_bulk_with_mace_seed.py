from pathlib import Path
import json, numpy as np, torch
from ase.io import read, write
from ase.optimize import BFGS
from mace.calculators import MACECalculator
ROOT=Path(__file__).resolve().parent
SRC=Path('/workspace/.local/lammps-ttm/run_1ps_diagnostic_20261001/potential_screening/periodic_interface_v1/structures/Ti3SiC2_bulk_orthorhombic.extxyz')
MODEL=Path('/workspace/.local/cache/mace/mace-mp-0b3-medium.model')
OUT=ROOT/'mace_mp_bulk_relax_seed';(OUT/'relax').mkdir(exist_ok=False)
torch.set_default_dtype(torch.float64)
a=read(SRC);a.calc=MACECalculator(model_paths=[str(MODEL)],device='cpu',default_dtype='float64')
opt=BFGS(a,trajectory=str(OUT/'relax.traj'),logfile=str(OUT/'relax.log'),maxstep=.08)
conv=opt.run(fmax=.05,steps=100)
f=np.asarray(a.get_forces());e=float(a.get_potential_energy());n=np.linalg.norm(f,axis=1)
write(OUT/'Ti3SiC2_mace_pre_relaxed.extxyz',a,format='extxyz')
r={'optimizer_converged':bool(conv),'steps':sum(1 for _ in open(OUT/'relax.log'))-1,'energy_eV':e,'max_force_eV_A':float(n.max()),'force_RMS_eV_A':float(np.sqrt(np.mean(f*f))),'note':'MACE-MP-0b3 geometry seed only; must be checked/refined by periodic PBE before use.'}
(OUT/'relax_summary.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
