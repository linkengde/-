from pathlib import Path
import csv
import os

import numpy as np
from ase.io import read
import gpaw_data


ROOT = Path(__file__).resolve().parent
SETUP = Path(gpaw_data.datapath())
os.environ["GPAW_SETUP_PATH"] = str(SETUP)

from gpaw import GPAW


START = ROOT.parent / "gpaw_step0_R6" / "state.gpw"
ID_A, ID_B = 520183, 520177
rows = []

for target in (1.8, 1.5):
    name = f"pair_d{target:.1f}".replace(".", "p")
    atoms = read(ROOT / f"{name}_R6.extxyz")
    calc_dir = ROOT / name
    if calc_dir.exists():
        raise SystemExit(f"Refusing to reuse existing result directory: {calc_dir}")
    calc_dir.mkdir()
    atoms.calc = GPAW(str(START), maxiter=120, txt=str(calc_dir / "gpaw.log"))
    energy = atoms.get_potential_energy()
    forces = atoms.get_forces()
    ids = atoms.arrays["lammps_id"].astype(int)
    ia, ib = (int(np.flatnonzero(ids == atom_id)[0]) for atom_id in (ID_A, ID_B))
    vector = atoms.positions[ib] - atoms.positions[ia]
    distance = float(np.linalg.norm(vector))
    separating = float(np.dot(forces[ib] - forces[ia], vector / distance))
    norms = np.linalg.norm(forces, axis=1)
    row = {
        "frame": name,
        "atoms": len(atoms),
        "GPAW_energy_eV": float(energy),
        "C_pair_distance_A": distance,
        "C_pair_separating_force_eV_per_A": separating,
        "C520183_force_norm_eV_per_A": float(norms[ia]),
        "C520177_force_norm_eV_per_A": float(norms[ib]),
        "max_force_norm_eV_per_A": float(norms.max()),
        "max_force_lammps_id": int(ids[int(norms.argmax())]),
    }
    with (calc_dir / "forces.csv").open("w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["lammps_id", "symbol", "fx_eV_A", "fy_eV_A", "fz_eV_A", "force_norm_eV_A"])
        for atom_id, atom, force, norm in zip(ids, atoms, forces, norms):
            writer.writerow([int(atom_id), atom.symbol, *map(float, force), float(norm)])
    atoms.calc.write(str(calc_dir / "state.gpw"), mode="all")
    rows.append(row)
    print(row, flush=True)

with (ROOT / "pair_scan_pbe_summary.csv").open("x", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=rows[0].keys())
    writer.writeheader()
    writer.writerows(rows)
