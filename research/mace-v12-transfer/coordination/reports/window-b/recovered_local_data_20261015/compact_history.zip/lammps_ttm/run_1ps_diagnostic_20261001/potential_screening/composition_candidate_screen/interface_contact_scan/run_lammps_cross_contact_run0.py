#!/usr/bin/env python3
"""Static calibration-v0 and cross-term-off forces on the Ag-C PBE clusters."""
from pathlib import Path
import json
import subprocess

import numpy as np
from ase.io import read

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "lammps_cross_contact_run0"
OUT.mkdir(exist_ok=True)
BASE = Path("/workspace/.local/lammps-ttm/composition_locked_candidate_20260930")
LMP = Path("/workspace/.local/lammps-ttm/bin/lmp_mpi")
SPECS = {
    "primary": (ROOT / "candidate_Ag_C_R6.extxyz", 732149, 197404),
    "secondary": (ROOT / "AgC_secondary/candidate_Ag_C_R6.extxyz", 688433, 604804),
}
MORSE = {
    (1, 4): (0.94814194, 2.0, 2.33708864),
    (2, 4): (0.93944948, 2.0, 2.40407837),
    (3, 4): (1.35077230, 2.0, 2.15255924),
}
MASS = {1: 47.8670000, 2: 28.0855000, 3: 12.0107000, 4: 107.8682000}

summaries = []
for env, (xyz_path, ag_id, c_id) in SPECS.items():
    env_dir = OUT / env
    env_dir.mkdir(exist_ok=True)
    atoms = read(xyz_path)
    types = np.asarray(atoms.arrays["lammps_type"], dtype=int)
    original_ids = np.asarray(atoms.arrays["lammps_id"], dtype=int)
    ia = int(np.flatnonzero(original_ids == ag_id)[0])
    ic = int(np.flatnonzero(original_ids == c_id)[0])
    u = atoms.positions[ia] - atoms.positions[ic]
    u /= np.linalg.norm(u)
    data = env_dir / "cluster.data"
    with data.open("w") as f:
        f.write("PBE Ag-C local cluster for LAMMPS static comparison\n\n")
        f.write(f"{len(atoms)} atoms\n4 atom types\n\n")
        f.write("0.0 28.0 xlo xhi\n0.0 28.0 ylo yhi\n0.0 28.0 zlo zhi\n\nMasses\n\n")
        for typ, mass in MASS.items():
            f.write(f"{typ} {mass}\n")
        f.write("\nAtoms # atomic\n\n")
        for i, (typ, pos) in enumerate(zip(types, atoms.positions), start=1):
            f.write(f"{i} {int(typ)} {pos[0]:.12f} {pos[1]:.12f} {pos[2]:.12f}\n")
    (env_dir / "id_map.json").write_text(json.dumps({str(i + 1): int(aid) for i, aid in enumerate(original_ids)}, indent=2) + "\n")

    env_summary = {"environment": env, "Ag_id": ag_id, "C_id": c_id,
                   "distance_A": float(np.linalg.norm(atoms.positions[ia] - atoms.positions[ic]))}
    forces_by_variant = {}
    for variant, scale in (("calibration_v0", 1.0), ("cross_terms_zero", 0.0)):
        run_dir = env_dir / variant
        run_dir.mkdir(exist_ok=True)
        dump_path = run_dir / "forces.dump"
        input_path = run_dir / "in.run0"
        lines = [
            "units metal", "atom_style atomic", "boundary f f f", f"read_data {data}",
            "pair_style hybrid eam tersoff morse 8.0",
            f"pair_coeff 4 4 eam {BASE}/potentials/Ag_u3.eam",
            f"pair_coeff * * tersoff {BASE}/potentials/TSCBOP.tersoff Ti Si C NULL",
        ]
        for (i, j), (d0, alpha, r0) in MORSE.items():
            lines.append(f"pair_coeff {i} {j} morse {d0 * scale:.12g} {alpha:.12g} {r0:.12g} 8.0")
        lines += [
            "neighbor 2.0 bin", "neigh_modify every 1 delay 0 check yes",
            "variable fnorm atom sqrt(fx*fx+fy*fy+fz*fz)", "compute fmax all reduce max v_fnorm",
            "thermo 1", "thermo_style custom step atoms pe press pxx pyy pzz c_fmax",
            "thermo_modify flush yes lost error", f"dump f all custom 1 {dump_path} id type x y z fx fy fz",
            "dump_modify f sort id", "run 0", "",
        ]
        input_path.write_text("\n".join(lines))
        log_path = run_dir / "log.lammps"
        with (run_dir / "run.stdout").open("w") as stdout:
            subprocess.run([str(LMP), "-in", str(input_path), "-log", str(log_path)],
                           cwd=run_dir, check=True, stdout=stdout, stderr=subprocess.STDOUT)
        rows = np.loadtxt(dump_path, comments="#", skiprows=9)
        forces = rows[:, 5:8]
        thermo = [line.split() for line in log_path.read_text().splitlines()
                  if line.strip().startswith("0 ") and len(line.split()) == 8]
        env_summary[variant] = {
            "PE_eV": float(thermo[-1][2]),
            "pair_separating_force_eV_A": float(np.dot(forces[ia] - forces[ic], u)),
            "Ag_force_eV_A": forces[ia].tolist(),
            "C_force_eV_A": forces[ic].tolist(),
            "Fmax_eV_A": float(np.linalg.norm(forces, axis=1).max()),
        }
        forces_by_variant[variant] = forces
    delta = forces_by_variant["calibration_v0"] - forces_by_variant["cross_terms_zero"]
    env_summary["Morse_cross_contribution_pair_force_eV_A"] = float(np.dot(delta[ia] - delta[ic], u))
    (env_dir / "summary.json").write_text(json.dumps(env_summary, indent=2) + "\n")
    summaries.append(env_summary)
    print(json.dumps(env_summary), flush=True)
(OUT / "summary.json").write_text(json.dumps(summaries, indent=2) + "\n")
