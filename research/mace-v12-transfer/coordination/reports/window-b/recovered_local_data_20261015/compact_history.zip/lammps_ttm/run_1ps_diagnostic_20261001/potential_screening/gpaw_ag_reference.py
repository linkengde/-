from pathlib import Path
import os

import numpy as np
from ase.build import bulk
from gpaw import GPAW, PW
import gpaw_data

out = Path(__file__).resolve().parent / "ag_reference"
out.mkdir(parents=True, exist_ok=True)
os.environ["GPAW_SETUP_PATH"] = str(gpaw_data.datapath())

atoms = bulk("Ag", "fcc", a=4.09)
atoms.calc = GPAW(
    mode=PW(350),
    xc="PBE",
    kpts=(4, 4, 4),
    txt=str(out / "gpaw.log"),
)
energy = atoms.get_potential_energy()
forces = atoms.get_forces()
(out / "summary.txt").write_text(
    f"GPAW: {__import__('gpaw').__version__}\n"
    f"ASE: {__import__('ase').__version__}\n"
    f"PAW data: {gpaw_data.datapath()}\n"
    f"Ag fcc lattice parameter (A): 4.09\n"
    f"PBE energy per atom (eV): {energy:.10f}\n"
    f"max force norm (eV/A): {np.linalg.norm(forces, axis=1).max():.6e}\n"
)
print((out / "summary.txt").read_text())
