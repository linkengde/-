# Ag–Ti–Si–C MACE 微调试验报告

## 目的与数据

本试验只判断 MACE-MP-0b3-medium 在少量组成锁定候选局部 DFT 构型上微调后，是否改善相关力。所有训练、验证和测试对象都是非周期小簇；这个数据集不代表生产势训练集。

- 训练：5 个候选构型，包括 C–C 初始/1.8 Å、最近 Ag–Ti、Ag–Si 和一个 Ag–C 接触。
- 验证：1 个候选 C–C 1.5 Å 构型。
- 留出测试：4 个原始 Ag 环境 C–C 构型，以及 1 个独立 Ag–C 接触。留出构型未参与参数更新。
- 参考标签：GPAW/PBE 固定坐标能量与力。
- 按验证损失选出的权重：epoch 51。MACE 训练器在单进程模式下没有实际跳出训练循环；观察到验证误差持续变差后停止后续更新，并从已保存的 epoch 51 checkpoint 导出/评估该模型。

## 结果

留出集的全原子力向量 RMSE（按原子数加权）从预训练 MACE 的 **0.549** 降到微调模型的 **0.502 eV/Å**，改善约 8.5%，但仍存在明显误差。单个独立 Ag–C 接触的分离力从 **−0.040** 改到 **−0.546 eV/Å**，方向与 PBE 一致，但 PBE 为 **−1.197 eV/Å**，微调模型仍低估一半以上。该接触全簇力 RMSE 从 0.521 降到 0.440 eV/Å，仍约为 PBE 力 RMS 的 28.9%。

压缩 C–C 留出结果并不一致：原始 Ag 环境 1.8 Å 点从 −0.218 改到 −0.972 eV/Å，接近 PBE 的 −0.877；1.5 Å 点从 −2.270 改到 −2.506 eV/Å，反而更偏离 PBE 的 −0.156。候选 1.5 Å 验证簇的总体力 RMSE 明显下降，但中心 C–C 分离力由 −9.046 变成 −9.839 eV/Å，相对 PBE −8.395 的误差扩大。

逐构型完整数据见 [heldout_metrics.csv](heldout_metrics.csv)；最终 MACE 训练器测试表见 `../results_export_epoch51/Ag_Ti_Si_C_MACE_finetune_pilot_run-42_train.txt`。可加载模型文件为 `../checkpoints_export_epoch51/Ag_Ti_Si_C_MACE_finetune_pilot_run-42.model`（SHA256 `5b10e1e28c04b789a167c51097487a900d1d368604b5eb1451c2534dfa782c1f`），最佳训练 checkpoint 为 `../checkpoints_keyfix/Ag_Ti_Si_C_MACE_finetune_pilot_run-42_epoch-51.pt`。

## 判断与停止边界

微调对独立 Ag–C 接触和部分 C–C 构型有改善，但在其他压缩构型出现回退；总留出误差仍大，训练集也只有 5 个小簇。因此该模型**没有通过交叉势验证**，只能作为诊断/后续训练起点，不能用于 1 ps、TTM 或生产 MD。

本试验没有计算周期 Ag/Ti₃SiC₂ 界面黏附能、平衡距离、不同表面终止/堆垛、体相与表面数据，也没有修改旧 calibration v0 Morse 交叉项。下一阶段应先补充周期 slab/interface 的 PBE 能量与力训练和留出构型，再重新训练并独立验证；模型进入 LAMMPS TTM 前还要解决其周期/MPI 接口限制。
