#!/usr/bin/env python3
"""Extend the fine-tuning pilot with a primary Ag-C PBE scan; keep secondary Ag-C held out."""
from pathlib import Path
import csv
import json

import numpy as np
from ase.io import read, write
from ase.calculators.singlepoint import SinglePointCalculator

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / "mace_finetune_pilot/data"
SCAN = ROOT.parent / "interface_contact_scan/AgC_environment_distance_scans_PBE_v1"
DATA = ROOT / "data"
DATA.mkdir(parents=True, exist_ok=True)

train = read(OLD / "train.extxyz", index=":")
valid = read(OLD / "valid.extxyz", index=":")
test = read(OLD / "test.extxyz", index=":")
added_train = []
added_test = []

for env, destination in (("primary", added_train), ("secondary", added_test)):
    for distance in (2.0, 2.4):
        tag = f"d{distance:.1f}"
        calc_dir = SCAN / env / tag
        summary_path = calc_dir / "summary.json"
        forces_path = calc_dir / "forces.csv"
        log_path = calc_dir / "gpaw.log"
        if not (summary_path.exists() and forces_path.exists()):
            raise RuntimeError(f"PBE scan incomplete: {env}/{tag}")
        log = log_path.read_text(errors="replace")
        if "converged" not in log.lower() or "failed to converge" in log.lower():
            raise RuntimeError(f"PBE convergence not confirmed: {env}/{tag}")
        summary = json.loads(summary_path.read_text())
        atoms = read(calc_dir / "input.extxyz")
        by_id = {}
        with forces_path.open() as f:
            for row in csv.DictReader(f):
                by_id[int(row["lammps_id"])] = [float(row["fx_eV_A"]), float(row["fy_eV_A"]), float(row["fz_eV_A"])]
        atom_ids = np.asarray(atoms.arrays["lammps_id"], dtype=int)
        forces = np.asarray([by_id[int(aid)] for aid in atom_ids], dtype=float)
        atoms.info["config_type"] = f"AgC_{env}_{tag}_PBE"
        atoms.info["source_config"] = f"AgC_{env}_{tag}"
        atoms.calc = SinglePointCalculator(atoms, energy=float(summary["PBE_energy_eV"]), forces=forces)
        destination.append(atoms)

for atoms in test:
    atoms.info["config_type"] = atoms.info.get("config_type", "heldout")

write(DATA / "train.extxyz", train + added_train, format="extxyz")
write(DATA / "valid.extxyz", valid, format="extxyz")
write(DATA / "test.extxyz", test + added_test, format="extxyz")
manifest = {
    "purpose": "Expanded local PBE fine-tuning dataset; nonperiodic clusters only, not a production dataset.",
    "train": [a.info.get("config_type", "unknown") for a in train] + [a.info["config_type"] for a in added_train],
    "valid": [a.info.get("config_type", "unknown") for a in valid],
    "test": [a.info.get("config_type", "unknown") for a in test] + [a.info["config_type"] for a in added_test],
    "split_rule": "Both added primary Ag-C scan points join training; the entire secondary Ag-C environment remains held out, including its distance scan.",
}
(DATA / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"train": len(train) + len(added_train), "valid": len(valid), "test": len(test) + len(added_test), "manifest": str(DATA / "manifest.json")}, indent=2))
