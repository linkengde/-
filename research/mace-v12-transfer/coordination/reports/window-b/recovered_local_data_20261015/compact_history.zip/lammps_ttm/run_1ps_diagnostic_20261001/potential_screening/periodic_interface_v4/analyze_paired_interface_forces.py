#!/usr/bin/env python3
"""Extract boundary-layer normal forces from completed paired-interface PBE cells."""
from pathlib import Path
import csv
import json

import numpy as np
from ase.io import read

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "paired_interface_force_analysis"
OUT.mkdir(exist_ok=True)
cases = {
    "d2.3": {
        "xyz": ROOT / "pbe_singlepoints_500eV/Ag_Ti3SiC2_PBE_d2.3.extxyz",
        "log": ROOT / "pbe_singlepoints_500eV/gpaw_d2.3.log",
        "geometry": ROOT / "structures/Ag_Ti3SiC2_periodic_d2.3.json",
    },
    "d2.6": {
        "xyz": ROOT / "pbe_singlepoint_d2.6_500eV_run2/Ag_Ti3SiC2_PBE_d2.6.extxyz",
        "log": ROOT / "pbe_singlepoint_d2.6_500eV_run2/gpaw.log",
        "geometry": ROOT / "structures/Ag_Ti3SiC2_periodic_d2.6.json",
    },
    "d2.9": {
        "xyz": ROOT / "pbe_singlepoint_d2.9_500eV_run1/Ag_Ti3SiC2_PBE_d2.9.extxyz",
        "log": ROOT / "pbe_singlepoint_d2.9_500eV_run1/gpaw.log",
        "geometry": ROOT / "structures/Ag_Ti3SiC2_periodic_d2.9.json",
    },
}
rows = []
case_summary = []
for tag, files in cases.items():
    if not files["xyz"].exists():
        continue
    atoms = read(files["xyz"])
    if "forces" not in atoms.calc.results:
        continue
    meta = json.loads(files["geometry"].read_text())
    forces = atoms.get_forces()
    symbols = np.asarray(atoms.get_chemical_symbols())
    normal = np.cross(atoms.cell[1], atoms.cell[2])
    normal /= np.linalg.norm(normal)
    heights = atoms.positions @ normal
    ag = np.flatnonzero(symbols == "Ag")
    substrate = np.flatnonzero(symbols != "Ag")
    ag_planes = []
    for idx in ag[np.argsort(heights[ag])]:
        h = float(heights[idx])
        if not ag_planes or abs(h - ag_planes[-1]["height_A"]) > 0.35:
            ag_planes.append({"height_A": h, "ids": [int(idx)]})
        else:
            ag_planes[-1]["ids"].append(int(idx))
    if len(ag_planes) < 2:
        raise RuntimeError(f"Could not identify Ag layers for {tag}")
    zlo, zhi = float(heights[substrate].min()), float(heights[substrate].max())
    surface_tol = 0.35
    surface_bottom = substrate[np.abs(heights[substrate] - zlo) <= surface_tol]
    surface_top = substrate[np.abs(heights[substrate] - zhi) <= surface_tol]
    interfaces = [
        ("top", float(meta["nominal_top_gap_A"]), ag_planes[0]["ids"], surface_top, +1.0),
        ("bottom", float(meta["nominal_bottom_gap_A"]), ag_planes[-1]["ids"], surface_bottom, -1.0),
    ]
    for side, gap, ag_ids, sub_ids, sign in interfaces:
        ag_fn = forces[ag_ids] @ normal
        sub_fn = forces[sub_ids] @ normal
        row = {
            "case": tag,
            "side": side,
            "gap_A": gap,
            "ag_layer_atoms": len(ag_ids),
            "substrate_surface_atoms": len(sub_ids),
            "ag_mean_separating_force_eV_A_per_atom": float(np.mean(sign * ag_fn)),
            "substrate_mean_separating_force_eV_A_per_atom": float(np.mean(-sign * sub_fn)),
            "ag_net_separating_force_eV_A": float(np.sum(sign * ag_fn)),
            "substrate_net_separating_force_eV_A": float(np.sum(-sign * sub_fn)),
        }
        rows.append(row)
    mag = np.linalg.norm(forces, axis=1)
    case_summary.append({
        "case": tag,
        "top_gap_A": meta["nominal_top_gap_A"],
        "bottom_gap_A": meta["nominal_bottom_gap_A"],
        "energy_eV_cell": float(atoms.get_potential_energy()),
        "free_energy_eV_cell": float(atoms.get_potential_energy(force_consistent=True)),
        "fmax_eV_A": float(mag.max()),
        "fmax_atom_1based": int(mag.argmax() + 1),
    })

if rows:
    with (OUT / "surface_layer_normal_forces.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
result = {
    "meaning": "Positive projected force means the selected surface layer is pushed away from the opposite solid, increasing its local gap. These are layer-force projections, not isolated pairwise force decompositions.",
    "energy_caveat": "Each periodic cell contains two interfaces. d2.3 is a (2.3,2.9) A gap pair, d2.6 is (2.6,2.6) A, and d2.9 is (2.9,2.3) A. Total energies are not a single-interface binding curve.",
    "cases": case_summary,
    "surface_layer_forces": rows,
}
(OUT / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2), flush=True)
