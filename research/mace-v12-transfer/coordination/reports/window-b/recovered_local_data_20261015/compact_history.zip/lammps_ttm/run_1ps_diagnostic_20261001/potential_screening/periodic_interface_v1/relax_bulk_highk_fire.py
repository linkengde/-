#!/usr/bin/env python3
"""Relax the reconstructed Ti3SiC2 bulk motif at the strict 1x4x2 PBE grid."""
from pathlib import Path
import json
import os

import gpaw_data
import numpy as np
from ase.io import read, write
from ase.optimize import FIRE

ROOT = Path(__file__).resolve().parent
SEED = ROOT / "bulk_pbe_strict_fire_1x4x2"
OUT = ROOT / "bulk_pbe_fire_1x4x2_relax"
OUT.mkdir(exist_ok=False)
os.environ["GPAW_SETUP_PATH"] = str(gpaw_data.datapath())
from gpaw import GPAW  # noqa: E402

atoms = read(ROOT / "bulk_pbe_fire_1x2x1" / "Ti3SiC2_PBE_Fire_1x2x1.extxyz")
atoms.calc = GPAW(str(SEED / "state.gpw"), txt=str(OUT / "gpaw_relax.log"))
optimizer = FIRE(
    atoms,
    trajectory=str(OUT / "fire.traj"),
    logfile=str(OUT / "fire.log"),
    dt=0.03,
    dtmax=0.08,
    maxstep=0.02,
    Nmin=5,
    finc=1.1,
    fdec=0.5,
    astart=0.1,
    fa=0.99,
)
converged = optimizer.run(fmax=0.10, steps=30)
forces = np.asarray(atoms.get_forces())
norms = np.linalg.norm(forces, axis=1)
energy = float(atoms.get_potential_energy())
np.savetxt(
    OUT / "forces.csv",
    np.column_stack((np.arange(1, len(atoms) + 1), forces)),
    delimiter=",",
    header="atom_index,fx_eV_A,fy_eV_A,fz_eV_A",
    comments="",
)
write(OUT / "Ti3SiC2_PBE_Fire_1x4x2.extxyz", atoms, format="extxyz")
atoms.calc.write(OUT / "state.gpw")
log = (OUT / "gpaw_relax.log").read_text(errors="replace").lower()
summary = {
    "optimizer": "FIRE",
    "optimizer_converged": bool(converged),
    "atoms": len(atoms),
    "cell_A": atoms.cell.array.tolist(),
    "kpts": [1, 4, 2],
    "scf_thresholds": "1e-4",
    "target_fmax_eV_A": 0.10,
    "scf_converged_at_all_logged_steps": "failed to converge" not in log,
    "max_force_eV_A": float(norms.max()),
    "max_force_atom_index": int(norms.argmax() + 1),
    "max_force_element": atoms[int(norms.argmax())].symbol,
    "force_RMS_eV_A": float(np.sqrt(np.mean(forces * forces))),
    "extrapolated_energy_eV": energy,
    "steps": max(0, sum(1 for _ in open(OUT / "fire.log")) - 1),
    "note": "Fixed-cell strict-grid PBE relaxation of a model-derived substrate motif; still not independently CIF-validated.",
}
(OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary), flush=True)
