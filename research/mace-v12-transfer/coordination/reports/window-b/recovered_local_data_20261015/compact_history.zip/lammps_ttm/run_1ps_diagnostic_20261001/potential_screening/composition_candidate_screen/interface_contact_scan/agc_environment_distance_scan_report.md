# Ag–C 局部环境距离扫描

## 计算设置

用两个组成锁定候选的 48 原子非周期局部簇（primary/secondary）分别扫描标记 Ag–C 对的间距。每个点对 Ag 和 C 各移动一半距离，保持其余原子和 28 Å 真空盒坐标不变，做 GPAW/PBE LCAO/DZP 固定坐标单点。所有 4 个新增 SCF 都收敛。此数据是环境敏感性诊断，不是周期界面验证。

力定义为 `(F_Ag − F_C)·u`，`u` 从 C 指向 Ag；正值为分离/排斥，负值为吸引。对同一几何另做了 calibration v0 的 LAMMPS `run 0` 和零交叉项力对照，并用 MACE-MP-0b3 与 epoch-51 微调模型计算静态力。

## Ag–C 分离力投影 (eV/Å)

| 环境 | 距离 (Å) | PBE | calibration v0 | 原始 MACE | epoch-51 微调 MACE |
|---|---:|---:|---:|---:|---:|
| primary | 2.0000 | +3.063 | +4.593 | +4.575 | +3.494 |
| primary | 2.2026 | −0.864 | −2.522 | +0.519 | −0.858 |
| primary | 2.4000 | −2.910 | −5.340 | −1.496 | −2.975 |
| secondary | 2.0000 | +2.188 | +7.860 | +4.274 | +3.982 |
| secondary | 2.2026 | −1.197 | +0.858 | −0.040 | −0.546 |
| secondary | 2.4000 | −2.653 | −1.745 | −2.188 | −2.606 |

逐原子全力误差及能量误差见 [原始/微调 MACE 逐点结果](mace_model_comparison_epoch51_full.csv)。PBE 运行目录含每点的 `gpaw.log`、`forces.csv` 与 `summary.json`；LAMMPS 输入和完整日志在 `AgC_environment_distance_scans_LAMMPS_v0_v2/`。

## 结论

- 两个环境的 PBE 曲线都从 2.0 Å 排斥转为 2.2026 Å 吸引，2.4 Å 仍为吸引，但不同环境在相同距离的力也有差异。
- calibration v0 在 secondary 的 2.2026 Å 预测错方向；primary 曲线上则在 2.2026/2.4 Å 过度吸引。其单平面 HCP surrogate 交叉项没有转移到这些局部簇。
- epoch-51 MACE 在训练过的 primary 环境上较好复现扫描曲线；整个 secondary 环境留出时，2.0/2.2026 Å 仍明显偏离，且该环境全原子力 RMSE 约 0.44 eV/Å。单点微调没有学到可靠的 Ag–C 环境迁移。
- 这支持采用环境依赖的多体势并用多个实际界面构型训练；但当前训练样本很少、无周期嵌入、MACE 还未过留出门槛，不能用于长时间 MD。增加了 primary 扫描数据、把 secondary 整个环境留出的第二轮微调正在运行。
