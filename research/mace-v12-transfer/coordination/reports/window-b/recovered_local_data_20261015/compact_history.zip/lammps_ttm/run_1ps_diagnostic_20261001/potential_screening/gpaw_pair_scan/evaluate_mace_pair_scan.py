from pathlib import Path
import csv

import numpy as np
from ase.io import read
from mace.calculators import mace_mp


ROOT = Path(__file__).resolve().parent
MODEL = Path("/workspace/.local/cache/mace/mace-mp-0b3-medium.model")
ID_A, ID_B = 520183, 520177
calculator = mace_mp(model=str(MODEL), device="cpu", default_dtype="float64")
rows = []

for target in (1.8, 1.5):
    name = f"pair_d{target:.1f}".replace(".", "p")
    atoms = read(ROOT / f"{name}_R6.extxyz")
    atoms.calc = calculator
    energy = atoms.get_potential_energy()
    forces = atoms.get_forces()
    ids = atoms.arrays["lammps_id"].astype(int)
    ia, ib = (int(np.flatnonzero(ids == atom_id)[0]) for atom_id in (ID_A, ID_B))
    vector = atoms.positions[ib] - atoms.positions[ia]
    distance = float(np.linalg.norm(vector))
    separating = float(np.dot(forces[ib] - forces[ia], vector / distance))
    norms = np.linalg.norm(forces, axis=1)
    rows.append(
        {
            "frame": name,
            "atoms": len(atoms),
            "MACE_energy_eV": float(energy),
            "C_pair_distance_A": distance,
            "C_pair_separating_force_eV_per_A": separating,
            "C520183_force_norm_eV_per_A": float(norms[ia]),
            "C520177_force_norm_eV_per_A": float(norms[ib]),
            "max_force_norm_eV_per_A": float(norms.max()),
            "max_force_lammps_id": int(ids[int(norms.argmax())]),
        }
    )
    force_path = ROOT / f"{name}_mace_forces.csv"
    with force_path.open("x", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["lammps_id", "symbol", "fx_eV_A", "fy_eV_A", "fz_eV_A", "force_norm_eV_A"])
        for atom_id, atom, force, norm in zip(ids, atoms, forces, norms):
            writer.writerow([int(atom_id), atom.symbol, *map(float, force), float(norm)])
    print(rows[-1], flush=True)

with (ROOT / "pair_scan_mace_summary.csv").open("x", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=rows[0].keys())
    writer.writeheader()
    writer.writerows(rows)
