from pathlib import Path
from ase.io import read
import csv

root = Path(__file__).resolve().parent
out = root / 'lammps_v6_serial_run0_20261002'
out.mkdir(exist_ok=True)
src = root.parent / 'composition_candidate_screen/interface_contact_scan/AgC_secondary/candidate_Ag_C_R6.extxyz'
atoms = read(src)
order = {'C': 1, 'Si': 2, 'Ti': 3, 'Ag': 4}
mass = {'C': 12.011, 'Si': 28.0855, 'Ti': 47.867, 'Ag': 107.8682}
data = out / 'cluster.data'
if data.exists(): raise SystemExit(f'Refusing to overwrite {data}')
with data.open('x') as f:
    f.write('48 atom Ag-C cluster for v6 serial run0\n\n')
    f.write(f'{len(atoms)} atoms\n4 atom types\n\n')
    for axis,lo,hi in zip('xyz',[0,0,0],atoms.cell.lengths()): f.write(f'{lo:.10f} {hi:.10f} {axis}lo {axis}hi\n')
    f.write('\nMasses\n\n')
    for el,typ in order.items(): f.write(f'{typ} {mass[el]:.8f} # {el}\n')
    f.write('\nAtoms # atomic\n\n')
    for i,(atom,pos) in enumerate(zip(atoms,atoms.positions),start=1):
        f.write(f'{i} {order[atom.symbol]} {pos[0]:.10f} {pos[1]:.10f} {pos[2]:.10f}\n')
with (out/'atom_id_map.csv').open('x',newline='') as f:
    w=csv.writer(f); w.writerow(['lammps_id','source_lammps_id','element'])
    for i,atom in enumerate(atoms,start=1): w.writerow([i,int(atoms.arrays['lammps_id'][i-1]),atom.symbol])
script = out/'in.run0'
script.write_text(f'''units metal
atom_style atomic
boundary f f f
read_data {data}
neighbor 2.0 bin
neigh_modify every 1 delay 0 check yes
pair_style mliap unified {out/'mace_v6_mliap_serial_compat.pt'} 0
pair_coeff * * C Si Ti Ag
compute atomforce all property/atom fx fy fz
variable force_mag atom sqrt(c_atomforce[1]^2+c_atomforce[2]^2+c_atomforce[3]^2)
compute maxforce all reduce max v_force_mag
thermo 1
thermo_style custom step atoms pe c_maxforce
thermo_modify norm no
dump force all custom 1 {out/'forces.dump'} id type x y z fx fy fz
dump_modify force sort id
run 0
''')
print(data)
print(script)
