#!/usr/bin/env python3
"""Resolve Ag-C versus Ag-Ti/Si Morse force contributions on the two contact clusters."""
from pathlib import Path
import json
import subprocess

import numpy as np
from ase.io import read

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "lammps_cross_contact_component_audit_v2"
BASE = Path("/workspace/.local/lammps-ttm/composition_locked_candidate_20260930")
LMP = Path("/workspace/.local/lammps-ttm/bin/lmp_mpi")
SPECS = {"primary": (ROOT / "candidate_Ag_C_R6.extxyz", 732149, 197404),
         "secondary": (ROOT / "AgC_secondary/candidate_Ag_C_R6.extxyz", 688433, 604804)}
MORSE = {(1, 4): (0.94814194, 2.0, 2.33708864),
         (2, 4): (0.93944948, 2.0, 2.40407837),
         (3, 4): (1.35077230, 2.0, 2.15255924)}
MASS = {1: 47.867, 2: 28.0855, 3: 12.0107, 4: 107.8682}
OUT.mkdir(exist_ok=False)
all_results = []

for env, (xyz, ag_id, c_id) in SPECS.items():
    atoms = read(xyz)
    types = np.asarray(atoms.arrays["lammps_type"], dtype=int)
    ids = np.asarray(atoms.arrays["lammps_id"], dtype=int)
    ia, ic = int(np.flatnonzero(ids == ag_id)[0]), int(np.flatnonzero(ids == c_id)[0])
    u = atoms.positions[ia] - atoms.positions[ic]
    u /= np.linalg.norm(u)
    env_out = OUT / env
    env_out.mkdir()
    data = env_out / "cluster.data"
    with data.open("w") as f:
        f.write("Ag-C local cluster\n\n%d atoms\n4 atom types\n\n" % len(atoms))
        f.write("0 28 xlo xhi\n0 28 ylo yhi\n0 28 zlo zhi\n\nMasses\n\n")
        for typ, mass in MASS.items(): f.write(f"{typ} {mass}\n")
        f.write("\nAtoms # atomic\n\n")
        for i, (typ, pos) in enumerate(zip(types, atoms.positions), 1):
            f.write(f"{i} {int(typ)} {pos[0]:.12f} {pos[1]:.12f} {pos[2]:.12f}\n")

    force_sets = {}
    force_metrics = {}
    for variant in ("calibration_v0", "AgC_zero", "all_cross_zero"):
        run_dir = env_out / variant
        run_dir.mkdir()
        dump = run_dir / "forces.dump"
        lines = ["units metal", "atom_style atomic", "boundary f f f", f"read_data {data}",
                 "pair_style hybrid eam tersoff morse 8.0",
                 f"pair_coeff 4 4 eam {BASE}/potentials/Ag_u3.eam",
                 f"pair_coeff * * tersoff {BASE}/potentials/TSCBOP.tersoff Ti Si C NULL"]
        for (i, j), (d0, alpha, r0) in MORSE.items():
            keep = variant == "calibration_v0" or (variant == "AgC_zero" and (i, j) != (3, 4))
            lines.append(f"pair_coeff {i} {j} morse {d0 if keep else 0.0:.12g} {alpha:.12g} {r0:.12g} 8.0")
        lines += ["neighbor 2.0 bin", "neigh_modify every 1 delay 0 check yes",
                  "variable fnorm atom sqrt(fx*fx+fy*fy+fz*fz)", "compute fmax all reduce max v_fnorm",
                  "thermo 1", "thermo_style custom step atoms pe c_fmax", "thermo_modify flush yes lost error",
                  f"dump f all custom 1 {dump} id type x y z fx fy fz", "dump_modify f sort id", "run 0", ""]
        inp = run_dir / "in.run0"
        inp.write_text("\n".join(lines))
        log = run_dir / "log.lammps"
        with (run_dir / "run.stdout").open("w") as stdout:
            subprocess.run([str(LMP), "-in", str(inp), "-log", str(log)], cwd=run_dir, check=True,
                           stdout=stdout, stderr=subprocess.STDOUT)
        rows = np.loadtxt(dump, comments="#", skiprows=9)
        force = rows[:, 5:8]
        thermo = [line.split() for line in log.read_text().splitlines()
                  if line.strip().startswith("0 ") and len(line.split()) == 4]
        force_sets[variant] = force
        force_metrics[variant] = {"PE_eV": float(thermo[-1][2]),
                                  "pair_separating_force_eV_A": float(np.dot(force[ia] - force[ic], u)),
                                  "Fmax_eV_A": float(np.linalg.norm(force, axis=1).max())}
    delta_agc = force_sets["calibration_v0"] - force_sets["AgC_zero"]
    delta_tisi = force_sets["AgC_zero"] - force_sets["all_cross_zero"]
    row = {"environment": env, "AgC_distance_A": float(np.linalg.norm(atoms.positions[ia] - atoms.positions[ic])),
           **force_metrics,
           "AgC_Morse_contribution_eV_A": float(np.dot(delta_agc[ia] - delta_agc[ic], u)),
           "AgTi_Si_Morse_contribution_eV_A": float(np.dot(delta_tisi[ia] - delta_tisi[ic], u))}
    (env_out / "summary.json").write_text(json.dumps(row, indent=2) + "\n")
    all_results.append(row)
    print(json.dumps(row), flush=True)
(OUT / "summary.json").write_text(json.dumps(all_results, indent=2) + "\n")
