from pathlib import Path
import hashlib, json
import numpy as np
import torch
from ase.data import chemical_symbols

root = Path(__file__).resolve().parent
run = root / 'mace_periodic_v5'
records = json.loads((run/'evaluation_retry2/summary.json').read_text())['records']
manifest = json.loads((run/'dataset_manifest.json').read_text())
composition = {c['config_type']: c['composition'] for c in manifest['cases']}
source = run/'models/Ag_Ti_Si_C_MACE_periodic_v5.model'
dest = run/'models/Ag_Ti_Si_C_MACE_periodic_v5_train_energy_reference_calibrated.model'
model = torch.load(source, map_location='cpu', weights_only=False).double().eval()
state = model.state_dict()
key = 'atomic_energies_fn.atomic_energies'
if key not in state:
    raise RuntimeError(f'Expected atomic energy buffer absent: {key}')
atomic_numbers = [int(z) for z in model.atomic_numbers.tolist()]
symbols = [chemical_symbols[z] for z in atomic_numbers]
train = [r for r in records if r['split'] == 'train']
A = np.array([[composition[r['config_type']].get(el, 0) for el in symbols] for r in train], dtype=float)
resid = np.array([r['finetuned_v5_energy_error_eV_atom']*r['atoms'] for r in train], dtype=float)
delta, _, rank, _ = np.linalg.lstsq(A, -resid, rcond=None)
if rank < 3:
    raise RuntimeError(f'Insufficient composition rank for observed formula classes: {rank}')
if state[key].numel() != len(delta):
    raise RuntimeError(f'E0 buffer size mismatch {state[key].shape} vs {len(delta)}')
state[key] = state[key] + torch.as_tensor(delta, dtype=state[key].dtype).reshape_as(state[key])
model.load_state_dict(state)
torch.save(model, dest)
train_after = resid + A @ delta
formulas = sorted(set(''.join(f'{el}{n}' for el,n in sorted(composition[r['config_type']].items())) for r in train))
summary = {
 'source_model': str(source), 'calibrated_model': str(dest),
 'fit_data_split': 'train only', 'heldout_test_used_for_fit': False,
 'atomic_number_order': atomic_numbers, 'element_order': symbols,
 'per_element_atomic_energy_shift_eV': {el: float(d) for el,d in zip(symbols,delta)},
 'design_matrix_rank': int(rank), 'train_records': len(train), 'train_formula_classes': formulas,
 'train_energy_RMSE_before_eV_cell': float(np.sqrt(np.mean(resid**2))),
 'train_energy_RMSE_after_eV_cell': float(np.sqrt(np.mean(train_after**2))),
 'train_energy_residual_after_eV_cell': {r['config_type']: float(x) for r,x in zip(train,train_after)},
 'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
 'calibrated_sha256': hashlib.sha256(dest.read_bytes()).hexdigest(),
 'note': 'Only element-wise constant energy offsets were adjusted; gradients/forces and trajectories are unchanged.'
}
out=run/'energy_reference_calibration.json'
out.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
