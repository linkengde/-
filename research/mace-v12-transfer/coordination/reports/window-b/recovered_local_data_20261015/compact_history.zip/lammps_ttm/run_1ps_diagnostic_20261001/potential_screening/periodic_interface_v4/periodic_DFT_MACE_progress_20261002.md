# Periodic DFT → MACE progress

Date: 2026-10-02

## Current decision

The v6 MACE model passes the preliminary held-out **periodic small-cell** numerical screen. It is not approved for production or long MD because external Ag–C local-cluster force comparisons remain poor. A 500 eV PW-PBE reference on the same 48-atom geometry is running to compare force transfer and quantify the combined DFT basis and boundary-condition difference.

No production candidate, production potential, TTM setup, or old result was modified. A separate serial LAMMPS build without TTM ran only `run 0` on the 48-atom static cluster; no MD steps were advanced.

## Periodic PBE data and split

Thirteen 500 eV PW-PBE interface single points converged in the constructed coherent screening cells. The grouped MACE split is train 9 / validation 2 / test 2. The test structures are Si- and C-terminated 2.9 Å gap screens. The calculations are unrelaxed, small screening cells; the substrate motif is reconstructed from the supplied model and Ag has about 4.8% lateral strain.

Dataset manifest: `mace_periodic_v5/dataset_manifest.json`.

## v5 and v6 fitting

v5 used the standard foundation E0 and passed the force and direction screens, but its raw held-out energy MAE was 0.0618 eV/atom, above the 0.05 eV/atom screen. A train-only formula-offset diagnostic reduces that residual to 0.0104 eV/atom and relative gap-energy errors are ≤0.105 eV/cell; this is a diagnostic only, not an applied production correction.

v6 uses MACE's `estimated E0` initialized from the foundation model and training data. Its independent periodic test summary is `mace_periodic_v6/evaluation_retry2/summary.json`:

- Test force RMSE: 0.0342 eV/Å (limit 0.25)
- Ag–interface separating-force MAE: 0.0392 eV/Å (limit 0.30)
- Test energy MAE: 0.0110 eV/atom (limit 0.05)
- Separating-force sign accuracy: 100% (minimum 90%)
- Result: `PASS_SCREENING_THRESHOLDS`

This is a numerical pass only for the two held-out periodic configurations; it does not establish transfer to production geometry, thermal disorder, liquid Ag, or TTM dynamics.

## External Ag–C local-cluster transfer

On the separate 48-atom candidate Ag–C local cluster labeled with PBE/LCAO, v6 has total force RMSE 0.583 eV/Å and central Ag–C separating-force error about 0.897 eV/Å. v5 was about 0.577 eV/Å and 0.702 eV/Å, respectively. The LCAO basis and nonperiodic boundary differ from the PW-PBE training set, so this is a warning, not a method-matched verdict.

The PW-PBE calculation is in `pbe_cluster_transfer_pw_20261002_run1/`. It uses the same PBE/500 eV plane-wave method as the periodic labels, with a 1×1×1 k-point mesh and a 28 Å fully periodic vacuum box. The existing LCAO reference used nonperiodic boundaries, so the comparison tests both basis and boundary-condition sensitivity. As of 05:04 UTC it reached SCF iteration 25 (latest energy −259.121144 eV; density residual log₁₀ ≈ −1.77) and is **not converged** against the 10⁻⁵ criteria. No partial forces are used. GPAW in this environment is serial-only; MPI startup was checked and rejected because the installed GPAW is not MPI-enabled.

The LCAO-seeded conversion was stopped after over five minutes of orbital expansion without reaching PW SCF. A fresh run with a lower Pulay mixing coefficient reached SCF iteration 2 after its long initialization and remains active with iteration checkpoints. It uses the same physical settings as the original calculation; only the SCF mixer differs. Logs from earlier startup attempts are preserved separately.

## Standalone LAMMPS MACE interface check

A clean serial LAMMPS build with ML-IAP and Python support was made in a separate build directory; the original TTM executable was untouched. On the same 48-atom Ag–C cluster, LAMMPS `run 0` gave PE −280.037280 eV and Fmax 6.7617663 eV/Å. The independent ASE MACE v6 evaluation gave PE −280.03728414 eV and Fmax 6.76176627 eV/Å. Maximum component force difference was 4.93×10⁻⁶ eV/Å, consistent with LAMMPS dump rounding.

The largest force is on C source atom ID 602564 at (15.1767, 10.2003, 13.1515) Å. The designated central Ag–C pair (IDs 688433 and 604804) is 2.2026 Å apart. These are model predictions on an unrelaxed cluster, pending the PW-PBE comparison.

This confirms the serialized MACE model is loaded and computes matching energy/forces through this standalone LAMMPS ML-IAP build. It does not validate the potential against DFT, TTM compatibility, periodic MPI behavior, or production geometry.

## Existing local-cluster force scans

I reused 12 existing PBE/LCAO Ag–C, Ag–Si, and Ag–Ti local-cluster single points and distance-scan geometries. Across these related diagnostics, v6 force RMSE is 0.436 eV/Å and the mean absolute error in the marked pair's separating force is 0.612 eV/Å. v5 is similar at 0.434 eV/Å and 0.596 eV/Å. Individual Ag–C geometries still show large pair-force errors, including a sign error near 2.20 Å in the primary environment and about 0.90 eV/Å error in the secondary nearest-contact case.

These labels are PBE/LCAO with nonperiodic boundaries while the periodic training labels are PBE plane-wave. Treat this as a secondary transfer warning; the same-geometry plane-wave calculation is still needed to distinguish basis and boundary effects from model transfer error. Absolute energy differences across these labels are not interpreted because the energy offsets are not on a validated common reference.

## Artifacts

- v5 held-out metrics: `mace_periodic_v5/evaluation_retry2/summary.json`
- v5 formula and relative-energy analysis: `mace_periodic_v5/evaluation_retry2/energy_profile_analysis_v2.json`
- v5 raw training model: `mace_periodic_v5/models/Ag_Ti_Si_C_MACE_periodic_v5.model`
- v6 model: `mace_periodic_v6/models/Ag_Ti_Si_C_MACE_periodic_v6.model`
- v6 full per-structure and external-cluster comparison: `mace_periodic_v6/evaluation_retry2/`
- PW-PBE cluster script/log: `run_agc_cluster_pw_reference.py`, `pbe_cluster_transfer_pw_20261002_run1/gpaw.log`
- Alternate SCF attempts (stopped before SCF): `pbe_cluster_transfer_pw_20261002_run2_lcao_seed_retry1/gpaw.log`, `pbe_cluster_transfer_pw_20261002_run2_mixer_retry1/gpaw.log`
- Alternate-mixer PW-PBE run (SCF started): `run_agc_cluster_pw_reference_mixer_retry2.py`, `pbe_cluster_transfer_pw_20261002_run3_mixer_retry2/gpaw.log`
- Alternate-attempt SHA256 list: `alternate_scf_attempts.sha256`
- LAMMPS static run and ASE comparison: `lammps_v6_serial_run0_20261002/log.mace_v6_run0_serial_retry3`, `lammps_v6_serial_run0_20261002/lammps_ase_force_check.json`
- LAMMPS v6 force hotspot: `lammps_v6_serial_run0_20261002/lammps_v6_force_hotspot.json`
- LAMMPS command/build provenance and hashes: `lammps_v6_serial_run0_20261002/run_reproducibility.txt`, `lammps_v6_serial_run0_20261002/run_artifact_sha256_final.txt`
- Existing LCAO cluster transfer screen: `lcaocluster_transfer_20261002/summary.json`, `lcaocluster_transfer_20261002/per_case.csv`
- LCAO screen SHA256 list: `lcaocluster_transfer_20261002/checksums.sha256`

## Next gate

Finish the method-matched 48-atom PW-PBE reference. Compare its central Ag–C force and full force RMSE against v5/v6. If v6 fails that comparison, add targeted Ag–C local-environment structures to a new training set, preserve a fresh held-out structure, and retrain. No production or long MD before that gate and the later LAMMPS/TTM parallel-interface check.

## Update — v8 force-only candidate and isolated LAMMPS/TTM interface checks (2026-10-02 UTC)

### v8 force-only fit and reference checks

The current screening model is `mace_periodic_v8_forceonly/models/Ag_Ti_Si_C_MACE_periodic_v8_forceonly.model` (MACE 0.3.16, epoch 73 of 80). Its training set contains 17 force-labeled structures, of which 9 periodic PW-PBE frames also have energy labels; 8 local Ag-C/Ag-Si/Ag-Ti endpoint structures contribute forces only. Two periodic PW-PBE structures remain validation frames and two remain test frames.

- Periodic validation: 13.5 meV/atom energy RMSE and 38.4 meV/Å force RMSE.
- Periodic test: C-terminated contact 21.1 meV/atom and 49.1 meV/Å; Si-terminated contact 15.2 meV/atom and 15.7 meV/Å.
- Four local PBE/LCAO nearest-contact coordinates withheld from fitting: force RMSE 24.4 meV/Å; marked-pair separating-force MAE 0.168 eV/Å, maximum absolute error 0.229 eV/Å. These are interpolation checks within scan motifs whose endpoint forces were trained on, not new-motif or PW-PBE tests.
- One method-matched periodic PW-PBE Ag-C external point: force RMSE 0.0715 eV/Å and marked Ag-C force error −0.0010 eV/Å. Absolute energy is offset by −486.5 meV/atom, so do not use the current raw absolute energies as calibrated formation or cohesive energies.
- The secondary Ag-C relative-energy profile has a 12.3 meV error over the tested 2.0–2.4 Å interval, but it is only one local motif and three distances.

Status: promising screening candidate for forces in sampled local environments; **broad transfer validation remains incomplete**. The existing independent PW-PBE set has one Ag-C motif check. New Ag-Ti and Ag-Si periodic PW-PBE single points are running under `pbe_external_v8_motif_holdouts/AgTi/retry1/` and `pbe_external_v8_motif_holdouts/AgSi/retry1/`; both SCF results are pending. They use 49- and 51-atom local clusters, not a production-cell run.

The v8 LCAO evaluator had stale v7 labels. The original artifacts are retained; corrected labels and wording are in `mace_periodic_v8_forceonly/evaluation_lcao_cluster_transfer/per_case_v8_labels_corrected.csv` and `summary_v8_labels_corrected.json`. Metrics are unchanged.

### LAMMPS MACE interface

An isolated serial build of LAMMPS 30Sep2026 adds an atom-tag view to `MLIAPDataPy` and a single-rank periodic exchange adapter. In a 48-atom Ag-C cluster translated across the periodic x boundary, LAMMPS exposed 48 ghost atoms and all 48 mapped to owned atom IDs. Static `run 0` matched ASE: PE difference 4.55×10⁻⁶ eV; maximum force-component difference 4.99×10⁻⁶ eV/Å; force-vector RMSE 3.15×10⁻⁶ eV/Å.

The checks are recorded in `mace_periodic_v8_forceonly/lammps_v8_periodic_serial_run0_20261003/`. This custom adapter explicitly does **not** implement MPI exchange; it throws if a ghost's owner is on another rank. It therefore cannot be used for domain-decomposed production runs as built.

### TTM interface check

The same isolated executable was rebuilt with the existing `EXTRA-FIX` `ttm/thermal` style. On the same 48-atom periodic test geometry, `run 0` with a one-cell uniform 300 K grid, zero electron-lattice coupling, and zero source completed at step 0. LAMMPS reported 48 atoms, electronic-grid energy 6,585,600 (in the configured `Ce=1`, 28 Å cube test units), and net transfer 0; MACE/ASE PE and forces retained the parity above. This only verifies that the code paths coexist in a serial static calculation. The grid material properties are deliberately artificial, and **no thermal exchange, heating, MD step, MPI, restart, or physical TTM behavior was tested**.

Evidence: `mace_periodic_v8_forceonly/lammps_v8_periodic_ttm_run0_20261003/log.mace_v8_periodic_ttm_run0`, `lammps_ase_ttm_run0_check.json`, `ttm_properties_1x1x1.dat`, and `run_artifact_sha256.txt`.

### Current decision

- MACE v8: **PASS_SCREENING** for the sampled force checks; **NOT_ESTABLISHED** as a broad Ag/Ti/Si/C cross-potential.
- LAMMPS serial periodic static parity: **PASS**.
- Serial MACE + `ttm/thermal` static coexistence: **PASS for run 0 only**.
- MPI/ghost exchange, physical TTM coupling, restart continuity with MACE v8, thermally disordered interface validation, and production-cell transfer: **NOT TESTED / NOT CLEARED**.
- No candidate model, production potential, or long-MD result was changed or generated. The only dynamics count in these interface checks is zero.

## Update — independent Ag–Ti and Ag–Si PW-PBE holdouts (2026-10-03 UTC)

Two independent 500 eV periodic PW-PBE single points are active on the MACE v8 nearest-contact Ag–Ti and Ag–Si motifs. They use the same DFT settings as the existing external Ag–C point. As of 01:12 UTC, Ag–Ti had reached SCF iteration 15 and Ag–Si iteration 14; neither has a final `summary.json`, so neither is converged or scored yet. Each SCF iteration currently takes roughly six minutes. The jobs use about 18 GiB combined resident memory; `/workspace` has about 12 GiB free. No MD is running.

Before results arrive, corrected `evaluate_pw_mace_holdout.py` to read the files from each `retry1/` output directory (the original evaluator path did not match the runner's directory layout) and to refuse scoring unless `summary.json` records `scf_converged=true`. The running DFT input and existing results were not changed. Holdout structures, DFT logs, provenance hashes, and future comparisons remain in `pbe_external_v8_motif_holdouts/{AgTi,AgSi}/retry1/`.

These are local interface motifs, not production cells. Until both converged PW force comparisons are available, cross-potential transfer remains **INCOMPLETE** and no long MD is cleared.

## Update — external Ag–Ti / Ag–Si PW-PBE holdout completion

Independent periodic PW-PBE 500 eV single-point checks on nearest-contact local motifs have exited. These motifs supplement the external Ag–C check; they do not validate thermal disorder or production-cell transfer.

### AgTi: INCONCLUSIVE

Reason: process exited without summary.json.

### AgSi: INCONCLUSIVE

Reason: process exited without summary.json.

Interpretation: two additional nearest-contact motifs were scored against converged PW-PBE labels. At least one result is inconclusive; the cross-potential remains unvalidated for that contact and production MD is not cleared.

## Correction and recovered scoring — Ag–Ti / Ag–Si PW-PBE holdouts (2026-10-03 UTC)

The watcher initially marked both calculations `INCONCLUSIVE` because the runner stopped before writing `summary.json`. This was a post-processing gap, not an SCF failure: each GPAW log explicitly reports convergence, and each converged force-labelled extxyz and final `state.gpw` had been written. Reconstructed summaries from those artifacts and completed the v8 force comparisons. The earlier `INCONCLUSIVE` labels are superseded by these recovered results.

| Contact | SCF | Component force RMSE (eV/Å) | Max force-vector error (eV/Å) | Marked-pair force error (eV/Å) | Absolute energy error (meV/atom) |
|---|---:|---:|---:|---:|---:|
| Ag–Ti, 2.3871 Å | converged, 36 iterations | 0.0695 | 0.4577 | +0.7201 | +86.95 |
| Ag–Si, 2.4541 Å | converged, 49 iterations | 0.0503 | 0.1595 | +0.1232 | −120.40 |

Against the project's existing 0.30 eV/Å marked-pair screening limit, Ag–Si passes this sampled contact and Ag–Ti fails. Both overall component RMSE values are below 0.25 eV/Å, but the Ag–Ti contact force mismatch is the controlling issue. The energy offsets are not an energy-validation pass; local-cluster absolute energies remain uncalibrated. These checks change both the DFT basis and the boundary treatment relative to the earlier non-periodic LCAO cluster labels, and cover only one geometry per contact.

Decision: **MACE v8 is not cleared for Ag–Ti interface dynamics or long MD.** Next, add method-matched Ag–Ti PW-PBE force data to a new training version and retain a separate Ag–Ti PW-PBE geometry for validation. Preserve v8 and these holdout artifacts unchanged. Ag–Si remains a single-point screening pass, not broad validation. No MD was run.

## Update — v9 targeted Ag–Ti retraining and next holdout (2026-10-03 UTC)

MACE v9 training completed at 04:12 UTC. Its training set has 18 force-labelled structures and 9 energy-labelled structures; the new frame is the converged Ag–Ti 2.3871 Å periodic PW-PBE force label. The local-cluster absolute energy was excluded. The selected checkpoint was epoch 53. Periodic test errors are 50.4 meV/Å force and 25.8 meV/atom energy for the C-gap frame, and 15.8 meV/Å force and 24.1 meV/atom energy for the Si-gap frame. These remain periodic screening metrics and do not establish Ag–Ti transfer.

A new periodic PW-PBE single point is now running at the Ag–Ti 2.7 Å scan geometry. This geometry was an LCAO force-training point, so this holdout tests transfer between the LCAO and plane-wave methods at a second Ag–Ti separation; it is not a novel coordination motif. At 05:12 UTC it had reached SCF iteration 10. The workflow will compare both v8 and v9 against the converged PW forces and record the result. No MD has been started.

## Ag–Ti 2.7 Å PW-PBE cross-method holdout after v9 (2026-10-03 UTC)

This independent PW-PBE single point uses the existing Ag-Ti 2.7 Å LCAO scan geometry. It checks method transfer at an already represented geometry, not a new coordination motif. The Ag-Ti 2.387 Å PW-PBE force frame was added force-only to v9; its energy was excluded.

v8 baseline: not scored (DFT runner exited without writing summary.json).

v9 candidate: not scored (DFT runner exited without writing summary.json).

Interpretation: this is a small local-cluster force screen only. It does not clear production transfer, thermal disorder, MPI/TTM dynamics, or long MD.

## Correction — recovered Ag–Ti 2.7 Å DFT summary and v8/v9 scoring (2026-10-03 07:57:05 UTC)

The workflow initially marked this calculation INCONCLUSIVE because the runner exited with code 1 after GPAW had converged and written the force-labelled extxyz. The failure was post-processing only: GPAW 26.7.0 returned an ASECalculator without the `calc.scf` attribute expected by the runner. The log explicitly says `Converged in 37 steps`; the 49-atom force-labelled extxyz has finite forces and exactly matches the calculation input in atom order, IDs, central-pair flags, positions, and cell. A recovered summary and provenance record were written, then both models were scored with the existing evaluator. This correction supersedes the preceding INCONCLUSIVE workflow status.

| Model | Component force RMSE (eV/Å) | Maximum force-vector error (eV/Å) | Ag–Ti pair force error (eV/Å) | Absolute energy offset (meV/atom) |
|---|---:|---:|---:|---:|
| v8 | 0.054485 | 0.261092 | -0.071283 | +86.112 |
| v9 | 0.046083 | 0.225166 | -0.067879 | +75.474 |

Both models are under the existing 0.30 eV/Å marked-pair screening limit at this one 2.7 Å geometry. v9 has lower sampled component RMSE (0.0461 vs 0.0545 eV/Å) and pair-force error magnitude (0.0679 vs 0.0713 eV/Å). The absolute energy offsets remain uncalibrated and are not an energy-validation pass. This is a method-transfer check on a geometry already present in the LCAO scan, not a novel coordination motif or thermal structure. It does not clear broad Ag–Ti/Ag–Si/Ag–C transfer, TTM/MPI dynamics, or long MD; no MD was run.

## v9 scoring on existing Ag–Si and Ag–C PW-PBE labels (2026-10-03 08:02:36 UTC)

Using the converged periodic PW-PBE force labels, v9 was evaluated on an Ag–Si holdout explicitly excluded from the v9 training set and on an Ag–C structure with the same geometry as an existing LCAO transfer reference. The Ag–C result therefore checks method transfer on a known geometry, not geometry generalization.

| Contact | Distance (Å) | Component force RMSE (eV/Å) | Max vector error (eV/Å) | Marked-pair force error (eV/Å) | Energy offset (meV/atom) |
|---|---:|---:|---:|---:|---:|
| Ag–Si independent PW holdout | 2.4541 | 0.046019 | 0.154539 | +0.127347 | -129.696 |
| Ag–C PW method transfer | 2.2026 | 0.060149 | 0.190640 | +0.062269 | -495.508 |

Both sampled pair-force errors are below the existing 0.30 eV/Å screening limit. The large Ag–C absolute energy offset and the Ag–Si energy offset are uncalibrated, so energy accuracy is not established. These sparse local checks do not establish thermal or production-cell transfer and do not clear long MD.

## Ag–Ti 2.55 Å PW-PBE holdout started (2026-10-03 08:04 UTC)

A new 49-atom periodic PW-PBE single point is running at an interpolated 2.55 Å Ag–Ti separation between the existing 2.1 and 2.7 Å scan geometries. This is a new distance in the same local motif; v8/v9 are unchanged. GPAW 26.7.0 convergence is detected from its explicit log marker to avoid the earlier post-processing API error. The workflow will score both models after the force label is verified. No MD is running.

## New Ag-Ti 2.55 Å PW-PBE interpolation holdout (2026-10-03 10:56:11 UTC)

This new 49-atom periodic PW-PBE reference uses an interpolated 2.55 Å central Ag–Ti separation between existing 2.1 and 2.7 Å scan endpoints. It is a new geometry in the same local interface motif, not a novel coordination motif. The two source geometries and their hashes are recorded in summary.json.

| Model | Component force RMSE (eV/Å) | Maximum force-vector error (eV/Å) | Ag–Ti pair force error (eV/Å) | Energy offset (meV/atom) |
|---|---:|---:|---:|---:|
| v8 | 0.055191 | 0.266196 | +0.250687 | +86.196 |
| v9 | 0.043879 | 0.183702 | +0.087882 | +75.442 |

This remains a local force screen; absolute energies are uncalibrated. Passing this one new separation would not validate thermally disordered coordination, production-size transfer, MPI/TTM, or long MD. No MD was run.

## MACE v9 one-step LAMMPS serial smoke check (2026-10-03 12:56:03 UTC)

The periodic 49-atom Ag–Ti 2.55 Å geometry was checked with the v9 model in the custom single-rank LAMMPS MLIAP adapter. Run 0 parity: energy error 2.864e-06 eV; force-component max error 4.996e-06 eV/Å; force RMSE 1.340e-06 eV/Å. A subsequent unheated NVE `run 1` ended at step 1 with 49 atoms. This checks only serial one-step plumbing; MPI, physical TTM coupling/restart, and production scale remain untested. No long MD was run.

## Correction — v9 LAMMPS run-0 false failure classification (2026-10-03 12:56:52 UTC)

The first unshifted run-0 actually returned code 0 with 49 atoms and finite results. Its ASE parity was energy error 2.883e-06 eV and maximum force-component error 4.995e-06 eV/Å. The initial checker falsely matched the echoed `thermo_modify norm no lost error` input and Fontconfig cache warnings. That geometry had no ghosts, so a separate periodic-equivalent translation retry exercised 49 ghost copies; its v9 run-0 parity also passed and the subsequent unheated NVE run reached step 1. The initial false status is corrected in lammps_smoke_status.json; retry2 evidence is kept separately.
