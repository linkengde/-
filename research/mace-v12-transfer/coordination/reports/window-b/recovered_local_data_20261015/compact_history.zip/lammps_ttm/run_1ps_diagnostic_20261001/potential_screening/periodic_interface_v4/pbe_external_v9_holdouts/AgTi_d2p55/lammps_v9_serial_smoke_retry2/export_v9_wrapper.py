import sys, torch
sys.path.insert(0, '/workspace/.local/lammps-ttm/run_1ps_diagnostic_20261001/potential_screening/lammps_mace_integration')
from mliap_periodic_serial_compat import LAMMPS_MLIAP_MACE_PeriodicSerial
model = torch.load('/workspace/.local/lammps-ttm/run_1ps_diagnostic_20261001/potential_screening/periodic_interface_v4/mace_periodic_v9_forceonly/models/Ag_Ti_Si_C_MACE_periodic_v9_forceonly.model', map_location="cpu", weights_only=False).double().cpu()
model.lammps_mliap = True
wrapper = LAMMPS_MLIAP_MACE_PeriodicSerial(model, head="Default")
torch.save(wrapper, '/workspace/.local/lammps-ttm/run_1ps_diagnostic_20261001/potential_screening/periodic_interface_v4/pbe_external_v9_holdouts/AgTi_d2p55/lammps_v9_serial_smoke_retry2/mace_v9_periodic_serial_compat.pt')
print("wrapper saved", '/workspace/.local/lammps-ttm/run_1ps_diagnostic_20261001/potential_screening/periodic_interface_v4/pbe_external_v9_holdouts/AgTi_d2p55/lammps_v9_serial_smoke_retry2/mace_v9_periodic_serial_compat.pt', "cutoff_A", float(model.r_max))
