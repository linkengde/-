from pathlib import Path
import json
import numpy as np
import torch
from ase.io import read,write
from mace.calculators import MACECalculator
ROOT=Path(__file__).resolve().parent
src=Path('/workspace/.local/lammps-ttm/run_1ps_diagnostic_20261001/potential_screening/periodic_interface_v1/structures/Ti3SiC2_bulk_orthorhombic.extxyz')
model=Path('/workspace/.local/cache/mace/mace-mp-0b3-medium.model')
out=ROOT/'mace_mp_bulk_relax_seed';out.mkdir(exist_ok=False)
torch.set_default_dtype(torch.float64)
calc=MACECalculator(model_paths=[str(model)],device='cpu',default_dtype='float64')
a=read(src);a.calc=calc
e=float(a.get_potential_energy());f=np.asarray(a.get_forces());n=np.linalg.norm(f,axis=1)
np.savetxt(out/'forces.csv',np.column_stack((np.arange(1,len(a)+1),f)),delimiter=',',header='atom_index,fx,fy,fz',comments='')
r={'energy_eV':e,'energy_eV_atom':e/len(a),'Fmax_eV_A':float(n.max()),'Fmax_atom_index':int(n.argmax()+1),'force_RMS_eV_A':float(np.sqrt(np.mean(f*f))),'note':'MACE-MP-0b3 is used only as a geometry-search seed; PBE will decide final reference.'}
(out/'summary.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
