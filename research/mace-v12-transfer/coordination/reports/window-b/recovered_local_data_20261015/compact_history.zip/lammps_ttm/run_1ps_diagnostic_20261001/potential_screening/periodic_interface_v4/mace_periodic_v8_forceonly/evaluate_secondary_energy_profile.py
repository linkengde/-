#!/usr/bin/env python3
"""Check relative Ag-C energy curve without using the LCAO energies in training."""
from pathlib import Path
import json
import numpy as np
import torch
from ase.io import read
from mace.calculators import MACECalculator
ROOT=Path(__file__).resolve().parent
PROJECT=ROOT.parent
SCREEN=PROJECT.parent/'composition_candidate_screen/interface_contact_scan'
OUT=ROOT/'evaluation_secondary_energy_profile.json'
if OUT.exists(): raise SystemExit(f'Refusing to overwrite {OUT}')
scan=SCREEN/'AgC_environment_distance_scans_PBE_v1/secondary'
base_lcao=json.loads((SCREEN/'AgC_secondary/pbe/summary.json').read_text())
pwdir=PROJECT/'pbe_cluster_transfer_pw_20261002_run3_mixer_retry2'
pwmeta=json.loads((pwdir/'summary.json').read_text())
center=read(pwdir/'AgC_cluster_PW_PBE.extxyz')
endpoints=[]
for tag in ('d2.0','d2.4'):
 p=scan/tag
 a=read(p/'input.extxyz');m=json.loads((p/'summary.json').read_text())
 endpoints.append((float(m['target_distance_A']),a,float(m['PBE_energy_eV'])))
torch.set_default_dtype(torch.float64)
models={}
for label,path in {
 'v6':PROJECT/'mace_periodic_v6/models/Ag_Ti_Si_C_MACE_periodic_v6.model',
 'v8_forceonly':ROOT/'models/Ag_Ti_Si_C_MACE_periodic_v8_forceonly.model'}.items():
 model=torch.load(path,map_location='cpu',weights_only=False).double().eval()
 models[label]=MACECalculator(models=[model],device='cpu',default_dtype='float64')
rows=[]
for label,calc in models.items():
 c=center.copy();c.calc=calc;ec=float(c.get_potential_energy())
 for dist,a,dft_lcao_e in endpoints:
  x=a.copy();x.calc=calc;em=float(x.get_potential_energy())
  rows.append({'model':label,'distance_A':dist,'model_energy_eV':em,
    'model_delta_from_2.2026_eV':em-ec,
    'DFT_LCAO_delta_from_2.2026_eV':dft_lcao_e-float(base_lcao['PBE_energy_eV']),
    'relative_energy_error_eV':(em-ec)-(dft_lcao_e-float(base_lcao['PBE_energy_eV']))})
by={m:[r for r in rows if r['model']==m] for m in models}
metrics={m:{'relative_energy_MAE_eV':float(np.mean([abs(r['relative_energy_error_eV']) for r in rr])),
            'DFT_LCAO_center_eV':float(base_lcao['PBE_energy_eV']),
            'PW_center_eV':float(pwmeta['energy_eV_cell']),
            'LCAO_minus_PW_center_eV':float(base_lcao['PBE_energy_eV'])-float(pwmeta['energy_eV_cell'])}
        for m,rr in by.items()}
summary={'reference_note':'At d=2.0 and 2.4 A use existing PBE/LCAO endpoint energies; the exact 2.202603 A geometry has both LCAO and converged periodic PW-PBE energies. Relative differences remove their common energy offset at the central geometry.',
 'training_note':'The forceonly model did not train on the endpoint energies; the endpoint forces were included. Relative energies are therefore not direct energy-label fits.',
 'models':metrics,'points':rows,
 'caveat':'Two scan endpoints in one secondary local environment; this does not validate a full interface energy surface or thermal/liquid configurations.'}
OUT.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
