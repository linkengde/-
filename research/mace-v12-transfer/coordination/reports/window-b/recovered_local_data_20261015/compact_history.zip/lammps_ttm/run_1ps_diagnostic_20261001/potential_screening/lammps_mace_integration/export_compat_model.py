from pathlib import Path

import torch

from mliap_serial_compat import LAMMPS_MLIAP_MACE_SerialCompat


MODEL = Path("/workspace/.local/cache/mace/mace-mp-0b3-medium.model")
OUT = Path(__file__).resolve().parent / "mace_mp_0b3_mliap_serial_compat.pt"

if OUT.exists():
    raise SystemExit(f"Refusing to overwrite existing file: {OUT}")

model = torch.load(MODEL, map_location="cpu", weights_only=False)
model = model.double().cpu()
model.lammps_mliap = True
wrapper = LAMMPS_MLIAP_MACE_SerialCompat(model, head="default")
torch.save(wrapper, OUT)
print(f"Saved {OUT}")
print(f"Elements in MACE model: {len(wrapper.element_types)}")
print(f"Cutoff: {float(model.r_max):.6f} Angstrom")
