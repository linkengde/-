from pathlib import Path
import csv,json,math
root=Path(__file__).resolve().parent
out=root/'lcaocluster_transfer_20261002'
with (out/'per_case.csv').open() as f: rows=list(csv.DictReader(f))
summary={'cases':len(rows),'case_names':[r['case'] for r in rows],
'reference_note':'All labels are existing GPAW PBE/LCAO cluster single points. They are a secondary diagnostic because periodic MACE training labels are PW-PBE.',
'models':{}}
for m in ('v5','v6'):
    w=sum(float(r[f'{m}_force_RMSE_eV_A'])**2*3*int(r['atoms']) for r in rows)
    n=sum(3*int(r['atoms']) for r in rows)
    p=[abs(float(r[f'{m}_pair_force_error_eV_A'])) for r in rows]
    summary['models'][m]={'all_component_force_RMSE_eV_A':math.sqrt(w/n),'pair_force_MAE_eV_A':sum(p)/len(p)}
summary['files']={'per_case_csv':str(out/'per_case.csv')}
with (out/'summary.json').open('x') as f: json.dump(summary,f,indent=2);f.write('\n')
print(json.dumps(summary,indent=2))
