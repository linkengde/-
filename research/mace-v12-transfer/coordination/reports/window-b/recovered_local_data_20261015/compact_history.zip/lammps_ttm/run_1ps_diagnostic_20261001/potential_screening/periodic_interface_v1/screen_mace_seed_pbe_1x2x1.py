#!/usr/bin/env python3
from pathlib import Path
import json,os
import numpy as np
import gpaw_data
from ase.io import read,write
os.environ['GPAW_SETUP_PATH']=str(gpaw_data.datapath())
from gpaw import GPAW
from gpaw.mixer import Mixer
from gpaw.occupations import FermiDirac
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'mace_seed_pbe_1x2x1';OUT.mkdir(exist_ok=False)
SRC=Path('/workspace/.local/lammps-ttm/run_1ps_diagnostic_20261001/potential_screening/periodic_interface_v2/mace_mp_bulk_relax_seed/Ti3SiC2_mace_pre_relaxed.extxyz')
a=read(SRC);a.calc=GPAW(mode='lcao',basis='dzp',xc='PBE',kpts=(1,2,1),occupations=FermiDirac(.1),mixer=Mixer(.15,5,100),convergence={'energy':1e-3,'density':1e-3,'eigenstates':1e-3},maxiter=80,txt=str(OUT/'gpaw.log'))
e=float(a.get_potential_energy());f=np.asarray(a.get_forces());n=np.linalg.norm(f,axis=1);log=(OUT/'gpaw.log').read_text(errors='replace').lower()
if 'converged' not in log or 'failed to converge' in log:raise RuntimeError('PBE screening SCF did not converge')
np.savetxt(OUT/'forces.csv',np.column_stack((np.arange(1,len(a)+1),f)),delimiter=',',header='atom_index,fx_eV_A,fy_eV_A,fz_eV_A',comments='')
write(OUT/'Ti3SiC2_pbe_screened.extxyz',a,format='extxyz');a.calc.write(OUT/'state.gpw')
r={'status':'PBE_screening_static_converged','atoms':len(a),'cell_A':a.cell.array.tolist(),'kpts':[1,2,1],'scf_thresholds':{'energy':1e-3,'density':1e-3,'eigenstates':1e-3},'energy_eV':e,'energy_eV_atom':e/len(a),'max_force_eV_A':float(n.max()),'max_force_atom_index':int(n.argmax()+1),'max_force_element':a[int(n.argmax())].symbol,'force_RMS_eV_A':float(np.sqrt(np.mean(f*f))),'note':'Coarse geometry/SCF screen only; selected structure requires high-k-point and tighter-threshold PBE confirmation.'}
(OUT/'summary.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
