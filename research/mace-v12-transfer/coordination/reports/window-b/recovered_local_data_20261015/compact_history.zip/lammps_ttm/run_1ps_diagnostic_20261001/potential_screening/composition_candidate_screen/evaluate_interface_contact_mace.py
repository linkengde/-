from pathlib import Path
import csv
import json

import numpy as np
from ase.io import read
from mace.calculators import mace_mp


ROOT = Path(__file__).resolve().parent
SCAN = ROOT / "interface_contact_scan"
OUT = SCAN / "mace"
MODEL = Path("/workspace/.local/cache/mace/mace-mp-0b3-medium.model")
if OUT.exists():
    raise SystemExit(f"Refusing to reuse existing output directory: {OUT}")
OUT.mkdir()
calculator = mace_mp(model=str(MODEL), device="cpu", default_dtype="float64")
summary = []

for symbol in ("Ti", "Si", "C"):
    atoms = read(SCAN / f"candidate_Ag_{symbol}_R6.extxyz")
    ids = atoms.arrays["lammps_id"].astype(int)
    pair_mask = atoms.arrays["central_pair"].astype(bool)
    pair_ids = ids[pair_mask]
    pair_symbols = atoms.get_chemical_symbols()
    if len(pair_ids) != 2:
        raise SystemExit(f"Expected 2 central atoms in Ag-{symbol} cluster, got {len(pair_ids)}")
    ag_id = int(next(atom_id for atom_id, el, selected in zip(ids, pair_symbols, pair_mask) if selected and el == "Ag"))
    scaffold_id = int(next(atom_id for atom_id, el, selected in zip(ids, pair_symbols, pair_mask) if selected and el == symbol))
    ia = int(np.flatnonzero(ids == ag_id)[0])
    ib = int(np.flatnonzero(ids == scaffold_id)[0])
    vector = atoms.positions[ib] - atoms.positions[ia]
    distance = float(np.linalg.norm(vector))
    unit = vector / distance
    atoms.calc = calculator
    energy = float(atoms.get_potential_energy())
    forces = atoms.get_forces()
    norms = np.linalg.norm(forces, axis=1)
    separating = float(np.dot(forces[ib] - forces[ia], unit))
    row = {
        "pair": f"Ag-{symbol}", "atoms": len(atoms),
        "Ag_id": ag_id, "scaffold_id": scaffold_id,
        "distance_A": distance,
        "MACE_energy_eV": energy,
        "MACE_pair_separating_force_eV_per_A": separating,
        "max_force_norm_eV_per_A": float(norms.max()),
        "max_force_id": int(ids[int(norms.argmax())]),
    }
    summary.append(row)
    force_path = OUT / f"candidate_Ag_{symbol}_forces.csv"
    with force_path.open("x", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["lammps_id", "symbol", "fx_eV_A", "fy_eV_A", "fz_eV_A", "force_norm_eV_A"])
        for atom_id, atom, force, norm in zip(ids, atoms, forces, norms):
            writer.writerow([int(atom_id), atom.symbol, *map(float, force), float(norm)])
    print(row, flush=True)

(OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
