#!/usr/bin/env bash
set -u

midgap_pid="${1:?pass the active intermediate-gap DFT queue PID}"
root="/workspace/.local/lammps-ttm/run_1ps_diagnostic_20261001/potential_screening/periodic_interface_v4"
run="$root/mace_periodic_v5"
midgap_log="$root/alt_midgap_scan_serial_launcher.log"
status_log="$root/mace_periodic_v5_queue_retry1.log"
gpaw_python="/workspace/.local/venvs/gpaw/bin/python"
mace_python="/workspace/.local/venvs/mace/bin/python"
mace_train="/workspace/.local/venvs/mace/bin/mace_run_train"

while :; do
  if rg -q 'All intermediate Si/C gap scans completed and converged\.' "$midgap_log" 2>/dev/null; then
    break
  fi
  if rg -q 'STOP:' "$midgap_log" 2>/dev/null; then
    echo "STOP: an intermediate Si/C DFT scan failed; MACE training was not started." >> "$status_log"
    exit 1
  fi
  if ! kill -0 "$midgap_pid" 2>/dev/null; then
    echo "STOP: intermediate DFT queue ended without a completion marker." >> "$status_log"
    exit 1
  fi
  sleep 20
done

echo "All queued periodic PW-PBE labels are converged; assembling grouped dataset." >> "$status_log"
mkdir -p "$run"
if [[ -s "$run/dataset_manifest.json" && -s "$run/data/train.extxyz" && -s "$run/data/valid.extxyz" && -s "$run/data/test.extxyz" ]]; then
  echo "Reusing verified dataset assembled before queue restart." >> "$status_log"
else
  "$gpaw_python" "$root/build_periodic_mace_dataset.py" > "$run/dataset_build_attempt1.log" 2>&1
  status=$?
  if [[ "$status" -ne 0 ]]; then
    echo "STOP: dataset assembly failed with status $status." >> "$status_log"
    exit "$status"
  fi
fi

mkdir -p "$run/models" "$run/checkpoints" "$run/results" "$run/logs" "$run/train_work"
export MPLCONFIGDIR=/tmp/mplconfig
export XDG_CACHE_HOME=/tmp/xdg-cache
export OMP_NUM_THREADS=4
export MKL_NUM_THREADS=4
export OPENBLAS_NUM_THREADS=1

echo "Starting CPU fine-tuning from MACE-MP-0b3 on same-method periodic data." >> "$status_log"
"$mace_train" \
  --name=Ag_Ti_Si_C_MACE_periodic_v5 \
  --seed=42 \
  --work_dir="$run/train_work" \
  --log_dir="$run/logs" \
  --model_dir="$run/models" \
  --checkpoints_dir="$run/checkpoints" \
  --results_dir="$run/results" \
  --device=cpu \
  --default_dtype=float64 \
  --train_file="$run/data/train.extxyz" \
  --valid_file="$run/data/valid.extxyz" \
  --test_file="$run/data/test.extxyz" \
  --energy_key=REF_energy \
  --forces_key=REF_forces \
  --foundation_model=/workspace/.local/cache/mace/mace-mp-0b3-medium.model \
  --E0s=foundation \
  --multiheads_finetuning=True \
  --batch_size=1 \
  --valid_batch_size=1 \
  --lr=0.0001 \
  --energy_weight=1.0 \
  --forces_weight=1000.0 \
  --max_num_epochs=80 \
  --patience=20 \
  --eval_interval=1 \
  --num_workers=0 \
  --plot=False > "$run/train.stdout" 2>&1
status=$?
if [[ "$status" -ne 0 ]]; then
  echo "STOP: MACE training failed with status $status." >> "$status_log"
  exit "$status"
fi

model="$run/models/Ag_Ti_Si_C_MACE_periodic_v5.model"
if [[ ! -s "$model" ]]; then
  echo "STOP: training exited but the expected model file is missing: $model" >> "$status_log"
  exit 1
fi

echo "Training finished; evaluating periodic held-out structures and external clusters." >> "$status_log"
"$mace_python" "$root/evaluate_periodic_mace_v5.py" > "$run/evaluation.stdout" 2>&1
status=$?
if [[ "$status" -ne 0 ]]; then
  echo "STOP: MACE evaluation crashed with status $status." >> "$status_log"
  exit "$status"
fi
if ! "$gpaw_python" -c 'import json,sys; sys.exit(0 if json.load(open(sys.argv[1]))["status"] == "PASS_SCREENING_THRESHOLDS" else 1)' "$run/evaluation/summary.json"; then
  echo "MODEL_NOT_PASSED: held-out criteria failed; no LAMMPS/MD stage was launched." >> "$status_log"
  exit 2
fi
echo "MACE passed the initial held-out numerical screen; no MD was launched." >> "$status_log"
