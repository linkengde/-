from pathlib import Path
import sys
import torch

HERE = Path(__file__).resolve().parent
V8 = HERE.parent
INTEGRATION = V8.parent.parent / "lammps_mace_integration"
sys.path.insert(0, str(INTEGRATION))
from mliap_periodic_serial_compat import LAMMPS_MLIAP_MACE_PeriodicSerial

model_path = V8 / "models/Ag_Ti_Si_C_MACE_periodic_v8_forceonly.model"
out = HERE / "mace_v8_periodic_serial_compat.pt"
if out.exists():
    raise SystemExit(f"Refusing to overwrite {out}")
model = torch.load(model_path, map_location="cpu", weights_only=False).double().cpu()
model.lammps_mliap = True
wrapper = LAMMPS_MLIAP_MACE_PeriodicSerial(model, head="Default")
torch.save(wrapper, out)
print(f"model={model_path}")
print(f"wrapper={out}")
print(f"elements={wrapper.element_types}")
print(f"cutoff_A={float(model.r_max)}")
