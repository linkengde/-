#!/usr/bin/env python3
"""Apply the existing nonperiodic-cluster MACE v3 pilot to the periodic interface geometries."""
from pathlib import Path
import csv, json
import numpy as np
import torch
from ase.io import read
from mace.calculators import MACECalculator
ROOT=Path(__file__).resolve().parent
MODEL=Path('/workspace/.local/lammps-ttm/run_1ps_diagnostic_20261001/potential_screening/composition_candidate_screen/mace_finetune_pilot_v3/checkpoints_export_epoch48/Ag_Ti_Si_C_MACE_finetune_pilot_v3_run-42.model')
OUT=ROOT/'mace_v3_predictions';OUT.mkdir(exist_ok=False)
torch.set_default_dtype(torch.float64)
model=torch.load(MODEL,map_location='cpu',weights_only=False).double().eval()
calc=MACECalculator(models=[model],device='cpu',default_dtype='float64')
rows=[]
for tag in ('d2.3','d2.6','d2.9'):
 a=read(ROOT/'structures'/f'Ti_term_Ag111_periodic_{tag}.extxyz');a.calc=calc
 e=float(a.get_potential_energy());f=np.asarray(a.get_forces());n=np.linalg.norm(f,axis=1);sy=a.get_chemical_symbols()
 np.savetxt(OUT/f'{tag}_forces.csv',np.column_stack((np.arange(1,len(a)+1),np.asarray([{'Ti':1,'Si':2,'C':3,'Ag':4}[s] for s in sy]),a.positions,f)),delimiter=',',header='atom_index,type,x_A,y_A,z_A,fx_eV_A,fy_eV_A,fz_eV_A',comments='')
 r={'geometry':tag,'atoms':len(a),'energy_eV':e,'energy_eV_atom':e/len(a),'force_RMS_eV_A':float(np.sqrt(np.mean(f*f))),'Fmax_eV_A':float(n.max()),'Fmax_atom_index':int(n.argmax()+1),'Fmax_element':sy[int(n.argmax())],'pbc':[bool(x) for x in a.pbc],'note':'Prediction from MACE v3 trained on local nonperiodic clusters; no periodic-interface training data in that model.'}
 rows.append(r);print(json.dumps(r),flush=True)
(OUT/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
