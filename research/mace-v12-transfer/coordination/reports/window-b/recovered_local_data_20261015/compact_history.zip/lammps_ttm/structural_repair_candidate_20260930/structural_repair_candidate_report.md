# Ag 填充结构修复候选报告

日期：2026-09-30  
原模型：`/workspace/.local/lammps-ttm/run-upload-20260930/stage65_model_150x300x300.data`  
候选目录：`/workspace/.local/lammps-ttm/structural_repair_candidate_20260930`

## 结果

已生成一个保留 Ti₃SiC₂ 骨架几何的 FCC Ag 填充候选：[stage65_model_fcc_ag_interface_clearance.data](stage65_model_fcc_ag_interface_clearance.data)。候选保留了原有 469,683 个 Ti/Si/C 原子的全部 ID、类型和周期坐标，逐 ID 比较的最大坐标差为 0 Å。LAMMPS 的 TTM `run 0` 通过，step=0、540,078 atoms，无报错或丢原子，初始 Ag 最大力范数 4.57 eV/Å。

原模型的 Ag 点位间距约 2.00 Å，按简单立方点阵放置；随包 `Ag_u3.eam` 文件头注明它是 Foiles universal-3 FCC 银势，参考 FCC 晶格常数 4.090 Å（对应最近邻约 2.892 Å）。原模型 Ag 与 Ti、Si、C 的最短距离分别只有 1.0003、1.0089、1.0078 Å，这是结构短接触的直接根因。

候选在原 Ag 填充点云外扩 2.2 Å 的包络内重建 FCC Ag，并对 Ag–Ti/Si/C 施加了当前 Morse 参数平衡距离加 0.05 Å 的几何间距下限。最终保留 70,395 个 Ag（原有 212,904 个）；银数量下降是移除不相容的 2 Å 简单立方过密点位和骨架内重叠的结果。候选最低距离如下：

| 最近邻 | 候选最短距离 | 当前 Morse r₀ + 0.05 Å |
|---|---:|---:|
| Ag–Ti | 2.3871 Å | 2.3871 Å |
| Ag–Si | 2.4541 Å | 2.4541 Å |
| Ag–C | 2.2026 Å | 2.2026 Å |
| Ag–Ag | 2.8666 Å | FCC 最近邻约 2.87 Å |

为适配原 150.1×300×300 Å 周期盒，FCC 点阵采用 4.0568×4.0541×4.0541 Å 的正交重复参数，相比 EAM 文件的 4.090 Å 有约 0.8–0.9% 压缩；盒子本身和骨架坐标没有缩放。候选含有限坐标、唯一 atom ID，全部 4 种类型计数与数据文件一致。

## LAMMPS / TTM 证据

- 最终 70,395-Ag 候选执行了 TTM `run 0`：0 步、540,078 atoms；PE = −2,876,377.1 eV、KE = 18,704.443 eV、总能 = −2,857,672.7 eV、TTM 初始电子能 = 1822.0886；Fmax 分量 = 11.806 eV/Å，Ag 最大力范数 = 4.571 eV/Å。对应完整屏幕日志：[ttm_run0.screen](final_candidate_run0/ttm_run0.screen)、[输入](final_candidate_run0/ttm_candidate_run0.in)。这只验证当前最终候选的文件、势、网格能初始化并计算 run 0；没有推进时间。
- 为验证 TTM 时间推进及 restart 回读，另有一个更宽松的 91,973-Ag FCC 几何原型做过恰好 1 步（0.0001 ps），step=1、561,656 atoms，LAMMPS 无错误、lost atoms 或非有限值；完整日志在 [ttm_1step.screen](ttm_dilated_candidate_smoke/ttm_1step.screen)。TTM 网格 13,500 个值均有限，范围 247.641–353.915 K、均值 299.991 K。由该步网格和电子热容网格积分得到的电子能 1822.2392900612522，与 step 1 restart `run 0` 读数完全相同；restart 日志确认 fix `twotemp` 的 global 与 per-atom 状态均重新分配，且 readback 输入没有 `infile`，因此没有把温度网格重置成初始 300 K。readback 输入重新 include 势文件（LAMMPS 提示 hybrid pair style 本身不写入 restart）；电子网格和 per-atom Langevin 状态恢复得到运行时确认，但随机数序列不保证逐位连续，累计 transfer 历史也不从 restart 恢复。证据见 [readback.screen](ttm_dilated_candidate_smoke/readback.screen) 和 [readback 输入](ttm_dilated_candidate_smoke/readback_run0.in)。
- 更早的 32,844-Ag几何原型也做过 1 步 TTM 冒烟测试。两次 1 步测试共推进 2 个 MD 步，分别用于两个原型；最终 70,395-Ag 候选本身只做了 run 0，没有推进 MD 时间。
- 没有热源、没有熔池初态，也没有继续到 step 2、10、100 或 ps 级运行。因此这里不声称形成熔坑或验证了高温行为。

## 势函数限制

最终候选仍使用包内的 `potential.interface_calibration_v0.inc`。文件注释说明 Ag–Ti/Si/C Morse 参数来自单界面 HCP surrogate 的粘附目标拟合，并明确标注“NOT YET A PRODUCTION POTENTIAL”。这次没有用随意调小吸引力来掩盖力，也没有找到可核验的 Ag–Ti₃SiC₂ 生产级交叉势。允许的 GitHub 只读访问可用，但仓库搜索 `Ti3SiC2`、`TSCBOP`、`Ag Ti potential LAMMPS` 等没有返回可用的势仓库；NIST potentials、Crossref 和 OpenAlex 站点请求被当前网络代理以 403 拒绝。因此，几何重叠已修复到符合现有参数间距，但界面热力学/粘附仍未得到独立验证，不能把该候选直接用于正式熔池模拟。

此外，较宽松的 70k-Ag 原型在 300 次最小化后出现 Ag–Ag 约 1.99 Å，故已拒绝该帧；这说明当前校准交叉势仍可能将界面结构拉坏。候选目录保留了这些对照输入和日志，最终文件没有取用该松弛帧。

## 可复现文件

- 最终几何生成脚本：[generate_fcc_ag_interface_clearance_candidate.py](generate_fcc_ag_interface_clearance_candidate.py)
- 几何参数和距离审计：[interface_clearance_geometry_summary.json](interface_clearance_geometry_summary.json)
- 最终结构：[stage65_model_fcc_ag_interface_clearance.data](stage65_model_fcc_ag_interface_clearance.data)
- 最终结构 run 0 日志：[final_candidate_run0/ttm_run0.screen](final_candidate_run0/ttm_run0.screen)
- 一个步 TTM 原型与 restart 证据：[ttm_dilated_candidate_smoke](ttm_dilated_candidate_smoke)

所有候选文件和报告均写在隔离目录，没有覆盖上传模型、原 restart、旧日志或 LAMMPS 源码。
