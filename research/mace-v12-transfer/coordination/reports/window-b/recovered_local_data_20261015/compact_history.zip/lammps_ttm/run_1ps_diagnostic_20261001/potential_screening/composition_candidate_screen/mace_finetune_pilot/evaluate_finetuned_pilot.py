#!/usr/bin/env python3
"""Evaluate saved best MACE fine-tune on untouched PBE validation/test clusters."""
import csv
import json
import os
from pathlib import Path

import numpy as np
import torch
from ase.io import read
from mace.calculators import MACECalculator

ROOT = Path(__file__).resolve().parent
BASE_MODEL = Path("/workspace/.local/cache/mace/mace-mp-0b3-medium.model")
CHECKPOINT = ROOT / "checkpoints_keyfix/Ag_Ti_Si_C_MACE_finetune_pilot_run-42_epoch-51.pt"
SAVED_MODEL = ROOT / "checkpoints_export_epoch51/Ag_Ti_Si_C_MACE_finetune_pilot_run-42.model"
OUT = ROOT / "evaluation_epoch51"
OUT.mkdir(parents=True, exist_ok=True)

torch.set_default_dtype(torch.float64)
base_model = torch.load(BASE_MODEL, map_location="cpu", weights_only=False).double().eval()
fine_model = torch.load(SAVED_MODEL, map_location="cpu", weights_only=False).double().eval()

baseline_calc = MACECalculator(models=[base_model], device="cpu", default_dtype="float64")
fine_calc = MACECalculator(models=[fine_model], device="cpu", default_dtype="float64")

records = []
for split in ("valid", "test"):
    atoms_list = read(ROOT / "data" / f"{split}.extxyz", index=":")
    for atoms in atoms_list:
        name = atoms.info.get("config_type", "unnamed")
        ref_e = float(atoms.get_potential_energy())
        ref_f = np.asarray(atoms.get_forces())
        ids = np.asarray(atoms.arrays["lammps_id"], dtype=int)
        marked = ids[np.asarray(atoms.arrays["central_pair"], dtype=int) == 1]

        predictions = {}
        for label, calc in (("mace", baseline_calc), ("finetuned", fine_calc)):
            trial = atoms.copy()
            trial.calc = calc
            energy = float(trial.get_potential_energy())
            forces = np.asarray(trial.get_forces())
            rmse = float(np.sqrt(np.mean((forces - ref_f) ** 2)))
            force_rms = float(np.sqrt(np.mean(ref_f ** 2)))
            predictions[label] = {"energy_eV": energy, "forces": forces, "force_rmse_eV_A": rmse,
                                  "force_rmse_fraction_of_pbe_rms": rmse / force_rms if force_rms else None,
                                  "energy_error_eV_per_atom": (energy - ref_e) / len(atoms)}

        pair_force_ref = None
        pair_force_values = {}
        if len(marked) == 2:
            i0 = int(np.where(ids == marked[0])[0][0])
            i1 = int(np.where(ids == marked[1])[0][0])
            sym0, sym1 = atoms[i0].symbol, atoms[i1].symbol
            # Orient u from the second atom to the first; positive means separation.
            u = atoms.positions[i0] - atoms.positions[i1]
            u /= np.linalg.norm(u)
            if {sym0, sym1} == {"Ag", "C"}:
                # Orient Ag-C pairs from C toward Ag.
                if sym0 == "C":
                    i0, i1 = i1, i0
                    u = -u
            for label, forces in (("pbe", ref_f), ("mace", predictions["mace"]["forces"]),
                                  ("finetuned", predictions["finetuned"]["forces"])):
                pair_force_values[label] = float(np.dot(forces[i0] - forces[i1], u))

        records.append({
            "split": split,
            "config": name,
            "atoms": len(atoms),
            "marked_pair_ids": [int(x) for x in marked],
            "marked_pair_symbols": [atoms[int(np.where(ids == x)[0][0])].symbol for x in marked],
            "pbe_energy_eV": ref_e,
            "models": {k: {kk: vv for kk, vv in v.items() if kk != "forces"} for k, v in predictions.items()},
            "pair_separating_force_eV_A": pair_force_values,
        })

csv_path = OUT / "heldout_metrics.csv"
with csv_path.open("w", newline="") as f:
    fields = ["split", "config", "atoms", "marked_pair_ids", "marked_pair_symbols", "pbe_energy_eV",
              "mace_force_rmse_eV_A", "finetuned_force_rmse_eV_A", "mace_force_rmse_fraction_of_pbe_rms",
              "finetuned_force_rmse_fraction_of_pbe_rms", "mace_energy_error_eV_per_atom",
              "finetuned_energy_error_eV_per_atom", "pbe_pair_separating_force_eV_A",
              "mace_pair_separating_force_eV_A", "finetuned_pair_separating_force_eV_A"]
    writer = csv.DictWriter(f, fieldnames=fields)
    writer.writeheader()
    for r in records:
        m = r["models"]
        p = r["pair_separating_force_eV_A"]
        writer.writerow({
            "split": r["split"], "config": r["config"], "atoms": r["atoms"],
            "marked_pair_ids": json.dumps(r["marked_pair_ids"]),
            "marked_pair_symbols": json.dumps(r["marked_pair_symbols"]), "pbe_energy_eV": r["pbe_energy_eV"],
            "mace_force_rmse_eV_A": m["mace"]["force_rmse_eV_A"],
            "finetuned_force_rmse_eV_A": m["finetuned"]["force_rmse_eV_A"],
            "mace_force_rmse_fraction_of_pbe_rms": m["mace"]["force_rmse_fraction_of_pbe_rms"],
            "finetuned_force_rmse_fraction_of_pbe_rms": m["finetuned"]["force_rmse_fraction_of_pbe_rms"],
            "mace_energy_error_eV_per_atom": m["mace"]["energy_error_eV_per_atom"],
            "finetuned_energy_error_eV_per_atom": m["finetuned"]["energy_error_eV_per_atom"],
            "pbe_pair_separating_force_eV_A": p.get("pbe"),
            "mace_pair_separating_force_eV_A": p.get("mace"),
            "finetuned_pair_separating_force_eV_A": p.get("finetuned"),
        })

summary = {
    "status": "local_nonperiodic_screening_only",
    "foundation_model": str(BASE_MODEL),
    "checkpoint": str(CHECKPOINT),
    "checkpoint_epoch": 51,
    "validation_and_test": records,
    "model_export": str(SAVED_MODEL),
}
(OUT / "heldout_metrics.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps({"records": len(records), "csv": str(csv_path), "model": str(SAVED_MODEL)}, indent=2))
