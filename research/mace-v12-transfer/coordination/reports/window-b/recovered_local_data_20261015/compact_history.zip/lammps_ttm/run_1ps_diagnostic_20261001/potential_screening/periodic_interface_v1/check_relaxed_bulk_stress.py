#!/usr/bin/env python3
"""Check the stress of the strict-grid, fixed-cell relaxed Ti3SiC2 motif."""
from pathlib import Path
import json
import os

import gpaw_data
import numpy as np
from ase.io import read

ROOT = Path(__file__).resolve().parent
RELAX = ROOT / "bulk_pbe_fire_1x4x2_relax"
OUT = RELAX / "stress_check"
OUT.mkdir(exist_ok=False)
os.environ["GPAW_SETUP_PATH"] = str(gpaw_data.datapath())
from gpaw import GPAW  # noqa: E402

atoms = read(RELAX / "Ti3SiC2_PBE_Fire_1x4x2.extxyz")
atoms.calc = GPAW(str(RELAX / "state.gpw"), txt=str(OUT / "gpaw_stress.log"))
energy = float(atoms.get_potential_energy())
forces = np.asarray(atoms.get_forces())
stress = np.asarray(atoms.get_stress(voigt=False))
summary = {
    "status": "COMPLETED",
    "atoms": len(atoms),
    "cell_A": atoms.cell.array.tolist(),
    "kpts": [1, 4, 2],
    "xc": "PBE",
    "basis": "LCAO-DZP",
    "stress_tensor_eV_A3": stress.tolist(),
    "stress_trace_mean_eV_A3": float(np.trace(stress) / 3),
    "stress_trace_mean_GPa": float(np.trace(stress) / 3 * 160.21766208),
    "energy_eV": energy,
    "max_force_eV_A": float(np.linalg.norm(forces, axis=1).max()),
    "note": "Static stress of the fixed-cell high-grid PBE relaxed geometry; cell was not changed in this calculation.",
}
(OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2), flush=True)
