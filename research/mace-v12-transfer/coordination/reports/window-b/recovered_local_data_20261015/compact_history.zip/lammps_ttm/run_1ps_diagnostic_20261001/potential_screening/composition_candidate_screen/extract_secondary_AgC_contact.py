from pathlib import Path
import json

import numpy as np
from ase import Atoms
from ase.io import write


ROOT = Path(__file__).resolve().parent
CANDIDATE = Path(
    "/workspace/.local/lammps-ttm/composition_locked_candidate_20260930/"
    "stage65_model_fcc_ag_59p8775wt_candidate.data"
)
OUT = ROOT / "interface_contact_scan" / "AgC_secondary"
PAIR_IDS = (688433, 604804)  # nearest distinct Ag-C pair after the minimum contact
BOX = np.array([150.1, 300.0, 300.0])
SYMBOL = {1: "Ti", 2: "Si", 3: "C", 4: "Ag"}

if OUT.exists():
    raise SystemExit(f"Refusing to reuse existing output directory: {OUT}")
OUT.mkdir()
ids, types, xyz = [], [], []
in_atoms = False
for line in CANDIDATE.open():
    s = line.strip()
    if s.startswith("Atoms"):
        in_atoms = True
        continue
    if not in_atoms:
        continue
    f = s.split()
    if len(f) == 5 and f[0].isdigit():
        ids.append(int(f[0])); types.append(int(f[1])); xyz.append(list(map(float, f[2:5])))
    elif ids and s and not s.startswith("#"):
        break
ids = np.asarray(ids, dtype=np.int64)
types = np.asarray(types, dtype=np.int8)
xyz = np.asarray(xyz, dtype=float)
index = {int(a): i for i, a in enumerate(ids)}
ia, ib = (index[a] for a in PAIR_IDS)
if types[ia] != 4 or types[ib] != 3:
    raise SystemExit("Secondary contact IDs are not Ag then C")
delta = xyz[ib] - xyz[ia]
delta -= BOX * np.rint(delta / BOX)
distance = float(np.linalg.norm(delta))
center = (xyz[ia] + 0.5 * delta) % BOX
rel = xyz - center
rel -= BOX * np.rint(rel / BOX)
mask = np.linalg.norm(rel, axis=1) <= 6.0
selected_ids = ids[mask]
selected_types = types[mask]
atoms = Atoms(
    [SYMBOL[int(t)] for t in selected_types],
    positions=rel[mask] + 14.0,
    cell=np.eye(3) * 28.0,
    pbc=False,
)
atoms.new_array("lammps_id", selected_ids)
atoms.new_array("lammps_type", selected_types)
atoms.new_array("central_pair", np.isin(selected_ids, PAIR_IDS).astype(np.int32))
write(OUT / "candidate_Ag_C_R6.extxyz", atoms, format="extxyz")
(OUT / "manifest.json").write_text(json.dumps({
    "candidate_data": str(CANDIDATE), "pair_ids": list(PAIR_IDS),
    "pair_symbols": ["Ag", "C"], "distance_A": distance,
    "atoms": len(atoms), "radius_A": 6.0,
    "caveat": "Nonperiodic radius-6 local fragment extracted with minimum-image coordinates.",
}, indent=2) + "\n")
print(json.dumps({"pair_ids": PAIR_IDS, "distance_A": distance, "atoms": len(atoms)}))
