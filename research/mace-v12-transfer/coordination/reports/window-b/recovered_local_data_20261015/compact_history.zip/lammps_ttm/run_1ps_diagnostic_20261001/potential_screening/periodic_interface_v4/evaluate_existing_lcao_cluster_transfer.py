#!/usr/bin/env python3
"""Reuse existing LCAO/PBE Ag-contact cluster labels to screen MACE v5/v6 transfer."""
from pathlib import Path
import csv, json
import numpy as np
import torch
from ase.io import read
from mace.calculators import MACECalculator

root=Path(__file__).resolve().parent
screen=root.parent/'composition_candidate_screen/interface_contact_scan'
out=root/'lcaocluster_transfer_20261002'
out.mkdir(exist_ok=False)
cases=[]
for contact, candidate in [('AgC','candidate_Ag_C_R6.extxyz'),('AgSi','candidate_Ag_Si_R6.extxyz'),('AgTi','candidate_Ag_Ti_R6.extxyz')]:
    base=screen/'pbe'/contact.replace('Ag','Ag_')
    cases.append((f'{contact}_nearest',screen/candidate,base/'forces.csv',base/'summary.json'))
cases.append(('AgC_secondary_nearest',screen/'AgC_secondary/candidate_Ag_C_R6.extxyz',screen/'AgC_secondary/pbe/forces.csv',screen/'AgC_secondary/pbe/summary.json'))
for env in ('primary','secondary'):
    base=screen/'AgC_environment_distance_scans_PBE_v1'/env
    for d in ('2.0','2.4'):
        p=base/f'd{d}'
        cases.append((f'AgC_{env}_d{d}',p/'input.extxyz',p/'forces.csv',p/'summary.json'))
for env, distances in [('AgSi',('2.2','2.8')),('AgTi',('2.1','2.7'))]:
    base=screen/'AgTi_AgSi_environment_distance_scans_PBE_v1'/env
    for d in distances:
        p=base/f'd{d}'
        cases.append((f'{env}_d{d}',p/'input.extxyz',p/'forces.csv',p/'summary.json'))
models={
 'v5':root/'mace_periodic_v5/models/Ag_Ti_Si_C_MACE_periodic_v5.model',
 'v6':root/'mace_periodic_v6/models/Ag_Ti_Si_C_MACE_periodic_v6.model'}
torch.set_default_dtype(torch.float64)
loaded={}
for name,path in models.items():
    loaded[name]=MACECalculator(models=[torch.load(path,map_location='cpu',weights_only=False).double().eval()],device='cpu',default_dtype='float64')
rows=[]
for name,structure,forcefile,metafile in cases:
    atoms=read(structure); atoms.pbc=False
    symbols=np.asarray(atoms.get_chemical_symbols())
    ids=np.asarray(atoms.arrays['lammps_id'],dtype=int)
    ref_by_id={}
    with forcefile.open() as f:
        for r in csv.DictReader(f):
            ref_by_id[int(r['lammps_id'])]=np.array([float(r[f'f{x}_eV_A']) for x in 'xyz'])
    ref=np.stack([ref_by_id[int(i)] for i in ids])
    cp=np.flatnonzero(np.asarray(atoms.arrays['central_pair'],dtype=bool))
    ag=next(i for i in cp if symbols[i]=='Ag'); partner=next(i for i in cp if symbols[i]!='Ag')
    sep=atoms.positions[ag]-atoms.positions[partner]; dist=float(np.linalg.norm(sep)); unit=sep/dist
    refpair=float(np.dot(ref[ag]-ref[partner],unit))
    meta=json.loads(metafile.read_text())
    row={'case':name,'contact':symbols[partner],'atoms':len(atoms),'distance_A':dist,
         'reference_method':'GPAW PBE/LCAO; existing diagnostic label','PBE_energy_eV_cell':float(meta['PBE_energy_eV']),
         'reference_pair_separating_force_eV_A':refpair,'reference_Fmax_eV_A':float(np.linalg.norm(ref,axis=1).max())}
    for modelname,calc in loaded.items():
        trial=atoms.copy(); trial.calc=calc
        e=float(trial.get_potential_energy()); f=np.asarray(trial.get_forces()); delta=f-ref
        pair=float(np.dot(f[ag]-f[partner],unit))
        row[f'{modelname}_force_RMSE_eV_A']=float(np.sqrt(np.mean(delta**2)))
        row[f'{modelname}_force_MAE_eV_A']=float(np.mean(np.abs(delta)))
        row[f'{modelname}_pair_separating_force_eV_A']=pair
        row[f'{modelname}_pair_force_error_eV_A']=pair-refpair
        row[f'{modelname}_energy_error_meV_atom']=(e-float(meta['PBE_energy_eV']))*1000/len(atoms)
    rows.append(row)
with (out/'per_case.csv').open('x',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary={'cases':len(rows),'case_names':[r['case'] for r in rows],
 'reference_note':'All labels are existing GPAW PBE/LCAO cluster single points. They are a secondary diagnostic because the periodic MACE training labels are PW-PBE.',
 'models':{}}
for m in models:
    weighted_mse=sum(float(r[f'{m}_force_RMSE_eV_A'])**2*3*int(r['atoms']) for r in rows)
    components=sum(3*int(r['atoms']) for r in rows)
    pair_errors=[abs(float(r[f'{m}_pair_force_error_eV_A'])) for r in rows]
    summary['models'][m]={'all_component_force_RMSE_eV_A':float(np.sqrt(weighted_mse/components)),
                          'pair_force_MAE_eV_A':float(np.mean(pair_errors))}
summary['files']={'per_case_csv':str(out/'per_case.csv')}
with (out/'summary.json').open('x') as f: json.dump(summary,f,indent=2);f.write('\n')
print(json.dumps(summary,indent=2))
