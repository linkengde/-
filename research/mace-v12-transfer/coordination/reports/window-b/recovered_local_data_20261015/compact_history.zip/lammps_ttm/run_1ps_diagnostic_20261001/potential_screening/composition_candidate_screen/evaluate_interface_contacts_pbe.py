from pathlib import Path
import csv
import json
import os

import numpy as np
import gpaw_data
from ase.io import read


ROOT = Path(__file__).resolve().parent
SCAN = ROOT / "interface_contact_scan"
OUT = SCAN / "pbe"
SETUP = Path(gpaw_data.datapath())
os.environ["GPAW_SETUP_PATH"] = str(SETUP)

from gpaw import GPAW
from gpaw.mixer import Mixer
from gpaw.occupations import FermiDirac

if OUT.exists():
    raise SystemExit(f"Refusing to reuse existing output directory: {OUT}")
OUT.mkdir()
summary = []

for scaffold in ("Ti", "Si", "C"):
    pair_name = f"Ag-{scaffold}"
    calc_dir = OUT / pair_name.replace("-", "_")
    calc_dir.mkdir()
    atoms = read(SCAN / f"candidate_Ag_{scaffold}_R6.extxyz")
    ids = atoms.arrays["lammps_id"].astype(int)
    pair_mask = atoms.arrays["central_pair"].astype(bool)
    pair_symbols = atoms.get_chemical_symbols()
    ag_id = int(next(atom_id for atom_id, el, selected in zip(ids, pair_symbols, pair_mask) if selected and el == "Ag"))
    scaffold_id = int(next(atom_id for atom_id, el, selected in zip(ids, pair_symbols, pair_mask) if selected and el == scaffold))
    ia = int(np.flatnonzero(ids == ag_id)[0])
    ib = int(np.flatnonzero(ids == scaffold_id)[0])
    vector = atoms.positions[ib] - atoms.positions[ia]
    distance = float(np.linalg.norm(vector))
    unit = vector / distance
    atoms.calc = GPAW(
        mode="lcao",
        basis="dzp",
        xc="PBE",
        occupations=FermiDirac(0.1),
        mixer=Mixer(beta=0.05, nmaxold=8, weight=100.0),
        convergence={"energy": 1e-4, "density": 1e-4, "eigenstates": 1e-4},
        maxiter=120,
        txt=str(calc_dir / "gpaw.log"),
    )
    energy = float(atoms.get_potential_energy())
    forces = atoms.get_forces()
    norms = np.linalg.norm(forces, axis=1)
    separating = float(np.dot(forces[ib] - forces[ia], unit))
    row = {
        "pair": pair_name,
        "atoms": len(atoms),
        "Ag_id": ag_id,
        "scaffold_id": scaffold_id,
        "distance_A": distance,
        "PBE_energy_eV": energy,
        "PBE_pair_separating_force_eV_per_A": separating,
        "Ag_force_norm_eV_per_A": float(norms[ia]),
        "scaffold_force_norm_eV_per_A": float(norms[ib]),
        "max_force_norm_eV_per_A": float(norms.max()),
        "max_force_id": int(ids[int(norms.argmax())]),
    }
    with (calc_dir / "forces.csv").open("x", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["lammps_id", "symbol", "fx_eV_A", "fy_eV_A", "fz_eV_A", "force_norm_eV_A"])
        for atom_id, atom, force, norm in zip(ids, atoms, forces, norms):
            writer.writerow([int(atom_id), atom.symbol, *map(float, force), float(norm)])
    atoms.calc.write(str(calc_dir / "state.gpw"), mode="all")
    (calc_dir / "summary.json").write_text(json.dumps(row, indent=2) + "\n")
    summary.append(row)
    print(json.dumps(row), flush=True)

(OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
