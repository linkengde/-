from pathlib import Path
import csv
import json

import numpy as np
from ase.io import read


ROOT = Path(__file__).resolve().parent
SCREEN = ROOT.parent
OUT = ROOT / "candidate_pair_force_comparison.json"
if OUT.exists():
    raise SystemExit(f"Refusing to overwrite existing file: {OUT}")

atoms = read(ROOT / "composition_candidate_c_pair_R6.extxyz")
ids = atoms.arrays["lammps_id"].astype(int)
ia, ib = (int(np.flatnonzero(ids == atom_id)[0]) for atom_id in (520183, 520177))
vector = atoms.positions[ib] - atoms.positions[ia]
distance = float(np.linalg.norm(vector))
unit = vector / distance

def projected_force(forces):
    return float(np.dot(forces[520177] - forces[520183], unit))

def read_force_csv(path):
    result = {}
    with path.open() as f:
        for row in csv.DictReader(f):
            result[int(row["lammps_id"])] = np.array(
                [float(row[f"f{axis}_eV_A"]) for axis in "xyz"]
            )
    return result

lines = (ROOT / "lammps_v0_pair_forces.dump").read_text().splitlines()
header = next(i for i, line in enumerate(lines) if line.startswith("ITEM: ATOMS"))
lammps = {}
for line in lines[header + 1 :]:
    f = line.split()
    if len(f) == 8:
        lammps[int(f[0])] = np.array([float(x) for x in f[5:8]])

rows = [
    {
        "model": "LAMMPS calibration v0, full periodic candidate",
        "cluster_radius_A": None,
        "C_pair_separating_force_eV_per_A": projected_force(lammps),
    }
]
for model in ("mace", "chgnet"):
    for radius in (6, 7):
        forces = read_force_csv(ROOT / f"{model}_forces_R{radius}.csv")
        rows.append(
            {
                "model": model.upper(),
                "cluster_radius_A": radius,
                "C_pair_separating_force_eV_per_A": projected_force(forces),
            }
        )

result = {
    "central_pair_ids": [520183, 520177],
    "C_pair_distance_A": distance,
    "positive_force_means": "the two C atoms are pushed apart",
    "models": rows,
    "note": "LAMMPS is the full periodic 682587-atom candidate. MACE/CHGNet use nonperiodic local fragments extracted from that candidate.",
}
OUT.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
