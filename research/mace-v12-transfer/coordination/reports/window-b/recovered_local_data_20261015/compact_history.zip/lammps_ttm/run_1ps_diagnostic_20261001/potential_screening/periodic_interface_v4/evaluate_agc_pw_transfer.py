#!/usr/bin/env python3
"""Compare converged GPAW PW-PBE cluster labels to periodic MACE v5/v6."""
from pathlib import Path
import csv
import json
import numpy as np
import torch
from ase.io import read
from mace.calculators import MACECalculator

root = Path(__file__).resolve().parent
run = root / 'pbe_cluster_transfer_pw_20261002_run1'
summary_path = run / 'summary.json'
structure_path = run / 'AgC_cluster_PW_PBE.extxyz'
out_path = run / 'mace_transfer_summary.json'
if not summary_path.exists() or not structure_path.exists():
    raise SystemExit('PW-PBE reference files do not exist yet; no comparison performed.')
dft_meta = json.loads(summary_path.read_text())
if not dft_meta.get('scf_converged', False):
    raise SystemExit('PW-PBE reference is not converged; refusing to compare.')
if out_path.exists():
    raise SystemExit(f'Refusing to overwrite {out_path}')
atoms = read(structure_path)
ref_e = float(atoms.get_potential_energy())
ref_f = np.asarray(atoms.get_forces())
ids = np.asarray(atoms.arrays['lammps_id'], dtype=int)
symbols = np.asarray(atoms.get_chemical_symbols())
central = np.asarray(atoms.arrays['central_pair'], dtype=bool)
pair_ids = np.flatnonzero(central)
if len(pair_ids) != 2:
    raise RuntimeError('Expected two central_pair atoms in the DFT structure')
ag_i = next(i for i in pair_ids if symbols[i] == 'Ag')
other_i = next(i for i in pair_ids if symbols[i] != 'Ag')
sep = atoms.positions[ag_i] - atoms.positions[other_i]
dist = float(np.linalg.norm(sep))
unit = sep / dist
ref_pair = float(np.dot(ref_f[ag_i] - ref_f[other_i], unit))
lcaodir = root.parent/'composition_candidate_screen/interface_contact_scan/AgC_secondary/pbe'
lcaometa = json.loads((lcaodir/'summary.json').read_text())
lcaof_by_id = {}
with (lcaodir/'forces.csv').open() as f:
    for row in csv.DictReader(f):
        lcaof_by_id[int(row['lammps_id'])] = np.array([float(row[f'f{axis}_eV_A']) for axis in 'xyz'])
lcaof = np.stack([lcaof_by_id[int(atom_id)] for atom_id in ids])
lcaopair = float(np.dot(lcaof[ag_i] - lcaof[other_i], unit))
lcaodelta = ref_f-lcaof
torch.set_default_dtype(torch.float64)
models = {
    'v5': root/'mace_periodic_v5/models/Ag_Ti_Si_C_MACE_periodic_v5.model',
    'v6': root/'mace_periodic_v6/models/Ag_Ti_Si_C_MACE_periodic_v6.model',
}
results = {}
for label, path in models.items():
    model = torch.load(path, map_location='cpu', weights_only=False).double().eval()
    trial = atoms.copy()
    trial.calc = MACECalculator(models=[model], device='cpu', default_dtype='float64')
    e = float(trial.get_potential_energy())
    f = np.asarray(trial.get_forces())
    delta = f - ref_f
    pair = float(np.dot(f[ag_i] - f[other_i], unit))
    per_element = {}
    for element in sorted(set(symbols.tolist())):
        mask = symbols == element
        per_element[element] = {
            'force_RMSE_eV_A': float(np.sqrt(np.mean(delta[mask]**2))),
            'force_MAE_eV_A': float(np.mean(np.abs(delta[mask]))),
            'count': int(mask.sum())}
    imax = int(np.linalg.norm(f,axis=1).argmax())
    results[label] = {
        'model_path': str(path), 'energy_eV_cell': e,
        'energy_error_eV_cell': e-ref_e,
        'energy_error_meV_atom': (e-ref_e)*1000/len(atoms),
        'force_RMSE_eV_A': float(np.sqrt(np.mean(delta**2))),
        'force_MAE_eV_A': float(np.mean(np.abs(delta))),
        'force_vector_max_error_eV_A': float(np.linalg.norm(delta,axis=1).max()),
        'predicted_Fmax_eV_A': float(np.linalg.norm(f[imax])),
        'predicted_Fmax_source_id': int(ids[imax]),
        'central_pair_separating_force_eV_A': pair,
        'central_pair_force_error_eV_A': pair-ref_pair,
        'per_element_force_metrics': per_element}
result = {
    'reference': str(structure_path), 'reference_method': dft_meta['method'],
    'reference_scf_converged': True, 'atoms': len(atoms),
    'composition': dft_meta['composition'], 'cell_A': dft_meta['cell_A'],
    'central_pair_source_ids': {'Ag':int(ids[ag_i]), symbols[other_i]:int(ids[other_i])},
    'central_pair_distance_A': dist,
    'reference_energy_eV_cell': ref_e,
    'reference_Fmax_eV_A': float(np.linalg.norm(ref_f,axis=1).max()),
    'reference_Fmax_source_id': int(ids[int(np.linalg.norm(ref_f,axis=1).argmax())]),
    'reference_central_pair_separating_force_eV_A': ref_pair,
    'same_geometry_LCAO_vs_PW_method_boundary_check': {
        'LCAO_boundary': 'nonperiodic 28 A box',
        'PW_boundary': 'periodic 28 A box',
        'LCAO_energy_eV_cell': float(lcaometa['PBE_energy_eV']),
        'PW_minus_LCAO_energy_eV_cell': ref_e-float(lcaometa['PBE_energy_eV']),
        'LCAO_central_pair_separating_force_eV_A': lcaopair,
        'PW_minus_LCAO_central_pair_force_eV_A': ref_pair-lcaopair,
        'force_RMSE_eV_A': float(np.sqrt(np.mean(lcaodelta**2))),
        'force_MAE_eV_A': float(np.mean(np.abs(lcaodelta))),
        'force_vector_max_error_eV_A': float(np.linalg.norm(lcaodelta,axis=1).max())},
    'models': results,
    'interpretation': 'Force errors and relative central-pair force are the primary transfer checks. Absolute energy differences are diagnostic because fitted per-element energy offsets are not uniquely determined by the periodic training compositions.'}
with out_path.open('x') as f:
    json.dump(result,f,indent=2); f.write('\n')
print(json.dumps(result,indent=2))
