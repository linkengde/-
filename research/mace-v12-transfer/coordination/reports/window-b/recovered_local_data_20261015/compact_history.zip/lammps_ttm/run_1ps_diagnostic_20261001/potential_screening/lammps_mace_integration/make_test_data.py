from pathlib import Path

import numpy as np
from ase.io import read, write


ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
atoms = read(ROOT / "c_pair_step0_R6.extxyz")
atoms.cell = np.eye(3) * 28.0
atoms.pbc = True
write(
    OUT / "step0_73atom.data",
    atoms,
    format="lammps-data",
    atom_style="atomic",
    units="metal",
    masses=True,
    specorder=["C", "Ti", "Si", "Ag"],
)
print(f"Wrote {len(atoms)} atoms to {OUT / 'step0_73atom.data'}")
