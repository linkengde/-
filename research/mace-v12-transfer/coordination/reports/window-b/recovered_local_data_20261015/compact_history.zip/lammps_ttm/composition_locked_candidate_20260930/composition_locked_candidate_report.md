# Ag 质量分数锁定候选

日期：2026-09-30  
源模型：`/workspace/.local/lammps-ttm/run-upload-20260930/stage65_model_150x300x300.data`

## 组成核算

候选保留原骨架和 Ag 的原子数。质量分数使用数据文件中的 Ti/Si/C 质量及银的标准原子量 107.8682 u 计算：

| 类型 | 原子数 | 质量 (u) |
|---|---:|---:|
| Ti | 238,383 | 11,410,679.0610 |
| Si | 74,646 | 2,096,470.2330 |
| C | 156,654 | 1,881,524.1978 |
| Ag | 212,904 | 22,965,571.2528 |

因此 Ag = **59.8775218 wt%**，四舍五入到四位小数为 **59.8775 wt%**；Ti/Si/C 合计为 40.1224782 wt%，四舍五入为 40.1225 wt%。

## 结构改动和检查

- 骨架仍为 469,683 个 Ti/Si/C 原子；每个骨架原子的 ID、类型和坐标逐个保持不变，最大坐标差 0 Å。
- Ag 保留 212,904 个，改为 FCC 点阵；删除了原来与骨架短距离冲突的 Ag 坐标，并在原有周期盒可容纳的安全 FCC 位点补足数量。
- 盒子保持 150.1 × 300 × 300 Å，没有缩放骨架或改变盒尺寸。为放入目标 Ag 数量，Ag 填充分布相对原 Ag 点云的最远距离扩展到 15.685 Å。
- FCC 重复数 37 × 73 × 73，对应晶格边长 4.0568 × 4.1096 × 4.1096 Å；相对 Ag EAM 参考 4.09 Å 分别为 −0.813%、+0.479%、+0.479%。
- 最短 Ag–Ti/Si/C 距离为 2.3871/2.4541/2.2026 Å，达到当前 Morse 平衡距离加 0.05 Å 的几何下限；Ag–Ag 最近邻为 2.8873 Å。

## LAMMPS 检查

候选执行 TTM `run 0`，没有推进 MD 时间：step=0、682,587 原子、无 LAMMPS ERROR/WARNING、lost atoms 或 NaN/Inf。PE = −3,288,546 eV，KE = 24,229.979 eV，Etot = −3,264,316 eV；TTM 初始电子能为 1,822.0886。最大力分量为 11.6372 eV/Å，Ag 最大力范数为 4.5515 eV/Å。

这个检查只确认候选结构能初始化当前 LAMMPS/TTM 并计算 `run 0`。交叉 Morse 参数仍标记为 calibration v0，尚未独立验证为生产势；本候选未做能量最小化或时间推进，不据此宣称界面已物理验证。

## 文件

- 候选数据：`stage65_model_fcc_ag_59p8775wt_candidate.data`
- 生成脚本：`generate_composition_locked_fcc_candidate.py`
- 几何和组成摘要：`composition_geometry_summary.json`
- SHA256：`candidate_SHA256.txt`
- 完整 LAMMPS 输入和日志：`ttm_candidate_run0.in`、`run0/ttm_run0.screen`、`run0/ttm_run0.log`
