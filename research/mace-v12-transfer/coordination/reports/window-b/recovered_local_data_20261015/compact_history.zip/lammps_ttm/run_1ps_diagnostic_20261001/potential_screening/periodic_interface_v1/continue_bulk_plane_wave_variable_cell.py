#!/usr/bin/env python3
"""Continue PW-PBE variable-cell relaxation from its saved first segment."""
from pathlib import Path
import json
import os

import gpaw_data
import numpy as np
from ase.filters import FrechetCellFilter
from ase.io import Trajectory, read, write
from ase.optimize import FIRE

ROOT = Path(__file__).resolve().parent
PREV = ROOT / "bulk_pbe_pw_variable_cell_500eV"
SEED = PREV / "Ti3SiC2_PBE_PW_variable_cell.extxyz"
OUT = ROOT / "bulk_pbe_pw_variable_cell_500eV_continue1"
OUT.mkdir(exist_ok=False)
os.environ["GPAW_SETUP_PATH"] = str(gpaw_data.datapath())
from gpaw import GPAW, PW  # noqa: E402
from gpaw.mixer import Mixer  # noqa: E402
from gpaw.occupations import FermiDirac  # noqa: E402

atoms = read(SEED)
atoms.calc = GPAW(
    mode=PW(500),
    xc="PBE",
    kpts=(1, 4, 2),
    occupations=FermiDirac(0.1),
    mixer=Mixer(0.1, 5, 100),
    convergence={"energy": 1e-4, "density": 1e-4, "eigenstates": 1e-4},
    maxiter=120,
    txt=str(OUT / "gpaw_relax.log"),
)
cell_filter = FrechetCellFilter(
    atoms,
    exp_cell_factor=float(len(atoms)),
    mask=[True, True, True, True, True, True],
)
traj = Trajectory(str(OUT / "cellopt.traj"), "w", atoms)
optimizer = FIRE(
    cell_filter,
    logfile=str(OUT / "fire.log"),
    dt=0.03,
    dtmax=0.08,
    maxstep=0.02,
)
optimizer.attach(traj.write, interval=1)
converged = optimizer.run(fmax=0.05, steps=20)
forces = np.asarray(atoms.get_forces())
stress = np.asarray(atoms.get_stress(voigt=False))
energy = float(atoms.get_potential_energy())
filter_forces = np.asarray(cell_filter.get_forces())
log = (OUT / "gpaw_relax.log").read_text(errors="replace").lower()
summary = {
    "optimizer": "FIRE with FrechetCellFilter continuation",
    "seed_segment": str(PREV),
    "optimizer_converged": bool(converged),
    "atoms": len(atoms),
    "cell_A": atoms.cell.array.tolist(),
    "cell_lengths_A": atoms.cell.lengths().tolist(),
    "kpts": [1, 4, 2],
    "xc": "PBE",
    "basis": "plane wave",
    "cutoff_eV": 500,
    "scf_thresholds": "1e-4",
    "scf_converged_records": log.count("converged in"),
    "scf_failed": "failed to converge" in log,
    "target_combined_fmax_eV_A": 0.05,
    "combined_fmax_eV_A": float(np.linalg.norm(filter_forces, axis=1).max()),
    "max_atomic_force_eV_A": float(np.linalg.norm(forces, axis=1).max()),
    "max_atomic_force_atom_index": int(np.linalg.norm(forces, axis=1).argmax() + 1),
    "force_RMS_eV_A": float(np.sqrt(np.mean(forces * forces))),
    "stress_tensor_eV_A3": stress.tolist(),
    "stress_tensor_GPa": (stress * 160.21766208).tolist(),
    "stress_frobenius_norm_eV_A3": float(np.linalg.norm(stress)),
    "max_abs_stress_component_GPa": float(np.max(np.abs(stress)) * 160.21766208),
    "energy_eV": energy,
    "note": "Continuation of variable-cell plane-wave PBE relaxation; all strain components and atomic positions remain free.",
}
write(OUT / "Ti3SiC2_PBE_PW_variable_cell.extxyz", atoms, format="extxyz")
atoms.calc.write(str(OUT / "state.gpw"))
(OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
traj.close()
print(json.dumps(summary, indent=2), flush=True)
