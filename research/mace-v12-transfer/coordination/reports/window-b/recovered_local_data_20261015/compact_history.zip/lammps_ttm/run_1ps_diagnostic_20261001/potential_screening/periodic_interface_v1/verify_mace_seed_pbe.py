#!/usr/bin/env python3
from pathlib import Path
import csv,json,os
import numpy as np
import gpaw_data
from ase.io import read,write
os.environ['GPAW_SETUP_PATH']=str(gpaw_data.datapath())
from gpaw import GPAW
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'mace_seed_strict_pbe';OUT.mkdir(exist_ok=False)
a=read('/workspace/.local/lammps-ttm/run_1ps_diagnostic_20261001/potential_screening/periodic_interface_v2/mace_mp_bulk_relax_seed/Ti3SiC2_mace_pre_relaxed.extxyz')
calc=GPAW(str(ROOT/'bulk_reference/state.gpw'),txt=str(OUT/'gpaw.log'))
a.calc=calc
e=float(a.get_potential_energy());f=np.asarray(a.get_forces());n=np.linalg.norm(f,axis=1)
log=(OUT/'gpaw.log').read_text(errors='replace').lower()
if 'converged' not in log or 'failed to converge' in log: raise RuntimeError('Strict PBE SCF convergence not confirmed')
np.savetxt(OUT/'forces.csv',np.column_stack((np.arange(1,len(a)+1),f)),delimiter=',',header='atom_index,fx_eV_A,fy_eV_A,fz_eV_A',comments='')
write(OUT/'Ti3SiC2_mace_seed_pbe_verified.extxyz',a,format='extxyz');calc.write(OUT/'state.gpw')
r={'status':'strict_periodic_PBE_static_converged','initial_geometry':'MACE-MP-0b3 pre-relaxed; not accepted until PBE force audit','atoms':len(a),'cell_A':a.cell.array.tolist(),'kpts':[1,4,2],'energy_eV':e,'energy_eV_atom':e/len(a),'max_force_eV_A':float(n.max()),'max_force_atom_index':int(n.argmax()+1),'max_force_element':a[int(n.argmax())].symbol,'force_RMS_eV_A':float(np.sqrt(np.mean(f*f))),'criterion':'PBE SCF convergence settings inherited from strict bulk reference (1e-4)'}
(OUT/'summary.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
