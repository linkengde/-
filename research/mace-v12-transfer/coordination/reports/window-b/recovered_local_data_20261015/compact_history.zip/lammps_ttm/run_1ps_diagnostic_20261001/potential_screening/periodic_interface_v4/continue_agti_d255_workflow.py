#!/usr/bin/env python3
"""Run the new Ag-Ti d2.55 PW holdout, score v8/v9, and append evidence."""
from pathlib import Path
import json
import os
import subprocess
import time

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'pbe_external_v9_holdouts/AgTi_d2p55/retry1'
WORK = OUT.parent
STATUS_PATH = WORK / 'workflow_status.json'
REPORT = ROOT / 'periodic_DFT_MACE_progress_20261002.md'
GPAW_PY = Path('/workspace/.local/venvs/gpaw/bin/python')
MACE_PY = Path('/workspace/.local/venvs/mace/bin/python')
RUNNER = ROOT / 'run_agti_d255_periodic_pw_holdout.py'
EVALUATOR = ROOT / 'evaluate_periodic_pw_model_generic.py'
MODELS = [('v8', ROOT / 'mace_periodic_v8_forceonly/models/Ag_Ti_Si_C_MACE_periodic_v8_forceonly.model'),
          ('v9', ROOT / 'mace_periodic_v9_forceonly/models/Ag_Ti_Si_C_MACE_periodic_v9_forceonly.model')]

def save(status):
    tmp = STATUS_PATH.with_suffix('.tmp')
    tmp.write_text(json.dumps(status, indent=2) + '\n')
    os.replace(tmp, STATUS_PATH)

WORK.mkdir(parents=True, exist_ok=True)
status = {'state':'AGTI_D2P55_DFT_RUNNING','started_utc':time.strftime('%Y-%m-%d %H:%M:%S UTC',time.gmtime())}
save(status)
with (WORK / 'runner.stdout').open('w') as stdout:
    proc = subprocess.Popen([str(GPAW_PY), str(RUNNER)], cwd=ROOT, stdout=stdout, stderr=subprocess.STDOUT)
    status['dft_pid'] = proc.pid
    while proc.poll() is None:
        p = OUT / 'progress.json'
        if p.exists():
            try: status['progress'] = json.loads(p.read_text())
            except Exception: pass
        save(status)
        time.sleep(60)
    status['dft_returncode'] = proc.returncode
summary_path = OUT / 'summary.json'
if proc.returncode != 0 or not summary_path.exists():
    status.update({'state':'AGTI_D2P55_DFT_INCONCLUSIVE','reason':'DFT runner failed or no summary.json was written'})
    save(status)
    raise SystemExit(1)
summary = json.loads(summary_path.read_text())
if summary.get('scf_converged') is not True:
    status.update({'state':'AGTI_D2P55_DFT_INCONCLUSIVE','reason':'SCF convergence was not established'})
    save(status)
    raise SystemExit(1)
env = os.environ.copy()
env['MPLCONFIGDIR'] = '/tmp/mpl-agti-d255-eval'
env['XDG_CACHE_HOME'] = '/tmp/mace-agti-d255-eval'
Path(env['MPLCONFIGDIR']).mkdir(parents=True, exist_ok=True)
Path(env['XDG_CACHE_HOME']).mkdir(parents=True, exist_ok=True)
comparisons = {}
for label, model in MODELS:
    cmd = [str(MACE_PY), str(EVALUATOR), '--out', str(OUT), '--model', str(model), '--element-a', 'Ag', '--element-b', 'Ti']
    result = subprocess.run(cmd, cwd=ROOT, env=env, text=True, capture_output=True, timeout=1800)
    status[f'{label}_evaluator_returncode'] = result.returncode
    if result.returncode:
        status.update({'state':'AGTI_D2P55_SCORING_FAILED','reason':result.stderr[-5000:]})
        save(status)
        raise SystemExit(1)
    comparisons[label] = json.loads((OUT / f'{model.stem}_comparison.json').read_text())
status.update({'state':'AGTI_D2P55_DFT_CONVERGED_V8_V9_SCORED','dft_summary':summary,'comparisons':comparisons,
               'completed_utc':time.strftime('%Y-%m-%d %H:%M:%S UTC',time.gmtime())})
save(status)
marker = '## New Ag-Ti 2.55 Å PW-PBE interpolation holdout'
if marker not in REPORT.read_text():
    lines = [f"\n{marker} ({status['completed_utc']})\n",
      '\nThis new 49-atom periodic PW-PBE reference uses an interpolated 2.55 Å central Ag–Ti separation between existing 2.1 and 2.7 Å scan endpoints. It is a new geometry in the same local interface motif, not a novel coordination motif. The two source geometries and their hashes are recorded in summary.json.\n',
      '\n| Model | Component force RMSE (eV/Å) | Maximum force-vector error (eV/Å) | Ag–Ti pair force error (eV/Å) | Energy offset (meV/atom) |\n|---|---:|---:|---:|---:|\n']
    for label in ('v8','v9'):
        c = comparisons[label]
        lines.append(f"| {label} | {c['full_force_component_RMSE_eV_A']:.6f} | {c['full_force_vector_max_abs_error_eV_A']:.6f} | {c['pair_force_error_eV_A']:+.6f} | {c['absolute_energy_error_meV_atom']:+.3f} |\n")
    lines.append('\nThis remains a local force screen; absolute energies are uncalibrated. Passing this one new separation would not validate thermally disordered coordination, production-size transfer, MPI/TTM, or long MD. No MD was run.\n')
    with REPORT.open('a') as f: f.write(''.join(lines))
