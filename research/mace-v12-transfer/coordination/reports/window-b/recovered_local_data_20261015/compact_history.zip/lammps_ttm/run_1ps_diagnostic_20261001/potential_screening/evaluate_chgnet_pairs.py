from pathlib import Path
import csv

import numpy as np
from ase.io import read
from chgnet.model import CHGNet
from chgnet.model.dynamics import CHGNetCalculator

ROOT = Path(__file__).resolve().parent
PAIR_IDS = (520183, 520177)
model = CHGNet.load()
calculator = CHGNetCalculator(model=model, use_device="cpu")
summary = []

for label in ("step0", "step1000"):
    atoms = read(ROOT / f"c_pair_{label}_R6.extxyz")
    atoms.calc = calculator
    energy = atoms.get_potential_energy()
    forces = atoms.get_forces()
    atom_ids = atoms.arrays["lammps_id"]
    ia = int(np.flatnonzero(atom_ids == PAIR_IDS[0])[0])
    ib = int(np.flatnonzero(atom_ids == PAIR_IDS[1])[0])
    vec = atoms.positions[ib] - atoms.positions[ia]
    distance = np.linalg.norm(vec)
    unit = vec / distance
    separating = float(np.dot(forces[ib] - forces[ia], unit))
    fmag = np.linalg.norm(forces, axis=1)
    summary.append(
        {
            "frame": label,
            "atoms": len(atoms),
            "CHGNet_energy_eV": energy,
            "C_pair_distance_A": distance,
            "C_pair_separating_force_eV_per_A": separating,
            "C520183_force_norm_eV_per_A": fmag[ia],
            "C520177_force_norm_eV_per_A": fmag[ib],
            "max_force_norm_eV_per_A": fmag.max(),
            "max_force_lammps_id": int(atom_ids[int(fmag.argmax())]),
        }
    )
    with (ROOT / f"chgnet_forces_{label}.csv").open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["lammps_id", "type", "symbol", "x_A", "y_A", "z_A", "fx_eV_A", "fy_eV_A", "fz_eV_A", "force_norm_eV_A"])
        for i, (aid, typ, pos, force, norm) in enumerate(
            zip(atom_ids, atoms.arrays["lammps_type"], atoms.positions, forces, fmag)
        ):
            w.writerow([int(aid), int(typ), atoms[i].symbol, *map(float, pos), *map(float, force), float(norm)])

with (ROOT / "chgnet_pair_summary.csv").open("w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=summary[0].keys())
    w.writeheader()
    w.writerows(summary)

for row in summary:
    print(row)
