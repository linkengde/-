"""Serial, zero-ghost compatibility shim for MACE 0.3.x and recent LAMMPS."""

import torch

from mace.calculators.lammps_mliap_mace import LAMMPS_MLIAP_MACE


class _SerialDataAdapter:
    def __init__(self, data):
        self.data = data

    def __getattr__(self, name):
        return getattr(self.data, name)

    def forward_exchange(self, source, destination, vector_length):
        if self.data.ntotal != self.data.nlocal:
            raise RuntimeError("The compatibility shim requires a zero-ghost serial box")
        destination.copy_(source)

    def reverse_exchange(self, source, destination, vector_length):
        if self.data.ntotal != self.data.nlocal:
            raise RuntimeError("The compatibility shim requires a zero-ghost serial box")
        destination.copy_(source)


class LAMMPS_MLIAP_MACE_SerialCompat(LAMMPS_MLIAP_MACE):
    def compute_forces(self, data):
        natoms = data.nlocal
        if natoms == 0 or data.npairs <= 1:
            return

        species = torch.as_tensor(data.elems, dtype=torch.int64)
        adapter = _SerialDataAdapter(data)
        if not self.initialized:
            self._initialize_device(data)

        batch = self._prepare_batch(
            adapter, natoms, data.ntotal - natoms, species
        )
        _, atom_energies, pair_forces = self.model(batch)

        local_energies = atom_energies[:natoms].detach().cpu().numpy()
        data.eatoms = local_energies
        data.energy = float(local_energies.sum())
        data.update_pair_forces(pair_forces.detach().cpu().numpy())
