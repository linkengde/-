#!/usr/bin/env python3
"""Fixed-cell GPAW/PBE static scan of the derived Ti-terminated Ag/Ti3SiC2 slab."""
from pathlib import Path
import csv, json, os
import numpy as np
import gpaw_data
from ase.io import read, write
os.environ['GPAW_SETUP_PATH'] = str(gpaw_data.datapath())
from gpaw import GPAW
from gpaw.mixer import Mixer
from gpaw.occupations import FermiDirac
ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'structures'
OUT = ROOT / 'interface_pbe_scan'
OUT.mkdir(exist_ok=False)
rows=[]
# Start near the middle separation, then warm-start neighboring gaps with the
# preceding self-consistent density. Each state remains a distinct output.
for d in (2.3, 2.0, 2.6):
    src=SRC / f'Ti_term_Ag111_d{d:.1f}.extxyz'
    atoms=read(src)
    target=OUT / f'd{d:.1f}'; target.mkdir()
    write(target/'input.extxyz',atoms,format='extxyz')
    if rows:
        calc=GPAW(str(OUT/f"d{rows[-1]['nominal_plane_separation_A']:.1f}"/'state.gpw'),
            maxiter=120,txt=str(target/'gpaw.log'))
    else:
        calc=GPAW(mode='lcao',basis='dzp',xc='PBE',kpts=(1,4,2),
            occupations=FermiDirac(0.1),mixer=Mixer(0.08,5,100),
            convergence={'energy':1e-4,'density':1e-4,'eigenstates':1e-4},
            maxiter=120,txt=str(target/'gpaw.log'))
    atoms.calc=calc
    energy=float(atoms.get_potential_energy()); forces=np.asarray(atoms.get_forces())
    log=(target/'gpaw.log').read_text(errors='replace').lower()
    if 'converged' not in log or 'failed to converge' in log:
        raise RuntimeError(f'PBE convergence not confirmed at d={d:.1f} A')
    np.savetxt(target/'forces.csv',np.column_stack((np.arange(1,len(atoms)+1),forces)),delimiter=',',
        header='atom_index,fx_eV_A,fy_eV_A,fz_eV_A',comments='')
    calc.write(target/'state.gpw')
    syms=np.asarray(atoms.get_chemical_symbols()); norms=np.linalg.norm(forces,axis=1)
    result={'nominal_plane_separation_A':d,'atoms':len(atoms),'elements':{s:int(np.sum(syms==s)) for s in sorted(set(syms))},
      'cell_A':atoms.cell.array.tolist(),'energy_eV':energy,'energy_eV_atom':energy/len(atoms),
      'force_RMS_eV_A':float(np.sqrt(np.mean(forces**2))),'Fmax_eV_A':float(norms.max()),
      'Fmax_atom_index':int(norms.argmax()+1),'max_force_element':str(syms[norms.argmax()]),
      'note':'Derived fixed-cell Ti-terminated interface; not independently validated against a CIF; Ag lateral strain about +4.8/+5.1 percent.'}
    (target/'summary.json').write_text(json.dumps(result,indent=2)+'\n'); rows.append(result)
    print(json.dumps(result),flush=True)
with (OUT/'summary.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
