from pathlib import Path

import numpy as np
from ase.io import read, write


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "composition_candidate_R6.data"
if OUT.exists():
    raise SystemExit(f"Refusing to overwrite existing file: {OUT}")
atoms = read(ROOT / "composition_candidate_c_pair_R6.extxyz")
atoms.cell = np.eye(3) * 28.0
atoms.pbc = False
write(
    OUT,
    atoms,
    format="lammps-data",
    atom_style="atomic",
    units="metal",
    masses=True,
    specorder=["C", "Ti", "Si", "Ag"],
)
print(f"Wrote {len(atoms)} atoms")
