#!/usr/bin/env python3
from pathlib import Path
import csv, hashlib, json, re
import numpy as np
import torch
from ase.io import read
from mace.calculators import MACECalculator

ROOT = Path(__file__).resolve().parent
LOG = ROOT / 'gpaw.log'
XYZ = ROOT / 'AgC_cluster_PW_PBE.extxyz'
SUMMARY = ROOT / 'summary.json'
OUT = ROOT / 'mace_transfer_summary.json'
if OUT.exists():
    raise SystemExit('Refusing to overwrite an existing evaluation.')
log = LOG.read_text()
convergence = re.search(r'Converged in (\d+) steps', log)
scf_lines = re.findall(r'^\|iter:.*$', log, flags=re.M)
if not convergence or not scf_lines:
    raise SystemExit('SCF convergence was not established from the GPAW log.')
last = scf_lines[-1]
# GPAW marks each converged criterion with a trailing c in the iteration row.
if not re.search(r'\|iter:\s*\d+\|.*c\|.*c\|.*c\|\s*$', last):
    raise SystemExit('Last SCF row does not show all three convergence markers.')
a = read(XYZ)
ids = np.asarray(a.arrays['lammps_id'], int)
symbols = np.asarray(a.get_chemical_symbols())
central = np.asarray(a.arrays['central_pair'], bool)
if len(a) != 48 or central.sum() != 2:
    raise SystemExit('Unexpected reference structure; refusing evaluation.')
ci = np.flatnonzero(central)
ag_i = next(i for i in ci if symbols[i] == 'Ag')
other_i = next(i for i in ci if symbols[i] != 'Ag')
sep = a.positions[ag_i] - a.positions[other_i]
dist = float(np.linalg.norm(sep))
unit = sep / dist
ref_e = float(a.get_potential_energy())
ref_f = np.asarray(a.get_forces())
norms = np.linalg.norm(ref_f, axis=1)
cell = np.asarray(a.cell.lengths())
ranges = np.ptp(a.positions, axis=0)
composition = {el: int(np.count_nonzero(symbols == el)) for el in sorted(set(symbols))}
method = {
    'xc':'PBE', 'basis':'plane wave', 'cutoff_eV':500, 'kpts':[1,1,1],
    'smearing_eV':0.1, 'scf_thresholds':'energy/density/eigenstates 1e-5',
    'mixer':'Pulay beta=0.05, nmaxold=8, weight=100',
    'maxiter':160, 'GPAW_version':'26.7.0'}
summary = {
    'source':'../composition_candidate_screen/interface_contact_scan/AgC_secondary/candidate_Ag_C_R6.extxyz',
    'atoms':len(a), 'formula':a.get_chemical_formula(), 'composition':composition,
    'pbc':np.asarray(a.pbc, bool).tolist(), 'cell_A':cell.tolist(),
    'gap_between_periodic_cluster_images_A':float(np.min(cell-ranges)),
    'central_pair_ids':{'Ag':int(ids[ag_i]), symbols[other_i]:int(ids[other_i])},
    'central_Ag_other_distance_A':dist, 'energy_eV_cell':ref_e,
    'scf_converged':True, 'scf_iterations':int(convergence.group(1)),
    'scf_last_iteration_log_row':last.strip(),
    'central_pair_separating_force_eV_A':float(np.dot(ref_f[ag_i]-ref_f[other_i],unit)),
    'fmax_eV_A':float(norms.max()), 'rms_force_eV_A':float(np.sqrt(np.mean(norms**2))),
    'max_force_source_id':int(ids[int(norms.argmax())]), 'method':method,
    'note':'Single point at the same geometry as the existing 48-atom Ag-C LCAO transfer reference. Fully periodic 28 A box, therefore periodic image gap is about 18 A. The LCAO comparison also includes boundary-condition sensitivity.'}
if not SUMMARY.exists():
    SUMMARY.write_text(json.dumps(summary,indent=2)+'\n')
else:
    summary = json.loads(SUMMARY.read_text())
# Read the existing LCAO reference on the identical geometry.
lcaodir = ROOT.parent.parent / 'composition_candidate_screen/interface_contact_scan/AgC_secondary/pbe'
lcaometa = json.loads((lcaodir/'summary.json').read_text())
lcaof_by_id = {}
with (lcaodir/'forces.csv').open() as f:
    for row in csv.DictReader(f):
        lcaof_by_id[int(row['lammps_id'])] = np.array([float(row[f'f{axis}_eV_A']) for axis in 'xyz'])
lcaof = np.stack([lcaof_by_id[int(atom_id)] for atom_id in ids])
lcaopair = float(np.dot(lcaof[ag_i]-lcaof[other_i],unit))
lcaodelta = ref_f-lcaof
torch.set_default_dtype(torch.float64)
models = {
    'v5': ROOT.parent/'mace_periodic_v5/models/Ag_Ti_Si_C_MACE_periodic_v5.model',
    'v6': ROOT.parent/'mace_periodic_v6/models/Ag_Ti_Si_C_MACE_periodic_v6.model'}
results = {}
for label,path in models.items():
    model = torch.load(path,map_location='cpu',weights_only=False).double().eval()
    trial = a.copy()
    trial.calc = MACECalculator(models=[model],device='cpu',default_dtype='float64')
    energy = float(trial.get_potential_energy())
    force = np.asarray(trial.get_forces())
    delta = force-ref_f
    pair = float(np.dot(force[ag_i]-force[other_i],unit))
    imax = int(np.linalg.norm(force,axis=1).argmax())
    per_element = {}
    for el in sorted(set(symbols)):
        mask=symbols==el
        per_element[el]={'force_RMSE_eV_A':float(np.sqrt(np.mean(delta[mask]**2))),
                         'force_MAE_eV_A':float(np.mean(np.abs(delta[mask]))),
                         'count':int(mask.sum())}
    results[label] = {
        'model_path':str(path), 'energy_eV_cell':energy,
        'energy_error_eV_cell':energy-ref_e,
        'energy_error_meV_atom':(energy-ref_e)*1000/len(a),
        'force_RMSE_eV_A':float(np.sqrt(np.mean(delta**2))),
        'force_MAE_eV_A':float(np.mean(np.abs(delta))),
        'force_vector_max_error_eV_A':float(np.linalg.norm(delta,axis=1).max()),
        'predicted_Fmax_eV_A':float(np.linalg.norm(force[imax])),
        'predicted_Fmax_source_id':int(ids[imax]),
        'central_pair_separating_force_eV_A':pair,
        'central_pair_force_error_eV_A':pair-summary['central_pair_separating_force_eV_A'],
        'per_element_force_metrics':per_element}
result = {
    'reference':str(XYZ), 'reference_method':method, 'reference_scf_converged':True,
    'reference_scf_iterations':summary['scf_iterations'], 'atoms':len(a),
    'composition':composition,'cell_A':cell.tolist(),
    'central_pair_source_ids':summary['central_pair_ids'],
    'central_pair_distance_A':dist, 'reference_energy_eV_cell':ref_e,
    'reference_Fmax_eV_A':float(norms.max()),
    'reference_Fmax_source_id':int(ids[int(norms.argmax())]),
    'reference_central_pair_separating_force_eV_A':summary['central_pair_separating_force_eV_A'],
    'same_geometry_LCAO_vs_PW_method_boundary_check':{
       'LCAO_boundary':'nonperiodic 28 A box','PW_boundary':'periodic 28 A box',
       'LCAO_energy_eV_cell':float(lcaometa['PBE_energy_eV']),
       'PW_minus_LCAO_energy_eV_cell':ref_e-float(lcaometa['PBE_energy_eV']),
       'LCAO_central_pair_separating_force_eV_A':lcaopair,
       'PW_minus_LCAO_central_pair_force_eV_A':summary['central_pair_separating_force_eV_A']-lcaopair,
       'force_RMSE_eV_A':float(np.sqrt(np.mean(lcaodelta**2))),
       'force_MAE_eV_A':float(np.mean(np.abs(lcaodelta))),
       'force_vector_max_error_eV_A':float(np.linalg.norm(lcaodelta,axis=1).max())},
    'models':results,
    'interpretation':'The primary transfer metrics are full force error and marked-pair separating-force error. Absolute energies are diagnostic only because the model elemental offsets are not uniquely established by the periodic training compositions.'}
OUT.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
