#!/usr/bin/env python3
"""Compare the periodic MACE candidate with structure-held-out PW-PBE labels."""
from pathlib import Path
import csv
import json

import numpy as np
import torch
from ase.io import read
from ase.neighborlist import neighbor_list
from mace.calculators import MACECalculator

ROOT = Path(__file__).resolve().parent
RUN = ROOT / "mace_periodic_v6"
DATA = RUN / "data"
MODEL = RUN / "models/Ag_Ti_Si_C_MACE_periodic_v6.model"
BASE_MODEL = Path("/workspace/.local/cache/mace/mace-mp-0b3-medium.model")
OUT = RUN / "evaluation"
OUT.mkdir(exist_ok=False)


def interface_separation_force(atoms, forces, contact):
    symbols = np.asarray(atoms.get_chemical_symbols())
    i_idx, j_idx, vectors = neighbor_list("ijD", atoms, cutoff=5.0, self_interaction=False)
    mask = (symbols[i_idx] == "Ag") & (symbols[j_idx] == contact)
    i_idx, j_idx, vectors = i_idx[mask], j_idx[mask], vectors[mask]
    distances = np.linalg.norm(vectors, axis=1)
    if not len(distances):
        return None
    mind = float(distances.min())
    use = np.abs(distances - mind) < 1e-4
    projections = []
    for i, j, vec, dist in zip(i_idx[use], j_idx[use], vectors[use], distances[use]):
        # vec points from Ag to the partner; -vec is the separating direction on Ag.
        unit = -vec / dist
        projections.append(float(np.dot(forces[i] - forces[j], unit)))
    return {"minimum_distance_A": mind, "mean_separating_force_eV_A": float(np.mean(projections)),
            "pair_count": len(projections)}


torch.set_default_dtype(torch.float64)
base = torch.load(BASE_MODEL, map_location="cpu", weights_only=False).double().eval()
fine = torch.load(MODEL, map_location="cpu", weights_only=False).double().eval()
calculators = {
    "mace_mp0b3": MACECalculator(models=[base], device="cpu", default_dtype="float64"),
    "finetuned_v5": MACECalculator(models=[fine], device="cpu", default_dtype="float64"),
}
rows = []
force_diffs = {name: [] for name in calculators}
for split in ("train", "valid", "test"):
    for atoms in read(DATA / f"{split}.extxyz", index=":"):
        name = atoms.info["config_type"]
        reference_energy = float(atoms.info["REF_energy"])
        reference_forces = np.asarray(atoms.arrays["REF_forces"])
        contact = name.split("_", 1)[0]
        ref_pair = interface_separation_force(atoms, reference_forces, contact)
        row = {"split": split, "config_type": name, "atoms": len(atoms),
               "contact": contact, "reference_energy_eV_cell": reference_energy,
               "reference_Fmax_eV_A": float(np.linalg.norm(reference_forces, axis=1).max()),
               "reference_pair": ref_pair}
        for label, calculator in calculators.items():
            trial = atoms.copy()
            trial.calc = calculator
            energy = float(trial.get_potential_energy())
            forces = np.asarray(trial.get_forces())
            diff = forces - reference_forces
            force_diffs[label].append(diff.reshape(-1))
            pred_pair = interface_separation_force(atoms, forces, contact)
            row[f"{label}_energy_error_eV_atom"] = (energy - reference_energy) / len(atoms)
            row[f"{label}_force_RMSE_eV_A"] = float(np.sqrt(np.mean(diff ** 2)))
            row[f"{label}_force_MAE_eV_A"] = float(np.mean(np.abs(diff)))
            row[f"{label}_pair"] = pred_pair
            if pred_pair is not None and ref_pair is not None:
                row[f"{label}_pair_force_error_eV_A"] = (
                    pred_pair["mean_separating_force_eV_A"] - ref_pair["mean_separating_force_eV_A"]
                )
        rows.append(row)

with (OUT / "per_structure_metrics.json").open("w") as f:
    json.dump(rows, f, indent=2)
with (OUT / "per_structure_metrics.csv").open("w", newline="") as f:
    cols = ["split", "config_type", "atoms", "contact", "reference_energy_eV_cell",
            "reference_Fmax_eV_A"]
    for name in calculators:
        cols += [f"{name}_energy_error_eV_atom", f"{name}_force_RMSE_eV_A",
                 f"{name}_force_MAE_eV_A", f"{name}_pair_force_error_eV_A"]
    writer = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
    writer.writeheader()
    for row in rows:
        flat = dict(row)
        for name in calculators:
            pair = row.get(f"{name}_pair")
            flat[f"{name}_pair_force_error_eV_A"] = row.get(f"{name}_pair_force_error_eV_A")
            if pair is not None:
                flat[f"{name}_pair_force_eV_A"] = pair["mean_separating_force_eV_A"]
        writer.writerow(flat)

# A second, separate transfer check uses the already-labeled nonperiodic PBE/LCAO
# holdout clusters. These are not mixed into training because their basis differs.
cluster_path = Path(
    "/workspace/.local/lammps-ttm/run_1ps_diagnostic_20261001/potential_screening/"
    "composition_candidate_screen/mace_finetune_pilot_v3/data/test.extxyz"
)
cluster_rows = []
for atoms in read(cluster_path, index=":"):
    reference_energy = float(atoms.get_potential_energy())
    reference_forces = np.asarray(atoms.get_forces())
    marked = np.flatnonzero(np.asarray(atoms.arrays.get("central_pair", []), dtype=int) == 1)
    contact = None
    ref_pair = None
    if len(marked) == 2:
        symbols = atoms.get_chemical_symbols()
        ag = next((i for i in marked if symbols[i] == "Ag"), None)
        other = next((i for i in marked if symbols[i] != "Ag"), None)
        if ag is not None and other is not None:
            contact = symbols[other]
            unit = atoms.positions[ag] - atoms.positions[other]
            unit /= np.linalg.norm(unit)
            ref_pair = float(np.dot(reference_forces[ag] - reference_forces[other], unit))
    row = {"config_type": atoms.info.get("config_type", "unknown"), "atoms": len(atoms),
           "reference_energy_eV_cell": reference_energy, "contact": contact,
           "reference_Fmax_eV_A": float(np.linalg.norm(reference_forces, axis=1).max()),
           "reference_pair_separating_force_eV_A": ref_pair}
    for label, calculator in calculators.items():
        trial = atoms.copy()
        trial.calc = calculator
        energy = float(trial.get_potential_energy())
        forces = np.asarray(trial.get_forces())
        diff = forces - reference_forces
        row[f"{label}_energy_error_eV_atom"] = (energy - reference_energy) / len(atoms)
        row[f"{label}_force_RMSE_eV_A"] = float(np.sqrt(np.mean(diff ** 2)))
        if contact is not None and ref_pair is not None:
            pair = np.flatnonzero(np.asarray(atoms.arrays["central_pair"], dtype=int) == 1)
            ag = next(i for i in pair if atoms[i].symbol == "Ag")
            other = next(i for i in pair if atoms[i].symbol != "Ag")
            unit = atoms.positions[ag] - atoms.positions[other]
            unit /= np.linalg.norm(unit)
            pred_pair = float(np.dot(forces[ag] - forces[other], unit))
            row[f"{label}_pair_separating_force_eV_A"] = pred_pair
            row[f"{label}_pair_force_error_eV_A"] = pred_pair - ref_pair
    cluster_rows.append(row)
with (OUT / "external_cluster_transfer.json").open("w") as f:
    json.dump({"reference": str(cluster_path), "method_note": "PBE/LCAO cluster labels; basis differs from PW training data, so interpret as force-transfer diagnostic only.",
               "records": cluster_rows}, f, indent=2)
with (OUT / "external_cluster_transfer.csv").open("w", newline="") as f:
    if cluster_rows:
        writer = csv.DictWriter(f, fieldnames=list(dict.fromkeys(key for row in cluster_rows for key in row)))
        writer.writeheader()
        writer.writerows(cluster_rows)

test_rows = [r for r in rows if r["split"] == "test"]
model = "finetuned_v5"
all_test_diffs = np.concatenate(force_diffs[model][sum(1 for r in rows if r["split"] != "test"):])
test_force_rmse = float(np.sqrt(np.mean(all_test_diffs ** 2)))
test_energy_mae = float(np.mean([abs(r[f"{model}_energy_error_eV_atom"]) for r in test_rows]))
pair_errors = [abs(r[f"{model}_pair_force_error_eV_A"]) for r in test_rows
               if r.get(f"{model}_pair_force_error_eV_A") is not None]
pair_mae = float(np.mean(pair_errors)) if pair_errors else float("inf")
reference_pairs = [r["reference_pair"]["mean_separating_force_eV_A"] for r in test_rows
                   if r.get("reference_pair") is not None]
predicted_pairs = [r[f"{model}_pair"]["mean_separating_force_eV_A"] for r in test_rows
                   if r.get(f"{model}_pair") is not None]
sign_cases = [(ref, pred) for ref, pred in zip(reference_pairs, predicted_pairs) if abs(ref) >= 0.2]
sign_accuracy = (sum(np.sign(ref) == np.sign(pred) for ref, pred in sign_cases) / len(sign_cases)
                 if sign_cases else None)
thresholds = {
    "test_force_RMSE_eV_A_max": 0.25,
    "test_pair_separating_force_MAE_eV_A_max": 0.30,
    "test_energy_MAE_eV_atom_max": 0.05,
    "test_pair_force_sign_accuracy_min": 0.90,
}
checks = {
    "force_RMSE": bool(test_force_rmse <= thresholds["test_force_RMSE_eV_A_max"]),
    "pair_force_MAE": bool(pair_mae <= thresholds["test_pair_separating_force_MAE_eV_A_max"]),
    "energy_MAE": bool(test_energy_mae <= thresholds["test_energy_MAE_eV_atom_max"]),
    "pair_force_sign": bool(sign_accuracy is not None and sign_accuracy >= thresholds["test_pair_force_sign_accuracy_min"]),
}
summary = {
    "status": "PASS_SCREENING_THRESHOLDS" if all(checks.values()) else "FAIL_SCREENING_THRESHOLDS",
    "scope": "held-out periodic PW-PBE test of the constructed Si/C-terminated screens",
    "model": str(MODEL),
    "thresholds": thresholds,
    "test_metrics": {
        "force_RMSE_eV_A": test_force_rmse,
        "pair_separating_force_MAE_eV_A": pair_mae,
        "energy_MAE_eV_atom": test_energy_mae,
        "pair_force_sign_accuracy": sign_accuracy,
    },
    "checks": checks,
    "limitations": [
        "passing is only a held-out numerical comparison against this PBE setup",
        "does not establish agreement with experiment or a validated phase/termination",
        "does not validate transfer to production-size geometry or TTM dynamics",
        "external PBE/LCAO cluster transfer results are reported separately because the basis differs from PW training data",
    ],
    "records": rows,
    "external_cluster_transfer": str(OUT / "external_cluster_transfer.json"),
}
(OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps({"status": summary["status"], "test_metrics": summary["test_metrics"],
                   "checks": checks, "summary": str(OUT / 'summary.json')}, indent=2), flush=True)
