#!/usr/bin/env python3
"""Periodic PW-PBE single point at an unseen 2.55 A Ag-Ti scan separation."""
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import time

import numpy as np
from ase.io import read, write

ROOT = Path(__file__).resolve().parent
SCAN = ROOT.parent / "composition_candidate_screen/interface_contact_scan/AgTi_AgSi_environment_distance_scans_PBE_v1/AgTi"
SOURCE_NEAR = SCAN / "d2.1/input.extxyz"
SOURCE_FAR = SCAN / "d2.7/input.extxyz"
OUT = ROOT / "pbe_external_v9_holdouts/AgTi_d2p55/retry1"
OUT.mkdir(parents=True, exist_ok=False)
TARGET_DISTANCE = 2.55

near = read(SOURCE_NEAR)
far = read(SOURCE_FAR)
assert len(near) == len(far) == 49
assert near.get_chemical_symbols() == far.get_chemical_symbols()
assert np.array_equal(near.arrays["lammps_id"], far.arrays["lammps_id"])
assert np.array_equal(near.arrays["central_pair"], far.arrays["central_pair"])
assert np.allclose(near.cell.array, far.cell.array, atol=0, rtol=0)
assert set(near.arrays["lammps_id"]) == set(far.arrays["lammps_id"])
near.pbc = True
far.pbc = True
symbols = np.asarray(near.get_chemical_symbols())
central = np.asarray(near.arrays["central_pair"], dtype=bool)
ag_idx = int(np.flatnonzero(central & (symbols == "Ag"))[0])
ti_idx = int(np.flatnonzero(central & (symbols == "Ti"))[0])
start_vec = near.positions[ti_idx] - near.positions[ag_idx]
end_vec = far.positions[ti_idx] - far.positions[ag_idx]
d0, d1 = float(np.linalg.norm(start_vec)), float(np.linalg.norm(end_vec))
assert abs(d0 - 2.1) < 1e-5 and abs(d1 - 2.7) < 1e-5
fraction = (TARGET_DISTANCE - d0) / (d1 - d0)
atoms = near.copy()
atoms.positions = near.positions + fraction * (far.positions - near.positions)
atoms.pbc = True
vec = atoms.positions[ti_idx] - atoms.positions[ag_idx]
distance = float(np.linalg.norm(vec))
assert abs(distance - TARGET_DISTANCE) < 1e-5
ids = np.asarray(atoms.arrays["lammps_id"], dtype=int)
write(OUT / "input.extxyz", atoms, format="extxyz")

os.environ["GPAW_SETUP_PATH"] = str(__import__("gpaw_data").datapath())
from gpaw import GPAW, PW
from gpaw.mixer import Mixer
from gpaw.occupations import FermiDirac

started = time.time()
calc = GPAW(
    mode=PW(500), xc="PBE", kpts=(1, 1, 1), occupations=FermiDirac(0.1),
    mixer=Mixer(0.05, 8, 100),
    convergence={"energy": 1e-5, "density": 1e-5, "eigenstates": 1e-5},
    maxiter=160, txt=str(OUT / "gpaw.log"),
)
atoms.calc = calc

def checkpoint(ctx):
    niter = int(ctx.niter)
    if niter == 30:
        free = shutil.disk_usage(OUT).free
        if free > 4 * 1024**3:
            calc.write(str(OUT / "checkpoint_iter030.gpw"), mode="all")
    if niter % 5 == 0:
        (OUT / "progress.json").write_text(json.dumps({
            "contact": "AgTi_d2p55", "iteration": niter,
            "elapsed_s": time.time() - started,
        }, indent=2) + "\n")

calc.hooks["scf_step"] = checkpoint
energy = float(atoms.get_potential_energy())
forces = np.asarray(atoms.get_forces())
if forces.shape != (len(atoms), 3) or not np.isfinite(forces).all() or not np.isfinite(energy):
    raise RuntimeError("DFT energy/forces contain non-finite values")
write(OUT / "AgTi_d2p55_cluster_PW_PBE.extxyz", atoms, format="extxyz")
log = (OUT / "gpaw.log").read_text(errors="replace")
match = re.search(r"Converged in\s+(\d+)\s+steps", log)
if not match:
    (OUT / "dft_status.json").write_text(json.dumps({
        "scf_converged": False, "reason": "No explicit GPAW convergence marker",
        "energy_and_forces_written": True,
    }, indent=2) + "\n")
    raise RuntimeError("GPAW did not report convergence; no model scoring will run")
norms = np.linalg.norm(forces, axis=1)
summary = {
    "source_near": str(SOURCE_NEAR),
    "source_near_sha256": hashlib.sha256(SOURCE_NEAR.read_bytes()).hexdigest(),
    "source_far": str(SOURCE_FAR),
    "source_far_sha256": hashlib.sha256(SOURCE_FAR.read_bytes()).hexdigest(),
    "interpolation_fraction": fraction,
    "contact": "AgTi_d2p55", "atoms": len(atoms),
    "formula": atoms.get_chemical_formula(), "pbc": atoms.pbc.tolist(),
    "cell_A": atoms.cell.lengths().tolist(),
    "central_pair_ids": {"Ag": int(ids[ag_idx]), "Ti": int(ids[ti_idx])},
    "central_pair_distance_A": distance, "energy_eV_cell": energy,
    "scf_converged": True, "scf_iterations": int(match.group(1)),
    "central_pair_separating_force_eV_A": float(np.dot(forces[ti_idx] - forces[ag_idx], vec / distance)),
    "fmax_eV_A": float(norms.max()), "rms_force_eV_A": float(np.sqrt(np.mean(norms**2))),
    "max_force_source_id": int(ids[int(norms.argmax())]),
    "method": {"xc": "PBE", "basis": "plane wave", "cutoff_eV": 500,
                "kpts": [1, 1, 1], "smearing_eV": 0.1,
                "scf_thresholds": "energy/density/eigenstates 1e-5",
                "mixer": "Pulay beta=0.05, nmaxold=8, weight=100",
                "maxiter": 160, "GPAW_version": __import__("gpaw").__version__},
    "elapsed_s": time.time() - started,
    "force_label_extxyz": "AgTi_d2p55_cluster_PW_PBE.extxyz",
    "note": "Unseen 2.55 A separation generated by linear interpolation of the existing symmetric 2.1/2.7 A central-pair scan; same interface motif, new geometry. Force-only model comparison; absolute energy remains uncalibrated.",
}
(OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2), flush=True)
