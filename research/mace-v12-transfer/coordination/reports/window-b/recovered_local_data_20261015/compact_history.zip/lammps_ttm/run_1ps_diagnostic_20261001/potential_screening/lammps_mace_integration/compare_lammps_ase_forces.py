import csv
import json
from pathlib import Path

import numpy as np
from ase.io import read


HERE = Path(__file__).resolve().parent
SCREEN = HERE.parent
OUT = HERE / "lammps_ase_force_check.json"
if OUT.exists():
    raise SystemExit(f"Refusing to overwrite existing file: {OUT}")

atoms = read(SCREEN / "c_pair_step0_R6.extxyz")
original_ids = atoms.arrays["lammps_id"].astype(int)
expected_rows = {}
with (SCREEN / "mace_forces_step0.csv").open() as f:
    for row in csv.DictReader(f):
        expected_rows[int(row["lammps_id"])] = np.array(
            [float(row[f"f{axis}_eV_A"]) for axis in "xyz"]
        )

dump_lines = (HERE / "lammps_forces_serial_compat.dump").read_text().splitlines()
atom_header = next(i for i, line in enumerate(dump_lines) if line.startswith("ITEM: ATOMS"))
actual = {}
for line in dump_lines[atom_header + 1 :]:
    fields = line.split()
    if len(fields) != 8:
        continue
    atom_id = int(fields[0])
    actual[atom_id] = np.array([float(v) for v in fields[5:8]])

if len(actual) != len(atoms) or len(expected_rows) != len(atoms):
    raise SystemExit("Unexpected atom count in the force comparison inputs")

delta = []
for index, original_id in enumerate(original_ids, start=1):
    delta.append(actual[index] - expected_rows[int(original_id)])
delta = np.asarray(delta)

summary_row = next(csv.DictReader((SCREEN / "mace_pair_summary.csv").open()))
log = (HERE / "log.mace_serial_compat").read_text().splitlines()
thermo_index = next(i for i, line in enumerate(log) if "PotEng" in line and "c_maxforce" in line)
thermo = log[thermo_index + 1].split()
lammps_energy = float(thermo[2])
lammps_fmax = float(thermo[3])
mace_energy = float(summary_row["MACE_energy_eV"])
mace_fmax = float(summary_row["max_force_norm_eV_per_A"])

result = {
    "atoms": len(atoms),
    "lammps_energy_eV": lammps_energy,
    "ase_mace_energy_eV": mace_energy,
    "energy_abs_error_eV": abs(lammps_energy - mace_energy),
    "lammps_fmax_eV_per_A": lammps_fmax,
    "ase_mace_fmax_eV_per_A": mace_fmax,
    "fmax_abs_error_eV_per_A": abs(lammps_fmax - mace_fmax),
    "force_component_max_abs_error_eV_per_A": float(np.abs(delta).max()),
    "force_component_rmse_eV_per_A": float(np.sqrt(np.mean(delta**2))),
    "force_vector_max_abs_error_eV_per_A": float(np.linalg.norm(delta, axis=1).max()),
    "force_vector_rmse_eV_per_A": float(np.sqrt(np.mean(np.sum(delta**2, axis=1)))),
    "comparison_note": "LAMMPS dump uses its default six-significant-digit formatting.",
}

OUT.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
