# Ag–Ti–Si–C 势函数替代路线初查

日期：2026-10-01  
范围：核对现有势、安装多元素候选软件，并对局部构型做 MACE/CHGNet/DFT 静态筛查；没有改候选模型，也没有推进 MD。

## 当前模型实际使用的势

候选的 `potential.interface_calibration_v0.inc` 定义：

- Ti–Si–C 骨架：`TSCBOP.tersoff`，文件头注明 Plummer 与 Tucker 的 Ti3SiC2 bond-order potential。
- Ag–Ag：`Ag_u3.eam`，文件头注明 Foiles 等人的 universal-3 Ag EAM，引用 *Physical Review B* 33, 7983 (1986)。
- Ag–Ti、Ag–Si、Ag–C：Morse pair 项，标为 calibration v0；注释说明参数由单平面 HCP surrogate 拟合，不是独立验证过的势。

把相同组成候选中的两个 Ag–C 局部簇同时交给 PBE 与当前 LAMMPS 势做静态单点后，v0 分离力分别为 −2.522 和 +0.858 eV/Å；PBE 分别为 −0.864 和 −1.197 eV/Å。两个 Ag–C 距离都约 2.2026 Å，v0 一个过度吸引、另一个方向错误。把全部交叉 Morse 项临时置零只作力分解，不能当成修复方案。详情见[calibration v0 交叉项审计](potential_screening/calibration_v0_cross_terms_audit.md)。

文件中的具体参数为：

| 交叉项 | D0 (eV) | α (Å⁻¹) | r0 (Å) | 截断 (Å) |
|---|---:|---:|---:|---:|
| Ag–Ti | 0.94814194 | 2.0 | 2.33708864 | 8.0 |
| Ag–Si | 0.93944948 | 2.0 | 2.40407837 | 8.0 |
| Ag–C | 1.35077230 | 2.0 | 2.15255924 | 8.0 |

`potential.interface_calibration_v0.inc` 只有“单平面 HCP surrogate 拟合 Ag(111)/Ti3SiC2(0001) DFT 黏附目标”的来源注释；候选目录内没有该 surrogate 的 DFT 输入/输出、拟合残差或独立测试数据。因此这里核实了拟合来源声明和参数，但无法复现原拟合或确认它对别的界面环境有效。

上一轮的力分解显示，在 step 0，那组 C–C 原子间的 Ag–C 项把相对作用从向外翻成向内；这让 Ag–C 交叉项成为当前首要替换/验证对象。它不证明骨架 TSCBOP 或 Ag EAM 本身有问题。

## 是否有可直接换上的现成势

目前仍没有发现已独立验证 Ag/Ti3SiC2 界面的现成四元素势。已取得并安装可覆盖 Ag、Ti、Si、C 的 MACE-MP-0b3-medium checkpoint，并安装 CHGNet、ASE、GPAW/PBE 用于候选筛查。模型涵盖元素只是运行条件，不代表该界面已经验证。

GitHub API、NIST 势库和搜索站点仍有请求被网络代理以 `403 Forbidden` 拒绝，无法完整检索公开二元势数据库。MACE 官方 checkpoint 已通过可用的官方发布下载通道取得并计算；不能据此称已找到经过界面验证的二元交叉势。

## 有希望的路线

| 路线 | 适合做什么 | 主要限制 |
|---|---|---|
| MACE-MP-0b3-medium | composition_locked_candidate 局部 C–C 曲线的总体趋势与 PBE 接近；Ag–Ti、Ag–Si 最近接触点的分离力也较接近 | 两个近等距 Ag–C 接触对 MACE/PBE 分离力分别为 +0.519/−0.864 和 −0.040/−1.197 eV/Å，第一处方向相反、第二处幅值过弱。小型微调把第二处改到 −0.546 eV/Å，但留出力 RMSE 只从 0.549 降到 0.502 eV/Å，C–C 1.5 Å 留出点回退；详见[微调报告](composition_candidate_screen/mace_finetune_pilot/evaluation_epoch51/mace_finetune_pilot_report.md)。仍未计算周期界面结合能。LAMMPS 兼容层仅支持无 ghost 静态单点，不能用于生产模型 |
| 训练一个针对 Ag–Ti–Si–C 的 MACE/ACE/GAP 等多体势 | 最有希望得到在 bulk、表面、界面及局部重排间一致的力场 | 需要一组覆盖 Ag(111)、Ti3SiC2 表面终止/吸附位点、界面间距、缺陷、压缩接触和热构型的 DFT 能量/力；训练和留出验证完成前不能用于物理解读 |
| 保留现有 TSCBOP 与 Ag EAM，只重新拟合 Ag–骨架交叉项 | 保留各相内部已有模型，针对当前失败的交叉作用做小规模校准 | 仍需 DFT/实验基准。简单 Morse 缺少配位和环境依赖，可能无法同时描述不同终止面、Ag 吸附和局部压缩；只调参数或设 Ag–C 为零不能构成验证 |

公开模型的候选资料：

- MACE 项目及模型资料：<https://github.com/ACEsuit/mace>
- MACE-MP-0 论文：Batatia 等，*A foundation model for atomistic materials chemistry*, arXiv:2401.00096，<https://arxiv.org/abs/2401.00096>

这些资料说明可以评估通用多元素模型；它们本身不是 Ag/Ti3SiC2 界面的验证证据。

## 建议的筛选顺序

1. 两个最近 Ag–C 接触的 PBE 单点均已完成，确认同距离附近的力响应随局部环境不同；Ag–Ti/Si 目前只有各一个局部接触点。
2. 5 个训练构型、1 个验证构型、5 个留出构型的 MACE 微调试验已完成。它对个别接触有改善，但整体留出误差仍高，因此没有通过势函数门槛。
3. 下一步是构造小型周期 Ag/Ti₃SiC₂ 界面胞，覆盖不同表面终止、吸附/堆垛和界面距离，计算 PBE 能量与力；以这些数据扩充训练和独立验证集。
4. 周期界面静态验证和势函数留出验证通过后，再解决 LAMMPS/TTM 正式接口并做极短稳定性测试；此前不跑长模拟。

## 结论

目前证据支持：**calibration v0 的 Ag–Ti/Si/C Morse 交叉项只有单平面 surrogate 拟合，缺乏独立验证；力分解与 PBE 对照将 Ag–C 项定位为主要失稳嫌疑。通用 MACE 和 5 构型局部微调都还没达到生产势标准。** 下一步须用周期 Ag/Ti₃SiC₂ 界面 PBE 数据补足配位与终止面变化，再训练并做真正留出验证；目前不能用于长时间 MD。

## 本轮追加结果

- 两个 Ag–C 环境的 2.0/2.4 Å PBE 距离扫描已完成。当前 v0 在 secondary 2.2026 Å 接触点仍预测错方向；完整逐点数据见[Ag–C 环境距离扫描报告](potential_screening/composition_candidate_screen/interface_contact_scan/agc_environment_distance_scan_report.md)。
- 用 primary 接触与扫描点微调的 epoch-51 MACE 能较好复现 primary 的距离曲线，但对整个留出的 secondary 环境仍有约 0.44 eV/Å 全原子力 RMSE。扩展数据的第二轮 MACE 微调正在进行，secondary 环境仍全部留出。
- 本轮没有改候选、Ag 含量或 calibration v0 文件，也没有运行 MD；在周期界面 PBE 与留出验证通过前，两个 MACE 模型都不是生产势。
