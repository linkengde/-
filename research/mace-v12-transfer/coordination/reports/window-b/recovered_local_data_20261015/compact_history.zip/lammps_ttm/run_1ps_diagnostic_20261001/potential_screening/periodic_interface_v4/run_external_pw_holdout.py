#!/usr/bin/env python3
"""Method-matched PW-PBE holdout for one local Ag/interface contact."""
from pathlib import Path
import json
import os
import sys
import time

import numpy as np
from ase.io import read, write

if len(sys.argv) != 2 or sys.argv[1] not in {"AgSi", "AgTi"}:
    raise SystemExit("usage: run_external_pw_holdout.py AgSi|AgTi")

ROOT = Path(__file__).resolve().parent
CONTACT = sys.argv[1]
OUT = ROOT / "pbe_external_v8_motif_holdouts" / CONTACT / "retry1"
OUT.mkdir(parents=True, exist_ok=False)
SOURCE = ROOT.parent / "composition_candidate_screen/interface_contact_scan" / f"candidate_{CONTACT[:2]}_{CONTACT[2:]}_R6.extxyz"
os.environ["GPAW_SETUP_PATH"] = str(__import__("gpaw_data").datapath())
from gpaw import GPAW, PW
from gpaw.mixer import Mixer
from gpaw.occupations import FermiDirac

atoms = read(SOURCE)
atoms.pbc = True
ids = np.asarray(atoms.arrays["lammps_id"], dtype=int)
central = np.asarray(atoms.arrays["central_pair"], dtype=bool)
symbols = np.asarray(atoms.get_chemical_symbols())
ag_idx = int(np.flatnonzero(central & (symbols == "Ag"))[0])
element = CONTACT[2:]
partner_idx = int(np.flatnonzero(central & (symbols == element))[0])
vec = atoms.positions[partner_idx] - atoms.positions[ag_idx]
distance = float(np.linalg.norm(vec))
started = time.time()

calc = GPAW(
    mode=PW(500),
    xc="PBE",
    kpts=(1, 1, 1),
    occupations=FermiDirac(0.1),
    mixer=Mixer(0.05, 8, 100),
    convergence={"energy": 1e-5, "density": 1e-5, "eigenstates": 1e-5},
    maxiter=160,
    txt=str(OUT / "gpaw.log"),
)
atoms.calc = calc

def checkpoint(ctx):
    niter = int(ctx.niter)
    if niter % 60 == 0:
        calc.write(str(OUT / f"checkpoint_iter{niter:03d}.gpw"), mode="all")
        progress = {"contact": CONTACT, "iteration": niter, "elapsed_s": time.time() - started}
        (OUT / "progress.json").write_text(json.dumps(progress, indent=2) + "\n")

calc.hooks["scf_step"] = checkpoint
energy = float(atoms.get_potential_energy())
forces = np.asarray(atoms.get_forces())
norms = np.linalg.norm(forces, axis=1)
pair_force = float(np.dot(forces[partner_idx] - forces[ag_idx], vec / distance))
write(OUT / f"{CONTACT}_cluster_PW_PBE.extxyz", atoms, format="extxyz")
calc.write(str(OUT / "state.gpw"), mode="all")
summary = {
    "source": str(SOURCE),
    "contact": CONTACT,
    "atoms": len(atoms),
    "formula": atoms.get_chemical_formula(),
    "composition": {e: int(np.count_nonzero(symbols == e)) for e in sorted(set(symbols.tolist()))},
    "pbc": atoms.pbc.tolist(),
    "cell_A": atoms.cell.lengths().tolist(),
    "periodic_image_gap_A": float(np.min(atoms.cell.lengths() - (atoms.positions.max(axis=0) - atoms.positions.min(axis=0)))),
    "central_pair_ids": {"Ag": int(ids[ag_idx]), element: int(ids[partner_idx])},
    "central_pair_distance_A": distance,
    "energy_eV_cell": energy,
    "scf_converged": bool(calc.scf.converged),
    "scf_iterations": int(calc.scf.niter),
    "central_pair_separating_force_eV_A": pair_force,
    "fmax_eV_A": float(norms.max()),
    "rms_force_eV_A": float(np.sqrt(np.mean(norms**2))),
    "max_force_source_id": int(ids[int(norms.argmax())]),
    "method": {
        "xc": "PBE", "basis": "plane wave", "cutoff_eV": 500,
        "kpts": [1, 1, 1], "smearing_eV": 0.1,
        "scf_thresholds": "energy/density/eigenstates 1e-5",
        "mixer": "Pulay beta=0.05, nmaxold=8, weight=100",
        "maxiter": 160, "GPAW_version": __import__("gpaw").__version__,
    },
    "elapsed_s": time.time() - started,
    "note": "Independent periodic PW-PBE single point for an interface-local geometry; not relaxed. Checkpoint every 60 SCF iterations. Not a production cell or thermal configuration.",
}
(OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2), flush=True)
