#!/usr/bin/env python3
"""Finalize external Ag-Ti / Ag-Si PW holdouts after their SCF jobs exit."""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
BASE = ROOT / "pbe_external_v8_motif_holdouts"
REPORT = ROOT / "periodic_DFT_MACE_progress_20261002.md"
STATUS = BASE / "watcher_status.json"
EVALUATOR = ROOT / "evaluate_pw_mace_holdout.py"
MACE_PYTHON = Path("/workspace/.local/venvs/mace/bin/python")
TARGETS = {"AgTi": 198531, "AgSi": 198824}


def process_is_target(pid: int, contact: str) -> bool:
    cmdline = Path(f"/proc/{pid}/cmdline")
    try:
        args = cmdline.read_bytes().replace(b"\0", b" ").decode(errors="replace")
    except FileNotFoundError:
        return False
    return "run_external_pw_holdout.py" in args and contact in args


def write_status(status: dict) -> None:
    temp = STATUS.with_suffix(".tmp")
    temp.write_text(json.dumps(status, indent=2) + "\n")
    os.replace(temp, STATUS)


def finish_contact(contact: str, pid: int) -> dict:
    out = BASE / contact / "retry1"
    summary_path = out / "summary.json"
    item: dict = {"contact": contact, "pid": pid, "finished_utc": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime())}
    if not summary_path.exists():
        item.update({"status": "INCONCLUSIVE", "reason": "process exited without summary.json"})
        return item
    summary = json.loads(summary_path.read_text())
    item["summary"] = summary
    if not summary.get("scf_converged", False):
        item.update({"status": "INCONCLUSIVE", "reason": "GPAW did not converge"})
        return item
    if not (out / f"{contact}_cluster_PW_PBE.extxyz").exists():
        item.update({"status": "INCONCLUSIVE", "reason": "converged summary exists but force-labelled extxyz is missing"})
        return item
    if not MACE_PYTHON.exists():
        item.update({"status": "INCONCLUSIVE", "reason": f"MACE interpreter missing: {MACE_PYTHON}"})
        return item
    result = subprocess.run(
        [str(MACE_PYTHON), str(EVALUATOR), contact],
        cwd=ROOT,
        text=True,
        capture_output=True,
        timeout=3600,
        check=False,
    )
    item["evaluator_returncode"] = result.returncode
    item["evaluator_stdout"] = result.stdout[-12000:]
    item["evaluator_stderr"] = result.stderr[-12000:]
    if result.returncode:
        item.update({"status": "EVALUATION_FAILED", "reason": "MACE comparison script returned nonzero"})
        return item
    comparison_path = out / "mace_v8_comparison.json"
    if not comparison_path.exists():
        item.update({"status": "EVALUATION_FAILED", "reason": "comparison JSON was not created"})
        return item
    item["comparison"] = json.loads(comparison_path.read_text())
    item["status"] = "SCF_CONVERGED_AND_SCORED"
    return item


def append_report(results: dict) -> None:
    lines = [
        "\n## Update — external Ag–Ti / Ag–Si PW-PBE holdout completion\n",
        "\nIndependent periodic PW-PBE 500 eV single-point checks on nearest-contact local motifs have exited. These motifs supplement the external Ag–C check; they do not validate thermal disorder or production-cell transfer.\n",
    ]
    for contact in ("AgTi", "AgSi"):
        item = results[contact]
        lines.append(f"\n### {contact}: {item['status']}\n")
        if "summary" in item:
            s = item["summary"]
            lines.append(
                f"\nSCF converged: `{s.get('scf_converged')}`; iterations: `{s.get('scf_iterations')}`; "
                f"marked-pair distance: `{s.get('central_pair_distance_A')}` Å; "
                f"Fmax: `{s.get('fmax_eV_A')}` eV/Å; elapsed: `{s.get('elapsed_s')}` s.\n"
            )
        if "comparison" in item:
            c = item["comparison"]
            lines.append(
                f"\nMACE v8 component force RMSE: `{c['full_force_component_RMSE_eV_A']}` eV/Å; "
                f"maximum force-vector error: `{c['full_force_vector_max_abs_error_eV_A']}` eV/Å; "
                f"marked-pair force error: `{c['pair_force_error_eV_A']}` eV/Å; "
                f"absolute energy error: `{c['absolute_energy_error_meV_atom']}` meV/atom.\n"
            )
        if item.get("reason"):
            lines.append(f"\nReason: {item['reason']}.\n")
        if item.get("evaluator_stderr"):
            lines.append(f"\nEvaluator stderr: `{item['evaluator_stderr'][-2000:]}`\n")
    good = all(results[c]["status"] == "SCF_CONVERGED_AND_SCORED" for c in results)
    lines.append(
        "\nInterpretation: two additional nearest-contact motifs were scored against converged PW-PBE labels. "
        + ("This broadens sampled force evidence but does not by itself clear production MD; thermal and production-cell checks remain." if good else "At least one result is inconclusive; the cross-potential remains unvalidated for that contact and production MD is not cleared.")
        + "\n"
    )
    with REPORT.open("a") as f:
        f.write("".join(lines))


def main() -> None:
    status = {
        "started_utc": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime()),
        "targets": {c: {"pid": p, "state": "RUNNING"} for c, p in TARGETS.items()},
    }
    write_status(status)
    pending = dict(TARGETS)
    results: dict[str, dict] = {}
    while pending:
        for contact, pid in list(pending.items()):
            if process_is_target(pid, contact):
                status["targets"][contact]["state"] = "RUNNING"
                continue
            item = finish_contact(contact, pid)
            results[contact] = item
            status["targets"][contact] = {"pid": pid, "state": item["status"]}
            status["results"] = results
            write_status(status)
            del pending[contact]
        if pending:
            time.sleep(60)
    append_report(results)
    status["completed_utc"] = time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime())
    status["report_appended"] = True
    write_status(status)


if __name__ == "__main__":
    main()
