from pathlib import Path
import csv
import json

import numpy as np
from ase.calculators.singlepoint import SinglePointCalculator
from ase.io import read, write


ROOT = Path(__file__).resolve().parent
ORIGINAL = ROOT.parent
CONTACTS = ROOT / "interface_contact_scan"
OUT = ROOT / "mace_finetune_pilot" / "data"

if OUT.exists():
    raise SystemExit(f"Refusing to reuse existing dataset directory: {OUT}")


def load_force_labels(path):
    with path.open() as f:
        return {
            int(r["lammps_id"]): {
                "symbol": r["symbol"],
                "force": np.array([float(r[f"f{x}_eV_A"]) for x in "xyz"]),
            }
            for r in csv.DictReader(f)
        }


def csv_row(path, key, value):
    with path.open() as f:
        rows = list(csv.DictReader(f))
    return next(r for r in rows if r[key] == value)


def image(source, forces_file, energy, tag):
    atoms = read(source)
    ids = atoms.arrays.get("lammps_id")
    if ids is None:
        raise SystemExit(f"Missing lammps_id array in {source}")
    labels = load_force_labels(forces_file)
    ids = ids.astype(int)
    if set(map(int, ids)) != set(labels):
        raise SystemExit(f"Force labels do not match atom IDs for {tag}")
    forces = np.empty((len(atoms), 3))
    for i, (atom_id, atom) in enumerate(zip(ids, atoms)):
        label = labels[int(atom_id)]
        if atom.symbol != label["symbol"]:
            raise SystemExit(f"Element mismatch for {tag}, atom {atom_id}")
        forces[i] = label["force"]
    atoms.info["config_type"] = tag
    atoms.info["source_config"] = tag
    atoms.calc = SinglePointCalculator(atoms, energy=float(energy), forces=forces)
    return atoms


candidate_init_summary = json.loads((ROOT / "gpaw_R6" / "summary.json").read_text())
candidate_d18_summary = json.loads((ROOT / "pbe_pair_d1p8" / "summary.json").read_text())
candidate_d15_summary = json.loads((ROOT / "pbe_pair_d1p5" / "summary.json").read_text())
contact_summaries = {
    el: json.loads((CONTACTS / "pbe" / f"Ag_{el}" / "summary.json").read_text())
    for el in ("Ti", "Si", "C")
}
secondary_agc = json.loads((CONTACTS / "AgC_secondary" / "pbe" / "summary.json").read_text())

candidate_d18_energy = float(candidate_d18_summary.get("energy_eV", candidate_d18_summary.get("GPAW_energy_eV")))
candidate_d15_energy = float(candidate_d15_summary.get("energy_eV", candidate_d15_summary.get("GPAW_energy_eV")))

raw_force_table = csv.DictReader((ORIGINAL / "model_force_comparison.csv").open())
raw_rows = list(raw_force_table)
raw_energy = {r["frame"]: float(r["GPAW_PBE_R6_energy_eV"]) for r in raw_rows}
raw_scan = {}
with (ORIGINAL / "gpaw_pair_scan" / "pair_scan_pbe_summary.csv").open() as f:
    for row in csv.DictReader(f):
        raw_scan[row["frame"]] = float(row["GPAW_energy_eV"])

train = [
    image(ROOT / "composition_candidate_c_pair_R6.extxyz", ROOT / "gpaw_R6" / "forces.csv", candidate_init_summary["energy_eV"], "candidate_cc_initial"),
    image(ROOT / "candidate_pair_scan_mace" / "pair_d1p8.extxyz", ROOT / "pbe_pair_d1p8" / "forces.csv", candidate_d18_energy, "candidate_cc_d1p8"),
    image(CONTACTS / "candidate_Ag_Ti_R6.extxyz", CONTACTS / "pbe" / "Ag_Ti" / "forces.csv", contact_summaries["Ti"]["PBE_energy_eV"], "candidate_Ag_Ti_contact"),
    image(CONTACTS / "candidate_Ag_Si_R6.extxyz", CONTACTS / "pbe" / "Ag_Si" / "forces.csv", contact_summaries["Si"]["PBE_energy_eV"], "candidate_Ag_Si_contact"),
    image(CONTACTS / "candidate_Ag_C_R6.extxyz", CONTACTS / "pbe" / "Ag_C" / "forces.csv", contact_summaries["C"]["PBE_energy_eV"], "candidate_Ag_C_contact_primary"),
]

valid = [image(
    ROOT / "candidate_pair_scan_mace" / "pair_d1p5.extxyz",
    ROOT / "pbe_pair_d1p5" / "forces.csv",
    candidate_d15_energy,
    "candidate_cc_d1p5_validation",
)]

test = [
    image(ORIGINAL / "c_pair_step0_R6.extxyz", ORIGINAL / "gpaw_step0_R6" / "forces.csv", raw_energy["step0"], "original_ag_layout_step0"),
    image(ORIGINAL / "c_pair_step1000_R6.extxyz", ORIGINAL / "gpaw_step1000_R6_restart" / "forces.csv", raw_energy["step1000"], "original_ag_layout_step1000"),
    image(ORIGINAL / "gpaw_pair_scan" / "pair_d1p8_R6.extxyz", ORIGINAL / "gpaw_pair_scan" / "pair_d1p8" / "forces.csv", raw_scan["pair_d1p8"], "original_ag_layout_cc_d1p8"),
    image(ORIGINAL / "gpaw_pair_scan" / "pair_d1p5_R6.extxyz", ORIGINAL / "gpaw_pair_scan" / "pair_d1p5" / "forces.csv", raw_scan["pair_d1p5"], "original_ag_layout_cc_d1p5"),
    image(CONTACTS / "AgC_secondary" / "candidate_Ag_C_R6.extxyz", CONTACTS / "AgC_secondary" / "pbe" / "forces.csv", secondary_agc["PBE_energy_eV"], "candidate_Ag_C_contact_secondary_heldout"),
]

OUT.mkdir(parents=True)
for name, images in (("train", train), ("valid", valid), ("test", test)):
    write(OUT / f"{name}.extxyz", images, format="extxyz")

manifest = {
    "purpose": "Small diagnostic fine-tuning pilot only; fragments are nonperiodic and do not represent a validated production dataset.",
    "split": {
        "train": [a.info["source_config"] for a in train],
        "valid": [a.info["source_config"] for a in valid],
        "test": [a.info["source_config"] for a in test],
    },
    "candidate_pbe_1p5_summary": candidate_d15_summary,
    "primary_contact_pbe": contact_summaries,
    "secondary_AgC_heldout_pbe": secondary_agc,
}
(OUT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({k: len(v) for k, v in (("train", train), ("valid", valid), ("test", test))}, indent=2))
