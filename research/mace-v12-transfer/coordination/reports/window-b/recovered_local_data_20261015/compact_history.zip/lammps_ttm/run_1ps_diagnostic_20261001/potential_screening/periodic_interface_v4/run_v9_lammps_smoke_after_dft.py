#!/usr/bin/env python3
"""After the AgTi d2.55 DFT workflow, run v9 parity and one serial MD step."""
from pathlib import Path
import csv
import hashlib
import json
import os
import re
import subprocess
import time

import numpy as np
from ase.io import read, write

ROOT = Path(__file__).resolve().parent
HOLDOUT = ROOT / 'pbe_external_v9_holdouts/AgTi_d2p55'
DFT_STATUS = HOLDOUT / 'workflow_status.json'
STRUCTURE = HOLDOUT / 'retry1/input.extxyz'
OUT = HOLDOUT / 'lammps_v9_serial_smoke_retry2'
LMP = Path('/workspace/.local/lammps-ttm/build_mace_v8_ghost_serial/lmp')
MACE_PY = Path('/workspace/.local/venvs/mace/bin/python')
MODEL = ROOT / 'mace_periodic_v9_forceonly/models/Ag_Ti_Si_C_MACE_periodic_v9_forceonly.model'
INTEGRATION = ROOT.parent / 'lammps_mace_integration'
REPORT = ROOT / 'periodic_DFT_MACE_progress_20261002.md'
STATUS = HOLDOUT / 'lammps_smoke_retry2_status.json'
ELEMENTS = ['C', 'Si', 'Ti', 'Ag']
TYPES = {e: i + 1 for i, e in enumerate(ELEMENTS)}
MASSES = {'C':12.011, 'Si':28.0855, 'Ti':47.867, 'Ag':107.8682}


def save_status(data):
    tmp = STATUS.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, indent=2) + '\n')
    os.replace(tmp, STATUS)


def floats_row(tokens):
    try:
        return [float(x) for x in tokens]
    except ValueError:
        return None


def final_thermo_row(path):
    lines = path.read_text(errors='replace').splitlines()
    best = None
    for i, line in enumerate(lines):
        header = line.split()
        if not header or header[0] != 'Step' or 'Atoms' not in header:
            continue
        for row in lines[i+1:]:
            vals = row.split()
            numeric = floats_row(vals)
            if numeric is None or len(numeric) != len(header):
                break
            best = dict(zip(header, numeric))
    if best is None:
        raise RuntimeError(f'No thermo row parsed from {path}')
    return best


def run_lammps(inp, tag, env):
    log = OUT / f'log.{tag}'
    screen = OUT / f'screen.{tag}'
    stdout = OUT / f'stdout.{tag}'
    result = subprocess.run([str(LMP), '-in', str(inp), '-log', str(log), '-screen', str(screen)],
                            cwd=OUT, env=env, text=True, capture_output=True, timeout=900)
    stdout.write_text(result.stdout + '\n--- STDERR ---\n' + result.stderr)
    if result.returncode:
        raise RuntimeError(f'LAMMPS {tag} exited {result.returncode}: {result.stderr[-3000:]}')
    text = (log.read_text(errors='replace') + '\n' + screen.read_text(errors='replace') + '\n' + result.stdout + result.stderr)
    if (re.search(r'(?m)^\s*ERROR\s*:', text, re.I)
            or re.search(r'\blost atoms\b', text, re.I)
            or re.search(r'\b(?:nan|inf)\b', text, re.I)):
        raise RuntimeError(f'LAMMPS {tag} log contains an error/lost atom/non-finite marker')
    return text


status = {'state':'WAITING_FOR_DFT','started_utc':time.strftime('%Y-%m-%d %H:%M:%S UTC',time.gmtime())}
save_status(status)
while True:
    try:
        dft_status = json.loads(DFT_STATUS.read_text())
        dft_state = dft_status.get('state')
    except (FileNotFoundError, json.JSONDecodeError):
        dft_state = None
    if dft_state and dft_state != 'AGTI_D2P55_DFT_RUNNING':
        break
    time.sleep(60)
status.update({'state':'PREPARING_V9_LAMMPS_RUN0','dft_workflow_state':dft_state})
save_status(status)
if not STRUCTURE.exists():
    status.update({'state':'LAMMPS_SMOKE_INCONCLUSIVE','reason':'DFT geometry input is missing'})
    save_status(status)
    raise SystemExit(1)
if OUT.exists():
    status.update({'state':'LAMMPS_SMOKE_INCONCLUSIVE','reason':'Refusing to overwrite existing smoke-test directory'})
    save_status(status)
    raise SystemExit(1)
OUT.mkdir(parents=True)
atoms = read(STRUCTURE)
atoms.pbc = True
if len(atoms) != 49 or not np.isfinite(atoms.positions).all():
    raise RuntimeError('Unexpected/non-finite smoke-test geometry')
atoms.positions[:, 0] = np.mod(atoms.positions[:, 0] + 14.0, atoms.cell.lengths()[0])
write(OUT / 'cluster_periodic.extxyz', atoms, format='extxyz')

# Write a deterministic LAMMPS atomic data file and retain its source-ID mapping.
data_path = OUT / 'AgTi_d2p55.data'
with data_path.open('x') as f:
    f.write('49 atom Ag-Ti periodic interface for v9 serial smoke check\n\n49 atoms\n4 atom types\n\n')
    for axis, hi in zip('xyz', atoms.cell.lengths()):
        f.write(f'0.0 {hi:.10f} {axis}lo {axis}hi\n')
    f.write('\nMasses\n\n')
    for elem in ELEMENTS:
        f.write(f'{TYPES[elem]} {MASSES[elem]:.8f} # {elem}\n')
    f.write('\nAtoms # atomic\n\n')
    for i, (atom, pos) in enumerate(zip(atoms, atoms.positions), 1):
        f.write(f'{i} {TYPES[atom.symbol]} {pos[0]:.10f} {pos[1]:.10f} {pos[2]:.10f}\n')
with (OUT / 'atom_id_map.csv').open('x', newline='') as f:
    w = csv.writer(f); w.writerow(['lammps_id','source_lammps_id','element'])
    for i, atom in enumerate(atoms, 1):
        w.writerow([i, int(atoms.arrays['lammps_id'][i-1]), atom.symbol])

wrapper = OUT / 'mace_v9_periodic_serial_compat.pt'
exporter = OUT / 'export_v9_wrapper.py'
exporter.write_text(f'''import sys, torch\nsys.path.insert(0, {str(INTEGRATION)!r})\nfrom mliap_periodic_serial_compat import LAMMPS_MLIAP_MACE_PeriodicSerial\nmodel = torch.load({str(MODEL)!r}, map_location="cpu", weights_only=False).double().cpu()\nmodel.lammps_mliap = True\nwrapper = LAMMPS_MLIAP_MACE_PeriodicSerial(model, head="Default")\ntorch.save(wrapper, {str(wrapper)!r})\nprint("wrapper saved", {str(wrapper)!r}, "cutoff_A", float(model.r_max))\n''')
base_env = os.environ.copy()
base_env['PYTHONPATH'] = ':'.join([str(Path('/workspace/.local/src/lammps-mace-source/python')),
    '/workspace/.local/venvs/mace/lib/python3.12/site-packages', str(INTEGRATION), base_env.get('PYTHONPATH','')]).rstrip(':')
base_env['LD_LIBRARY_PATH'] = ':'.join(['/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib',
    '/workspace/.local/venvs/mace/lib', '/workspace/.local/venvs/mace/lib/python3.12/site-packages/torch/lib',
    base_env.get('LD_LIBRARY_PATH','')]).rstrip(':')
base_env['MPLCONFIGDIR'] = '/tmp/mpl-v9-lammps-smoke'
base_env['XDG_CACHE_HOME'] = '/tmp/cache-v9-lammps-smoke'
base_env['XDG_CONFIG_HOME'] = '/tmp/config-v9-lammps-smoke'
for key in ('MPLCONFIGDIR','XDG_CACHE_HOME','XDG_CONFIG_HOME'):
    Path(base_env[key]).mkdir(parents=True, exist_ok=True)
export = subprocess.run([str(MACE_PY), str(exporter)], cwd=OUT, env=base_env, text=True, capture_output=True, timeout=600)
(OUT/'export_wrapper.stdout').write_text(export.stdout+'\n--- STDERR ---\n'+export.stderr)
if export.returncode or not wrapper.exists():
    raise RuntimeError('Could not export v9 LAMMPS wrapper: '+export.stderr[-3000:])

common = f'''units metal\natom_style atomic\nboundary p p p\nread_data {data_path}\nneighbor 2.0 bin\nneigh_modify every 1 delay 0 check yes\npair_style mliap unified {wrapper} 0\npair_coeff * * C Si Ti Ag\ncompute atomforce all property/atom fx fy fz\nvariable force_mag atom sqrt(c_atomforce[1]^2+c_atomforce[2]^2+c_atomforce[3]^2)\ncompute maxforce all reduce max v_force_mag\nthermo 1\n'''
run0 = OUT / 'in.run0'
run0.write_text(common + f'''thermo_style custom step atoms pe c_maxforce\nthermo_modify norm no lost error\ndump force all custom 1 {OUT/'forces.run0.dump'} id type x y z fx fy fz\ndump_modify force sort id\nrun 0\n''')
run1 = OUT / 'in.run1'
run1.write_text(common + f'''thermo_style custom step atoms temp pe ke etotal c_maxforce\nthermo_modify norm no lost error\ntimestep 0.0001\nvelocity all set 0.0 0.0 0.0\nfix integrate all nve\ndump traj all custom 1 {OUT/'traj.run1.dump'} id type x y z vx vy vz fx fy fz\ndump_modify traj sort id\nrun 1\n''')

status.update({'state':'RUNNING_V9_LAMMPS_RUN0','wrapper':str(wrapper),'lammps_executable':str(LMP),
               'periodic_equivalent_x_translation_A':14.0})
save_status(status)
try:
    run0_text = run_lammps(run0, 'run0', base_env)
except Exception as exc:
    status.update({'state':'LAMMPS_RUN0_FAILED','reason':str(exc)})
    save_status(status)
    raise
if not (OUT/'forces.run0.dump').exists():
    raise RuntimeError('LAMMPS run 0 produced no force dump')

compare = ROOT / 'compare_v9_lammps_run0_ase.py'
compare_result = subprocess.run([str(MACE_PY), str(compare)], cwd=OUT, env=base_env, text=True, capture_output=True, timeout=600)
(OUT/'compare_run0.stdout').write_text(compare_result.stdout+'\n--- STDERR ---\n'+compare_result.stderr)
if compare_result.returncode:
    status.update({'state':'LAMMPS_RUN0_PARITY_ERROR','reason':compare_result.stderr[-3000:]})
    save_status(status)
    raise RuntimeError('ASE/LAMMPS run0 parity comparison failed: '+compare_result.stderr[-3000:])
parity = json.loads((OUT/'run0_parity.json').read_text())
status['run0_parity'] = parity
if (parity['atoms'] != 49 or parity['energy_abs_error_eV'] > 1e-4
        or parity['force_component_max_abs_error_eV_A'] > 1e-4
        or not parity['lammps_ghost_map_marker']):
    status.update({'state':'LAMMPS_RUN0_PARITY_FAIL','reason':'Run 0 parity failed or the translated periodic geometry did not exercise ghost mapping'})
    save_status(status)
    raise RuntimeError('v9 LAMMPS run0 parity exceeded threshold; stopped before MD step')
status.update({'state':'RUNNING_V9_LAMMPS_ONE_STEP'})
save_status(status)
try:
    run1_text = run_lammps(run1, 'run1', base_env)
except Exception as exc:
    status.update({'state':'LAMMPS_ONE_STEP_FAILED','reason':str(exc)})
    save_status(status)
    raise
row = final_thermo_row(OUT/'log.run1')
if int(row['Step']) != 1 or int(row['Atoms']) != 49:
    raise RuntimeError(f'Unexpected final thermo row: {row}')
if not (OUT/'traj.run1.dump').exists():
    raise RuntimeError('No trajectory output from one-step run')
status.update({'state':'V9_SERIAL_ONE_STEP_PASS','run1_final_thermo':row,
    'run1_mace_ghost_map_message':bool(re.search(r'MACE_PERIODIC_SERIAL_GHOST_MAP[^\n]*nghost=[1-9]',run1_text)),
    'note':'One unheated serial NVE step only. This verifies the serial LAMMPS/MACE execution path, not MPI, physical TTM, or production-cell performance.',
    'completed_utc':time.strftime('%Y-%m-%d %H:%M:%S UTC',time.gmtime())})
for name in ('mace_v9_periodic_serial_compat.pt','AgTi_d2p55.data','in.run0','in.run1'):
    path=OUT/name
    status.setdefault('sha256',{})[name]=hashlib.sha256(path.read_bytes()).hexdigest()
save_status(status)
marker='## MACE v9 one-step LAMMPS serial smoke check'
if marker not in REPORT.read_text():
    p=parity
    with REPORT.open('a') as f:
        f.write(f"\n{marker} ({status['completed_utc']})\n\nThe periodic 49-atom Ag–Ti 2.55 Å geometry was checked with the v9 model in the custom single-rank LAMMPS MLIAP adapter. Run 0 parity: energy error {p['energy_abs_error_eV']:.3e} eV; force-component max error {p['force_component_max_abs_error_eV_A']:.3e} eV/Å; force RMSE {p['force_component_RMSE_eV_A']:.3e} eV/Å. A subsequent unheated NVE `run 1` ended at step 1 with 49 atoms. This checks only serial one-step plumbing; MPI, physical TTM coupling/restart, and production scale remain untested. No long MD was run.\n")
print(json.dumps(status,indent=2))
