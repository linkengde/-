#!/usr/bin/env python3
"""Score a MACE model on a converged periodic PW-PBE local-interface frame."""
from pathlib import Path
import argparse
import json

import numpy as np
import torch
from ase.io import read
from mace.calculators import MACECalculator

p = argparse.ArgumentParser()
p.add_argument('--out', type=Path, required=True)
p.add_argument('--model', type=Path, required=True)
p.add_argument('--element-a', required=True)
p.add_argument('--element-b', required=True)
a = p.parse_args()
summary = json.loads((a.out / 'summary.json').read_text())
if summary.get('scf_converged') is not True:
    raise SystemExit('Refusing to score a non-converged DFT structure')
label_path = a.out / summary.get('force_label_extxyz', 'AgTi_d2p55_cluster_PW_PBE.extxyz')
label = read(label_path)
label.pbc = np.asarray(summary['pbc'], dtype=bool)
ref_energy = float(label.get_potential_energy())
ref_forces = np.asarray(label.get_forces())
ids = np.asarray(label.arrays['lammps_id'], dtype=int)
symbols = np.asarray(label.get_chemical_symbols())
central = np.asarray(label.arrays['central_pair'], dtype=bool)
ia = int(np.flatnonzero(central & (symbols == a.element_a))[0])
ib = int(np.flatnonzero(central & (symbols == a.element_b))[0])
vec = label.positions[ib] - label.positions[ia]
distance = float(np.linalg.norm(vec))
unit = vec / distance
ref_pair = float(np.dot(ref_forces[ib] - ref_forces[ia], unit))
torch.set_default_dtype(torch.float64)
model = torch.load(a.model, map_location='cpu', weights_only=False).double().eval()
label.calc = MACECalculator(models=[model], device='cpu', default_dtype='float64')
model_energy = float(label.get_potential_energy())
model_forces = np.asarray(label.get_forces())
delta = model_forces - ref_forces
vector_errors = np.linalg.norm(delta, axis=1)
model_pair = float(np.dot(model_forces[ib] - model_forces[ia], unit))
result = {
    'contact': summary['contact'], 'scf_converged': True,
    'scf_iterations': int(summary['scf_iterations']),
    'reference_method': 'periodic PBE plane-wave, 500 eV, Gamma, 0.1 eV Fermi smearing',
    'atoms': len(label), 'formula': label.get_chemical_formula(),
    'central_pair_ids': {a.element_a: int(ids[ia]), a.element_b: int(ids[ib])},
    'central_pair_distance_A': distance,
    'full_force_component_RMSE_eV_A': float(np.sqrt(np.mean(delta**2))),
    'full_force_vector_max_abs_error_eV_A': float(vector_errors.max()),
    'reference_pair_separating_force_eV_A': ref_pair,
    'model_pair_separating_force_eV_A': model_pair,
    'pair_force_error_eV_A': model_pair - ref_pair,
    'absolute_energy_error_meV_atom': (model_energy - ref_energy) * 1000.0 / len(label),
    'model': str(a.model),
    'note': summary.get('note', ''),
}
target = a.out / f"{a.model.stem}_comparison.json"
target.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
