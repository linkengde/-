#!/usr/bin/env python3
"""Evaluate the v2 model on its validation and fully held-out test splits."""
from pathlib import Path
import csv
import json

import numpy as np
import torch
from ase.io import read
from mace.calculators import MACECalculator

ROOT = Path(__file__).resolve().parent
BASE_MODEL = Path("/workspace/.local/cache/mace/mace-mp-0b3-medium.model")
MODEL = ROOT / "models_v2/Ag_Ti_Si_C_MACE_finetune_pilot_v2.model"
OUT = ROOT / "evaluation_v2"
OUT.mkdir(exist_ok=False)

torch.set_default_dtype(torch.float64)
base_model = torch.load(BASE_MODEL, map_location="cpu", weights_only=False).double().eval()
fine_model = torch.load(MODEL, map_location="cpu", weights_only=False).double().eval()
calculators = {
    "mace_mp0b3": MACECalculator(models=[base_model], device="cpu", default_dtype="float64"),
    "finetuned_v2": MACECalculator(models=[fine_model], device="cpu", default_dtype="float64"),
}
records = []
for split in ("valid", "test"):
    for atoms in read(ROOT / "data" / f"{split}.extxyz", index=":"):
        name = atoms.info.get("config_type", "unnamed")
        ref_e = float(atoms.get_potential_energy())
        ref_f = np.asarray(atoms.get_forces())
        ids = np.asarray(atoms.arrays["lammps_id"], dtype=int)
        marked = ids[np.asarray(atoms.arrays["central_pair"], dtype=int) == 1]
        row = {"split": split, "config": name, "atoms": len(atoms),
               "marked_pair_ids": marked.tolist(), "pbe_energy_eV": ref_e,
               "pbe_force_RMS_eV_A": float(np.sqrt(np.mean(ref_f ** 2)))}
        for label, calc in calculators.items():
            trial = atoms.copy()
            trial.calc = calc
            pred_e = float(trial.get_potential_energy())
            pred_f = np.asarray(trial.get_forces())
            row[f"{label}_force_RMSE_eV_A"] = float(np.sqrt(np.mean((pred_f - ref_f) ** 2)))
            row[f"{label}_relative_force_RMSE"] = row[f"{label}_force_RMSE_eV_A"] / row["pbe_force_RMS_eV_A"]
            row[f"{label}_energy_error_eV_atom"] = (pred_e - ref_e) / len(atoms)
            if len(marked) == 2:
                i0, i1 = [int(np.flatnonzero(ids == aid)[0]) for aid in marked]
                sym0, sym1 = atoms[i0].symbol, atoms[i1].symbol
                u = atoms.positions[i0] - atoms.positions[i1]
                u /= np.linalg.norm(u)
                if {sym0, sym1} == {"Ag", "C"} and sym0 == "C":
                    i0, i1 = i1, i0
                    u = -u
                row[f"{label}_pair_separating_force_eV_A"] = float(np.dot(pred_f[i0] - pred_f[i1], u))
        if len(marked) == 2:
            i0, i1 = [int(np.flatnonzero(ids == aid)[0]) for aid in marked]
            sym0, sym1 = atoms[i0].symbol, atoms[i1].symbol
            u = atoms.positions[i0] - atoms.positions[i1]
            u /= np.linalg.norm(u)
            if {sym0, sym1} == {"Ag", "C"} and sym0 == "C":
                i0, i1 = i1, i0
                u = -u
            row["pbe_pair_separating_force_eV_A"] = float(np.dot(ref_f[i0] - ref_f[i1], u))
        records.append(row)

with (OUT / "heldout_metrics.csv").open("w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=records[0].keys())
    writer.writeheader()
    writer.writerows(records)
summary = {
    "status": "local_nonperiodic_screening_only",
    "model": str(MODEL),
    "splits": json.loads((ROOT / "data/manifest.json").read_text()),
    "records": records,
}
(OUT / "heldout_metrics.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps({"records": len(records), "csv": str(OUT / "heldout_metrics.csv")}, indent=2))
