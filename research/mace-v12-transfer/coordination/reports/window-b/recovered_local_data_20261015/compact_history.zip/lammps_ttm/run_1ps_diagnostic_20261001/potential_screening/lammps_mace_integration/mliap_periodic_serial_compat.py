"""Single-rank periodic MACE/ML-IAP adapter with tag-based ghost exchange.

Requires the isolated LAMMPS build whose MLIAPDataPy exposes ``atom_tags``.
This adapter intentionally rejects any ghost tag not owned on the same rank;
it does not implement MPI communication.
"""

import numpy as np
import torch

from mace.calculators.lammps_mliap_mace import LAMMPS_MLIAP_MACE


class _PeriodicSerialDataAdapter:
    def __init__(self, data):
        self.data = data
        self.nlocal = int(data.nlocal)
        self.ntotal = int(data.ntotal)
        tags = np.asarray(data.atom_tags, dtype=np.int64)
        if tags.shape != (self.ntotal,):
            raise RuntimeError("LAMMPS atom_tags length does not match ntotal")
        owned = {}
        for i, tag in enumerate(tags[: self.nlocal]):
            tag = int(tag)
            if tag in owned:
                raise RuntimeError(f"Duplicate owned LAMMPS atom tag {tag}")
            owned[tag] = i
        try:
            local_source = [owned[int(tag)] for tag in tags]
        except KeyError as exc:
            raise RuntimeError(
                "This serial adapter cannot exchange a ghost whose owner is on another rank"
            ) from exc
        self.local_source = torch.as_tensor(local_source, dtype=torch.long)
        self.ghost_count = self.ntotal - self.nlocal
        self.local_map = local_source

    def __getattr__(self, name):
        return getattr(self.data, name)

    def forward_exchange(self, source, destination, vector_length):
        if source.shape[0] != self.ntotal or source.shape[-1] != vector_length:
            raise RuntimeError("Unexpected MACE forward-exchange tensor shape")
        destination.copy_(source.index_select(0, self.local_source.to(source.device)))

    def reverse_exchange(self, source, destination, vector_length):
        if source.shape[0] != self.ntotal or source.shape[-1] != vector_length:
            raise RuntimeError("Unexpected MACE reverse-exchange tensor shape")
        destination.zero_()
        destination[: self.nlocal].index_add_(
            0, self.local_source.to(source.device), source
        )


class LAMMPS_MLIAP_MACE_PeriodicSerial(LAMMPS_MLIAP_MACE):
    """MACE wrapper supporting serial periodic ghost copies via atom tags."""

    def compute_forces(self, data):
        natoms = int(data.nlocal)
        if natoms == 0 or data.npairs <= 1:
            return
        species = torch.as_tensor(data.elems, dtype=torch.int64)
        adapter = _PeriodicSerialDataAdapter(data)
        if not getattr(self, "_ghost_map_reported", False):
            print(
                "MACE_PERIODIC_SERIAL_GHOST_MAP "
                f"nlocal={adapter.nlocal} ntotal={adapter.ntotal} "
                f"nghost={adapter.ghost_count} "
                f"ghosts_mapped_to_local={sum(i < adapter.nlocal for i in adapter.local_map[adapter.nlocal:])}",
                flush=True,
            )
            self._ghost_map_reported = True
        if not self.initialized:
            self._initialize_device(data)
        batch = self._prepare_batch(adapter, natoms, data.ntotal - natoms, species)
        _, atom_energies, pair_forces = self.model(batch)
        local_energies = atom_energies[:natoms].detach().cpu().numpy()
        data.eatoms = local_energies
        data.energy = float(local_energies.sum())
        data.update_pair_forces(pair_forces.detach().cpu().numpy())
