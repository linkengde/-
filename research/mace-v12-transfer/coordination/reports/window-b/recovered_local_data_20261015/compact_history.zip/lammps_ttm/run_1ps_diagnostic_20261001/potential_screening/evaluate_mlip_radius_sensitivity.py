from pathlib import Path
import csv

import numpy as np
from ase.io import read
from chgnet.model import CHGNet
from chgnet.model.dynamics import CHGNetCalculator
from mace.calculators import mace_mp

ROOT = Path(__file__).resolve().parent
PAIR_IDS = (520183, 520177)
mace = mace_mp(
    model="/workspace/.local/cache/mace/mace-mp-0b3-medium.model",
    device="cpu",
    default_dtype="float64",
)
chgnet = CHGNetCalculator(model=CHGNet.load(), use_device="cpu")
rows = []

for radius in (6, 7):
    for frame in ("step0", "step1000"):
        atoms = read(ROOT / f"c_pair_{frame}_R{radius}.extxyz")
        ids = atoms.arrays["lammps_id"]
        ia = int(np.flatnonzero(ids == PAIR_IDS[0])[0])
        ib = int(np.flatnonzero(ids == PAIR_IDS[1])[0])
        vec = atoms.positions[ib] - atoms.positions[ia]
        distance = np.linalg.norm(vec)
        unit = vec / distance
        for name, calc in (("MACE-MP-0b3-medium", mace), ("CHGNet-0.3.0", chgnet)):
            atoms.calc = calc
            energy = float(atoms.get_potential_energy())
            forces = atoms.get_forces()
            relative = float(np.dot(forces[ib] - forces[ia], unit))
            rows.append(
                {
                    "radius_A": radius,
                    "frame": frame,
                    "atoms": len(atoms),
                    "model": name,
                    "energy_eV": energy,
                    "C_pair_distance_A": distance,
                    "C_pair_separating_force_eV_per_A": relative,
                }
            )

with (ROOT / "mlip_radius_sensitivity.csv").open("w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=rows[0].keys())
    writer.writeheader()
    writer.writerows(rows)

for row in rows:
    print(row, flush=True)
