# 150×300×300 Å TTM 诊断报告

日期：2026-10-01（Asia/Shanghai）  
工作目录：/workspace/.local/lammps-ttm/run-upload-20260930  
诊断输出：/workspace/.local/lammps-ttm/overnight_TTM_diagnostic_20261001

## 结论与阶段门槛

| 阶段 | 状态 | 结果 |
|---|---|---|
| 1. step10 restart 与 TTM 状态 | PASS（有 RNG 连续性限制） | 电子温度网格及 per-atom Langevin restart 回调均有运行时确认；未读取初始 Te 文件 |
| 2. step0/step10 run 0 与力/几何比较 | FAIL，停止条件命中 | 找到固定层 Ag–Ti 1.000209 Å 短接触；Fmax 增长的分力来源仍无法确认 |
| 3. step10 到 step11 | NOT RUN | 阶段2失败，按要求不继续 |
| 长跑前置检查 | NO-GO | 缺少稳定熔池起点、熔池 TTM 场、热源输入及已验证的 surface mask |

新增 MD 步数为 0。执行了三个 run 0 检查（step10 restart readback、step0、step10），没有推进 timestep；没有运行 step11、0.1 ps、1 ps 或 2 ps，也没有覆盖原有日志、restart 或轨迹。

## 阶段 1：step10 restart 状态恢复

执行文件版本为 LAMMPS 30 Sep 2026；/workspace/.local/lammps-ttm/bin/lmp_mpi 与编译目录下的 lmp_mpi SHA256 相同，为 5ccc549d6bc0f479b9d0ced08e8d0e3d429c6b4f7c33cf696ecec85deba4996d。restart 输入保留 fix ID twotemp、style ttm/thermal、15×30×30 网格和相同属性文件，特意省略 infile stage65_initial_Te_15x30x30.dat。

源码检查结果：

- FixTTM::write_restart 写入网格尺寸、seed 和整个电子温度网格；restart() 检查网格尺寸并恢复电子温度数组。
- 基类设置 restart_global 与 restart_peratom。pack_restart/unpack_restart 保存并恢复每原子的三分量 Langevin 力。
- FixTTM::restart 将保存的 seed 加 1 后创建新的 RanMars。因此网格/per-atom 状态可以读回，但内部 PRNG 序列不作逐位连续保证。
- LAMMPS 添加匹配 fix 后先执行 post_constructor，再按 restart 文件中的 ID/style 调用 global restart 和 per-atom unpack。实际日志记录 twotemp 的 global 和 per-atom restart 信息均已重新分配，且 global/peratom restart 项全部重新分配。
- restart 输入没有初始温度 infile；run 0 后 step=10、atom count=682587、TTM electron energy=1823.816493。由 step10 网格文件与电子比热网格按 fix_ttm/thermal 的能量公式离线积分得到 1823.8164930343767，吻合到数值精度，证明恢复的是 step10 网格而不是重新读入均匀 300 K 初态。

restart run 0 的 TTM transfer vector 为 0；这是没有推进一步时的当前交换量，不代表 step0–10 的累计交换。restart 实现也没有保存 net_energy_transfer_all 交换累加数组，所以不能从 restart readback 恢复累计交换历史。

## 阶段 2：run 0、Fmax 与局部几何

step0 和 step10 分别使用独立目录、完整 LAMMPS 日志及一帧全原子 dump；两次均为 5 个 MPI ranks、exit 0、682587 atoms，无 runtime ERROR、lost atoms、NaN 或非有限 dump 数值。

| 状态 | 温度 K | PE | KE | 总原子能 | TTM 电子能 | run 0 TTM transfer | LAMMPS Fmax eV/Å |
|---|---:|---:|---:|---:|---:|---:|---:|
| step0 | 269.98095 | -4077237.7 | 23820.733 | -4053417 | 1822.088622 | 0 | 10.7394 |
| step10 restart | 270.2135 | -4077260.3 | 23841.252 | -4053419 | 1823.816493 | 0 | 24.0992 |

LAMMPS 的 thermo Fmax 定义为全原子力分量的最大绝对值。step0 的最大分量来自 ID 46388、type 3（C），位置 (129.178, 98.486, 72.1262) Å，力分量 (6.42918, -10.7394, 2.29259) eV/Å；最近 Ti 邻居距离约 1.893、1.894、1.905 Å。step10 的最大分量来自另一个 C 原子 ID 178431，位置 (75.3236, 247.941, 13.7408) Å，力分量 (-2.85957, 24.0992, 1.53335) eV/Å；最近 Ti 邻居距离约 1.887、1.951、1.961 Å，距最近盒面 13.74 Å。

ID 178431 在 step0 的最大分量只有 0.7741 eV/Å。它到最近 Ti 邻居的距离从 1.885293 Å 变为 1.886960 Å，位置只移动约 0.01263 Å；局部距离没有明显缩短，不能解释其总力分量跃升至 24.0992 eV/Å。FixTTM::post_force 会将速度阻尼项和 gamma2×(uniform−0.5) 随机 Langevin 项加入原子力，这使 TTM 随机力成为合理候选解释；但 dump 保存的是合力，当前证据不能分离势函数力与 TTM 力，故 Fmax 上升原因仍标为 INCONCLUSIVE。step10 run 0 会重新执行 force setup，不能把它的 Fmax 当成原 10 步运行中最后一步的同一随机力样本。此前日志的 step10 Fmax 约 23.8 eV/Å，与本次 restart run 0 的 24.0992 eV/Å不应直接视为同一数值。

两帧全体系的周期最短原子对相同：ID 2151（type 4 Ag，144.400, 44.800, 2.400 Å）与 ID 2158（type 1 Ti，144.794, 45.4545, 1.75439 Å），最小像距离 1.000209 Å。二者位于 x=140–150.1 Å 固定层，受 fix setforce 后力为零；它们不是 Fmax 原子，也不是跨周期边界的接触，但该间距相对 type 1–4 Morse 参数 r0=2.337 Å 是显著短接触。它属于明确的几何异常，阶段2因此 FAIL 并停止。step0/step10 的 Fmax 原子都不在盒面附近；全局短接触也不跨 PBC。当前没有做长程 PBC contact/spanning 判断。

TTM 网格有 13500/13500 个有限值：初始场为 300 K；step10 场范围 239.700–379.705 K，均值 300.566 K。按同一属性网格积分，电子能由 1822.088622 增至 1823.816493，变化 +1.727871。run 0 的 transfer 值为零且不是累计交换；step0–10 的累计能量闭合还需要 thermostat 做功和交换历史，现有 restart 未保留该累加量，结论为“无法确认”，不判为通过。

## 长跑前置检查

未找到与该 300×300 模型匹配的稳定熔池 checkpoint、熔池电子温度场或正式热源输入。项目文件中只有 300 K 冷态模型、均匀 300 K 初始 Te、10 步 smoke 输入及其 step10 smoke restart。run_ttm_10steps.in 不含 source 热源设置；fix ttm/thermal 默认 inductive_power=0。准备包 README 也说明该 300 K 网格是新建冷态烟测初态，不是找回的旧熔池场。

势文件与类型映射已核验，但没有发现可对照的稳定 300×300 熔池案例，因此无法完成与稳定案例的哈希和类型映射比对：

- 类型映射：1 Ti、2 Si、3 C、4 Ag。
- Ag_u3.eam SHA256：cb3d605cd27ec6efb50c4dd7462c2ab3d967e63775dc4400de9134315a44d807。
- TSCBOP.tersoff SHA256：729273a6488d75756ed7927432c77c7347a1b115cecbaefae4981bafcec80fd7。
- potential.interface_calibration_v0.inc SHA256：34deced5e08174ba369290b87f5c3bfd2b284b272991adf302b2b0d28c12815f。
- 势文件明确标为 calibration version 0 / not a production potential。

目前只有 in.regions_x_surface.inc 的静态区域分组与 fixed layer 定义；没有找到适用于 300×300 模型的已冻结 surface atom mask。长跑的 PBC spanning/contact 状态未验证。

资源观测：nproc=5，cgroup CPU quota=4 核，memory.max=32 GiB，当前 memory.current 约 2.5 GiB，/workspace 可用磁盘约 28 GiB。此前 5-rank 10 步试跑吞吐约 0.344 steps/s，按此估算每 0.1 ps（1000 步）约 49 分钟、1 ps 约 8.1 小时、2 ps 约 16.2 小时。当前接口未暴露可确认的任务级运行时限，无法保证 8–16 小时任务可持续执行。资源估计不改变科学前置条件失败的结论。

**长跑结论：NO-GO。** 缺少匹配的稳定熔池起点/TTM 场和热源输入；标定势未与稳定案例核对；存在 1.000209 Å 固定层 Ag–Ti 短接触；Fmax 合力分解及能量闭合未确认；surface mask 未找到。不得把现有 300 K smoke 输入延长为熔池模拟。

## 证据文件

- 阶段1完整日志：stage1_restart_state/run.stdout 与 stage1_restart_state/log.lammps
- 阶段1输入：stage1_restart_state/restart_run0.in
- 原始输入、restart、TTM 网格、势和源码 SHA256 校验：stage1_restart_state/source_sha256.txt
- step0 完整日志与单帧 dump：stage2_step0/run.stdout、stage2_step0/log.lammps、stage2_step0/step0_forces.dump
- step10 完整日志与单帧 dump：stage2_step10/run.stdout、stage2_step10/log.lammps、stage2_step10/step10_forces.dump
- 最大力原子、邻居距离、最短原子对、TTM 网格能量计算：stage2_force_diagnostics_final.json

未对输入模型、势、TTM 源码或既有运行产物作修改。所有本次日志、输入副本和单帧 dump 均在本报告目录下。
