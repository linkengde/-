#!/usr/bin/env python3
"""Evaluate v7-forceonly against existing Ag-C/Ag-Si/Ag-Ti LCAO cluster labels."""
from pathlib import Path
import csv,json
import numpy as np
import torch
from ase.io import read
from mace.calculators import MACECalculator
ROOT=Path(__file__).resolve().parent
PROJECT=ROOT.parent
SCREEN=PROJECT.parent/'composition_candidate_screen/interface_contact_scan'
OUT=ROOT/'evaluation_lcao_cluster_transfer'
if OUT.exists(): raise SystemExit(f'Refusing to overwrite {OUT}')
OUT.mkdir()
cases=[]
for contact,candidate in [('AgC','candidate_Ag_C_R6.extxyz'),('AgSi','candidate_Ag_Si_R6.extxyz'),('AgTi','candidate_Ag_Ti_R6.extxyz')]:
 base=SCREEN/'pbe'/contact.replace('Ag','Ag_')
 cases.append((f'{contact}_nearest',SCREEN/candidate,base/'forces.csv',base/'summary.json'))
cases.append(('AgC_secondary_nearest',SCREEN/'AgC_secondary/candidate_Ag_C_R6.extxyz',SCREEN/'AgC_secondary/pbe/forces.csv',SCREEN/'AgC_secondary/pbe/summary.json'))
for env in ('primary','secondary'):
 base=SCREEN/'AgC_environment_distance_scans_PBE_v1'/env
 for dist in ('2.0','2.4'):
  p=base/f'd{dist}'; cases.append((f'AgC_{env}_d{dist}',p/'input.extxyz',p/'forces.csv',p/'summary.json'))
for env,distances in [('AgSi',('2.2','2.8')),('AgTi',('2.1','2.7'))]:
 base=SCREEN/'AgTi_AgSi_environment_distance_scans_PBE_v1'/env
 for dist in distances:
  p=base/f'd{dist}'; cases.append((f'{env}_d{dist}',p/'input.extxyz',p/'forces.csv',p/'summary.json'))
model_paths={
 'v5':PROJECT/'mace_periodic_v5/models/Ag_Ti_Si_C_MACE_periodic_v5.model',
 'v6':PROJECT/'mace_periodic_v6/models/Ag_Ti_Si_C_MACE_periodic_v6.model',
 'v7_forceonly':ROOT/'models/Ag_Ti_Si_C_MACE_periodic_v7_forceonly.model'}
train_frames={'AgC_primary_d2.0','AgC_primary_d2.4','AgC_secondary_d2.0','AgC_secondary_d2.4'}
torch.set_default_dtype(torch.float64)
calcs={}
for name,path in model_paths.items():
 model=torch.load(path,map_location='cpu',weights_only=False).double().eval()
 calcs[name]=MACECalculator(models=[model],device='cpu',default_dtype='float64')
rows=[]
for name,structure,forcefile,metafile in cases:
 a=read(structure);a.pbc=False
 symbols=np.asarray(a.get_chemical_symbols());ids=np.asarray(a.arrays['lammps_id'],int)
 with forcefile.open() as f: byid={int(r['lammps_id']):np.array([float(r[f'f{x}_eV_A']) for x in 'xyz']) for r in csv.DictReader(f)}
 ref=np.stack([byid[int(i)] for i in ids]);cp=np.flatnonzero(np.asarray(a.arrays['central_pair'],bool))
 ag=next(i for i in cp if symbols[i]=='Ag'); partner=next(i for i in cp if symbols[i]!='Ag')
 sep=a.positions[ag]-a.positions[partner];dist=float(np.linalg.norm(sep));unit=sep/dist
 refpair=float(np.dot(ref[ag]-ref[partner],unit));meta=json.loads(metafile.read_text())
 row={'case':name,'contact':symbols[partner],'atoms':len(a),'distance_A':dist,
      'reference_pair_separating_force_eV_A':refpair,'reference_Fmax_eV_A':float(np.linalg.norm(ref,axis=1).max()),
      'v7_force_training_frame':name in train_frames}
 for modelname,calc in calcs.items():
  trial=a.copy();trial.calc=calc;e=float(trial.get_potential_energy());f=np.asarray(trial.get_forces());delta=f-ref
  pair=float(np.dot(f[ag]-f[partner],unit))
  row[f'{modelname}_force_RMSE_eV_A']=float(np.sqrt(np.mean(delta**2)))
  row[f'{modelname}_pair_force_error_eV_A']=pair-refpair
  row[f'{modelname}_energy_error_meV_atom']=(e-float(meta['PBE_energy_eV']))*1000/len(a)
 rows.append(row)
with (OUT/'per_case.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary={'cases':len(rows),'reference_method':'Existing PBE/LCAO local-cluster labels; diagnostic mix of train points and independent contacts.',
 'models':{},'per_case_csv':str(OUT/'per_case.csv'),
 'note':'The four named Ag-C endpoints were force-only training frames for v7. Values on those four are in-sample. Other cases were not in the v7 training split, but are still LCAO rather than PW heldouts.'}
for m in model_paths:
 squared=0.;components=0;pairerrs=[]
 for r in rows:
  n=int(r['atoms']);squared+=float(r[f'{m}_force_RMSE_eV_A'])**2*3*n;components+=3*n
  pairerrs.append(abs(float(r[f'{m}_pair_force_error_eV_A'])))
 summary['models'][m]={'all_component_force_RMSE_eV_A':float(np.sqrt(squared/components)),
                       'pair_force_MAE_eV_A':float(np.mean(pairerrs))}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
