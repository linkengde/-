from pathlib import Path
import csv
import json

import numpy as np
from ase.io import read


ROOT = Path(__file__).resolve().parent
SCAN = ROOT / "interface_contact_scan"
OUT = SCAN / "mace_pbe_force_comparison.json"
if OUT.exists():
    raise SystemExit(f"Refusing to reuse existing output file: {OUT}")


def load_forces(path):
    with path.open() as f:
        return {
            int(r["lammps_id"]): {
                "symbol": r["symbol"],
                "force": np.array([float(r[f"f{x}_eV_A"]) for x in "xyz"]),
            }
            for r in csv.DictReader(f)
        }


pbe_summary = json.loads((SCAN / "pbe" / "summary.json").read_text())
mace_summary = json.loads((SCAN / "mace" / "summary.json").read_text())
results = []
by_element = []
for pbe_row, mace_row in zip(pbe_summary, mace_summary):
    scaffold = pbe_row["pair"].split("-")[1]
    atoms = read(SCAN / f"candidate_Ag_{scaffold}_R6.extxyz")
    ids = atoms.arrays["lammps_id"].astype(int)
    pair_mask = atoms.arrays["central_pair"].astype(bool)
    symbols = atoms.get_chemical_symbols()
    ag_i = int(np.flatnonzero(pair_mask & (np.asarray(symbols) == "Ag"))[0])
    sc_i = int(np.flatnonzero(pair_mask & (np.asarray(symbols) == scaffold))[0])
    vector = atoms.positions[sc_i] - atoms.positions[ag_i]
    unit = vector / np.linalg.norm(vector)
    pbe = load_forces(SCAN / "pbe" / f"Ag_{scaffold}" / "forces.csv")
    mace = load_forces(SCAN / "mace" / f"candidate_Ag_{scaffold}_forces.csv")
    common = sorted(set(pbe) & set(mace))
    if len(common) != len(ids) or any(pbe[i]["symbol"] != mace[i]["symbol"] for i in common):
        raise SystemExit(f"Atom IDs or elements differ for Ag-{scaffold}")
    delta = np.array([mace[i]["force"] - pbe[i]["force"] for i in common])
    pbe_vectors = np.array([pbe[i]["force"] for i in common])
    pbe_pair = float(np.dot(pbe[pbe_row["scaffold_id"]]["force"] - pbe[pbe_row["Ag_id"]]["force"], unit))
    mace_pair = float(np.dot(mace[pbe_row["scaffold_id"]]["force"] - mace[pbe_row["Ag_id"]]["force"], unit))
    rmse = float(np.sqrt(np.mean(np.sum(delta**2, axis=1))))
    pbe_rms = float(np.sqrt(np.mean(np.sum(pbe_vectors**2, axis=1))))
    results.append({
        "pair": pbe_row["pair"], "atoms": len(common),
        "distance_A": pbe_row["distance_A"],
        "PBE_pair_separating_force_eV_per_A": pbe_pair,
        "MACE_pair_separating_force_eV_per_A": mace_pair,
        "pair_force_abs_error_eV_per_A": abs(mace_pair - pbe_pair),
        "force_vector_rmse_eV_per_A": rmse,
        "PBE_force_vector_rms_eV_per_A": pbe_rms,
        "normalized_force_vector_rmse": rmse / pbe_rms if pbe_rms else None,
    })
    for element in ("Ag", "Ti", "Si", "C"):
        selected = [j for j, atom_id in enumerate(common) if pbe[atom_id]["symbol"] == element]
        if not selected:
            continue
        e_rmse = float(np.sqrt(np.mean(np.sum(delta[selected]**2, axis=1))))
        by_element.append({"pair": pbe_row["pair"], "element": element, "atoms": len(selected), "force_vector_rmse_eV_per_A": e_rmse})

data = {"summary": results, "by_element": by_element}
OUT.write_text(json.dumps(data, indent=2) + "\n")
print(json.dumps(data, indent=2))
