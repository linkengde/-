from pathlib import Path
import csv
import json

import numpy as np
from ase.io import read
import gpaw_data


ROOT = Path(__file__).resolve().parent
SETUP = Path(gpaw_data.datapath())
import os
os.environ["GPAW_SETUP_PATH"] = str(SETUP)

from gpaw import GPAW
from gpaw.mixer import Mixer
from gpaw.occupations import FermiDirac


STRUCTURE = ROOT / "composition_candidate_c_pair_R6.extxyz"
OUT_DIR = ROOT / "gpaw_R6"
if OUT_DIR.exists():
    raise SystemExit(f"Refusing to reuse existing output directory: {OUT_DIR}")
OUT_DIR.mkdir()
atoms = read(STRUCTURE)
atoms.calc = GPAW(
    mode="lcao",
    basis="dzp",
    xc="PBE",
    occupations=FermiDirac(0.1),
    mixer=Mixer(beta=0.05, nmaxold=8, weight=100.0),
    convergence={"energy": 1e-4, "density": 1e-4, "eigenstates": 1e-4},
    maxiter=120,
    txt=str(OUT_DIR / "gpaw.log"),
)
energy = float(atoms.get_potential_energy())
forces = atoms.get_forces()
ids = atoms.arrays["lammps_id"].astype(int)
norms = np.linalg.norm(forces, axis=1)
pair = {}
for atom_id in (520183, 520177):
    i = int(np.flatnonzero(ids == atom_id)[0])
    pair[atom_id] = i
ia, ib = pair[520183], pair[520177]
vector = atoms.positions[ib] - atoms.positions[ia]
distance = float(np.linalg.norm(vector))
separating = float(np.dot(forces[ib] - forces[ia], vector / distance))

with (OUT_DIR / "forces.csv").open("x", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["lammps_id", "symbol", "fx_eV_A", "fy_eV_A", "fz_eV_A", "force_norm_eV_A"])
    for atom_id, atom, force, norm in zip(ids, atoms, forces, norms):
        writer.writerow([int(atom_id), atom.symbol, *map(float, force), float(norm)])
atoms.calc.write(str(OUT_DIR / "state.gpw"), mode="all")
summary = {
    "atoms": len(atoms),
    "energy_eV": energy,
    "C_pair_distance_A": distance,
    "C_pair_separating_force_eV_per_A": separating,
    "C520183_force_norm_eV_per_A": float(norms[ia]),
    "C520177_force_norm_eV_per_A": float(norms[ib]),
    "max_force_norm_eV_per_A": float(norms.max()),
    "max_force_lammps_id": int(ids[int(norms.argmax())]),
}
(OUT_DIR / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2), flush=True)
