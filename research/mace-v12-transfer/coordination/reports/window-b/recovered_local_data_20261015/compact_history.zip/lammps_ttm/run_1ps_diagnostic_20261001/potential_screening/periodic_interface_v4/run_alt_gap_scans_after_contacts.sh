#!/usr/bin/env bash
set -u

contact_pid="${1:?pass the active Si/C contact-DFT queue PID}"
root="/workspace/.local/lammps-ttm/run_1ps_diagnostic_20261001/potential_screening/periodic_interface_v4"
python="/workspace/.local/venvs/gpaw/bin/python"
contact_log="$root/alt_termination_serial_launcher.log"
scan_log="$root/alt_gap_scan_serial_launcher.log"

while :; do
  if rg -q 'All queued alternate-termination PBE checks completed\.' "$contact_log" 2>/dev/null; then
    break
  fi
  if rg -q 'STOP:' "$contact_log" 2>/dev/null; then
    echo "STOP: initial Si/C contact scan did not pass; no gap scan was launched." >> "$scan_log"
    exit 1
  fi
  if ! kill -0 "$contact_pid" 2>/dev/null; then
    echo "STOP: initial Si/C queue ended without a completion marker." >> "$scan_log"
    exit 1
  fi
  sleep 20
done

echo "Initial Ag-Si and Ag-C contact checks converged; starting gap scans." >> "$scan_log"
for element in Si C; do
  for gap in 2.3 2.9; do
    label="${element}_gap_scan"
    stdout="$root/alt_gap_scan_${element}_d${gap}.stdout"
    "$python" -u "$root/run_one_interface_pbe.py" "$gap" "$label" \
      structures_alt_terminations_gap_scan "Ag_${element}_terminated" > "$stdout" 2>&1
    status=$?
    if [[ "$status" -ne 0 ]]; then
      echo "STOP: ${element} gap ${gap} Å PBE calculation ended with status $status." >> "$scan_log"
      exit "$status"
    fi
    echo "${element} gap ${gap} Å PBE calculation converged." >> "$scan_log"
  done
done
echo "All Si/C gap scans completed and converged." >> "$scan_log"
