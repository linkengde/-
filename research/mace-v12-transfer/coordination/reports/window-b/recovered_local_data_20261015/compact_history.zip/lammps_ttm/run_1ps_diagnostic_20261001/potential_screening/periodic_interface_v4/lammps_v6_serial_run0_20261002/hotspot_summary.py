from pathlib import Path
import csv,json
import numpy as np
from ase.io import read
here=Path(__file__).resolve().parent
root=here.parent
src=root.parent/'composition_candidate_screen/interface_contact_scan/AgC_secondary/candidate_Ag_C_R6.extxyz'
atoms=read(src); atoms.pbc=False
forces=np.zeros((len(atoms),3))
lines=(here/'forces.dump').read_text().splitlines(); i=next(i for i,l in enumerate(lines) if l.startswith('ITEM: ATOMS'))+1
for line in lines[i:]:
 f=line.split()
 if len(f)==8: forces[int(f[0])-1]=[float(x) for x in f[5:8]]
norm=np.linalg.norm(forces,axis=1); imax=int(norm.argmax())
ids=np.asarray(atoms.arrays.get('lammps_id',np.arange(1,len(atoms)+1)),dtype=int)
cp=np.flatnonzero(np.asarray(atoms.arrays.get('central_pair',np.zeros(len(atoms))),dtype=bool))
pair=None
if len(cp)==2:
 ag=next(i for i in cp if atoms[i].symbol=='Ag'); other=next(i for i in cp if atoms[i].symbol!='Ag')
 d=float(np.linalg.norm(atoms.positions[ag]-atoms.positions[other]))
 pair={'Ag_source_id':int(ids[ag]),'other_source_id':int(ids[other]),'other_element':atoms[other].symbol,'distance_A':d}
obj={'atoms':len(atoms),'max_force_eV_A':float(norm[imax]),'max_force_lammps_id':imax+1,'max_force_source_id':int(ids[imax]),'max_force_element':atoms[imax].symbol,'max_force_position_A':atoms.positions[imax].tolist(),'central_pair':pair,'force_source':'MACE v6 through LAMMPS run 0; values rounded in dump'}
out=here/'lammps_v6_force_hotspot.json'
with out.open('x') as f: json.dump(obj,f,indent=2); f.write('\n')
print(json.dumps(obj,indent=2))
