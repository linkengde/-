from pathlib import Path
import csv
import json

import numpy as np
from scipy.spatial import cKDTree
from ase import Atoms
from ase.io import write


ROOT = Path(__file__).resolve().parent
CANDIDATE = Path(
    "/workspace/.local/lammps-ttm/composition_locked_candidate_20260930/"
    "stage65_model_fcc_ag_59p8775wt_candidate.data"
)
AG_FORCE_DUMP = Path(
    "/workspace/.local/lammps-ttm/composition_locked_candidate_20260930/"
    "run0/ag_run0_forces.dump"
)
OUT = ROOT / "interface_contact_scan"
BOX = np.array([150.1, 300.0, 300.0])
SYMBOL = {1: "Ti", 2: "Si", 3: "C", 4: "Ag"}

if OUT.exists():
    raise SystemExit(f"Refusing to reuse existing output directory: {OUT}")
OUT.mkdir()

ids, types, xyz = [], [], []
in_atoms = False
with CANDIDATE.open() as f:
    for line in f:
        s = line.strip()
        if s.startswith("Atoms"):
            in_atoms = True
            continue
        if not in_atoms:
            continue
        a = s.split()
        if len(a) == 5 and a[0].isdigit():
            ids.append(int(a[0])); types.append(int(a[1])); xyz.append([float(x) for x in a[2:5]])
        elif ids and s and not s.startswith("#"):
            break
ids = np.asarray(ids, dtype=np.int64)
types = np.asarray(types, dtype=np.int8)
xyz = np.asarray(xyz, dtype=float)
if len(ids) != 682587:
    raise SystemExit(f"Expected 682587 atoms, parsed {len(ids)}")

ag_idx = np.flatnonzero(types == 4)
rows = []
contact_pairs = {}
for scaffold_type in (1, 2, 3):
    sc_idx = np.flatnonzero(types == scaffold_type)
    tree = cKDTree(xyz[sc_idx], boxsize=BOX)
    distances, local_idx = tree.query(xyz[ag_idx], k=1, workers=-1)
    order = np.argsort(distances)[:20]
    rows_for_type = []
    for j in order:
        ai = int(ag_idx[j]); si = int(sc_idx[local_idx[j]])
        row = {
            "Ag_id": int(ids[ai]),
            "Ag_type": SYMBOL[4],
            "scaffold_id": int(ids[si]),
            "scaffold_type": SYMBOL[scaffold_type],
            "distance_A": float(distances[j]),
        }
        rows_for_type.append(row)
    contact_pairs[SYMBOL[scaffold_type]] = rows_for_type
    rows.append(rows_for_type[0])

with (OUT / "nearest_cross_contacts.csv").open("x", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=rows[0].keys())
    writer.writeheader(); writer.writerows(rows)

# Make one exact local DFT candidate around each closest cross-species contact.
manifests = []
index = {int(atom_id): i for i, atom_id in enumerate(ids)}
cell = np.eye(3) * 28.0
for scaffold_symbol, entries in contact_pairs.items():
    pair = entries[0]
    pair_ids = (pair["Ag_id"], pair["scaffold_id"])
    ia, ib = (index[k] for k in pair_ids)
    delta = xyz[ib] - xyz[ia]
    delta -= BOX * np.rint(delta / BOX)
    pair_distance = float(np.linalg.norm(delta))
    center = (xyz[ia] + 0.5 * delta) % BOX
    relative = xyz - center
    relative -= BOX * np.rint(relative / BOX)
    d = np.linalg.norm(relative, axis=1)
    radius = 6.0
    chosen = d <= radius
    pos = relative[chosen] + 14.0
    selected_types = types[chosen]
    selected_ids = ids[chosen]
    atoms = Atoms(
        [SYMBOL[int(t)] for t in selected_types],
        positions=pos,
        cell=cell,
        pbc=False,
    )
    atoms.new_array("lammps_id", selected_ids)
    atoms.new_array("lammps_type", selected_types)
    atoms.new_array("central_pair", np.isin(selected_ids, pair_ids).astype(np.int32))
    out_path = OUT / f"candidate_Ag_{scaffold_symbol}_R6.extxyz"
    write(out_path, atoms, format="extxyz")
    manifests.append({
        "pair_ids": list(pair_ids), "pair_symbols": ["Ag", scaffold_symbol],
        "distance_A": pair_distance, "atoms": len(atoms), "cluster_file": out_path.name,
    })

# Record the largest Ag force norms reported in the existing full-size v0 run0 dump.
ag_force_rows = []
lines = AG_FORCE_DUMP.read_text().splitlines()
header = next(i for i, line in enumerate(lines) if line.startswith("ITEM: ATOMS"))
for line in lines[header + 1:]:
    f = line.split()
    if len(f) < 9:
        continue
    fx, fy, fz = map(float, f[5:8])
    ag_force_rows.append({"id": int(f[0]), "norm_eV_per_A": float(np.linalg.norm([fx, fy, fz]))})
ag_force_rows.sort(key=lambda r: r["norm_eV_per_A"], reverse=True)

summary = {
    "candidate_data": str(CANDIDATE),
    "atom_count": len(ids),
    "nearest_cross_contacts": rows,
    "contact_cluster_models": manifests,
    "top_10_Ag_force_norms_from_existing_full_size_v0_run0": ag_force_rows[:10],
    "caveat": "Clusters use minimum-image positions, then nonperiodic vacuum boundary; these are local DFT screening fragments, not periodic interface calculations.",
}
(OUT / "contact_manifest.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
