#!/usr/bin/env python3
"""Continue the small reconstructed Ti3SiC2 motif with a damped FIRE relaxer."""
from pathlib import Path
import json
import os

import gpaw_data
import numpy as np
from ase.io import read, write
from ase.optimize import FIRE

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT / "bulk_pbe_relaxed_1x2x1"
OUT = ROOT / "bulk_pbe_fire_1x2x1"
OUT.mkdir(exist_ok=False)

os.environ["GPAW_SETUP_PATH"] = str(gpaw_data.datapath())
from gpaw import GPAW  # noqa: E402

atoms = read(PREVIOUS / "relax.traj", index=-1)
atoms.calc = GPAW(
    str(ROOT / "mace_seed_pbe_1x2x1" / "state.gpw"),
    txt=str(OUT / "gpaw_fire.log"),
)
optimizer = FIRE(
    atoms,
    trajectory=str(OUT / "fire.traj"),
    logfile=str(OUT / "fire.log"),
    dt=0.05,
    dtmax=0.10,
    maxstep=0.02,
    Nmin=5,
    finc=1.1,
    fdec=0.5,
    astart=0.1,
    fa=0.99,
)
converged = optimizer.run(fmax=0.10, steps=30)
forces = np.asarray(atoms.get_forces())
norms = np.linalg.norm(forces, axis=1)
energy = float(atoms.get_potential_energy())
np.savetxt(
    OUT / "forces.csv",
    np.column_stack((np.arange(1, len(atoms) + 1), forces)),
    delimiter=",",
    header="atom_index,fx_eV_A,fy_eV_A,fz_eV_A",
    comments="",
)
write(OUT / "Ti3SiC2_PBE_Fire_1x2x1.extxyz", atoms, format="extxyz")
atoms.calc.write(OUT / "state.gpw")
summary = {
    "optimizer": "FIRE",
    "optimizer_converged": bool(converged),
    "atoms": len(atoms),
    "cell_A": atoms.cell.array.tolist(),
    "kpts": [1, 2, 1],
    "scf_thresholds": "1e-3",
    "target_fmax_eV_A": 0.10,
    "max_force_eV_A": float(norms.max()),
    "max_force_atom_index": int(norms.argmax() + 1),
    "max_force_element": atoms[int(norms.argmax())].symbol,
    "force_RMS_eV_A": float(np.sqrt(np.mean(forces * forces))),
    "extrapolated_energy_eV": energy,
    "steps": max(0, sum(1 for _ in open(OUT / "fire.log")) - 1),
    "note": (
        "Fixed-cell low-cost PBE position relaxation. The source motif is reconstructed "
        "from the supplied model and is not independently CIF-validated. This is a "
        "screening geometry only; a stricter PBE single point is still required."
    ),
}
(OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary), flush=True)
