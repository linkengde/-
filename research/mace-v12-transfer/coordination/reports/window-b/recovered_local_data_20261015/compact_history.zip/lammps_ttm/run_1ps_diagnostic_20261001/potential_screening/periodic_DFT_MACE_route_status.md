# Periodic DFT → environment-dependent potential: status

Date: 2026-10-01

## Status

The replacement-potential route is underway, but the Ag/Ti3SiC2 interaction is **not solved yet**. The current calibration-v0 cross terms are falsified by force-sign comparisons on fixed-geometry PBE clusters. The local-cluster MACE v3 model is not validated for periodic interfaces. No candidate or production model files were changed, and no long MD was started.

## Software and access

Installed versions:

- GPAW 26.7.0
- ASE 3.29.0
- MACE 0.3.16
- LAMMPS with the existing TTM build

No additional software download is needed for periodic PBE calculations or MACE fitting. An attempt to query Crossref through the current network proxy failed with HTTP 403, so the periodic Ti3SiC2 basis is explicitly marked as reconstructed from the repeated motif in the supplied model rather than independently sourced from a CIF.

## Existing cross-potential check

The Ag–Ti/Si/C terms in `potential.interface_calibration_v0.inc` are pairwise Morse terms. On fixed local structures, their forces do not reproduce the PBE direction at relevant separations:

| Contact | Separation (Å) | PBE separating force (eV/Å) | Calibration v0 (eV/Å) |
|---|---:|---:|---:|
| Ag–Ti | 2.3871 | +5.361 | −1.509 |
| Ag–Si | 2.4541 | +2.030 | −2.966 |
| Ag–Ti | 2.1000 | +17.035 | +9.100 |
| Ag–Ti | 2.7000 | −0.904 | −5.068 |
| Ag–Si | 2.2000 | +7.748 | +4.628 |

Positive means the PBE pair projection is separating/repulsive in the tested fixed geometry. At the two near-contact geometries, calibration v0 predicts attraction while PBE predicts repulsion. This agrees with the earlier finding that one common Morse curve cannot represent different local environments reliably.

Detailed PBE and run-0 outputs are in `composition_candidate_screen/interface_contact_scan/AgTi_AgSi_environment_distance_scans_PBE_v1/` and `composition_candidate_screen/interface_contact_scan/AgTi_AgSi_environment_distance_scans_LAMMPS_v0_v1/`.

## MACE check so far

The existing MACE v3 pilot was trained on nonperiodic local clusters. Applied with periodic boundary conditions to the first derived interface geometries, it predicts Fmax values of 3.94, 2.75, and 2.84 eV/Å at nominal Ag–Ti gaps of 2.3, 2.6, and 2.9 Å. There are no periodic PBE labels for these geometries yet, so these are out-of-domain predictions, not an accuracy measurement or a usable potential.

Predictions are recorded in `periodic_interface_v2/mace_v3_predictions/`.

## Periodic-cell audit and correction

A 28-atom fully periodic screening cell was constructed from the repeated Ti3SiC2 layer motif and a three-layer Ag(111) film. A later audit found that its stored 62.314 wt% Ag metadata used the 12-atom bulk formula even though the cut substrate actually contains Ti12Si2C8. The actual 28-atom cell contains Ag6Ti12Si2C8 and is 47.108 wt% Ag. Its Ag layer is laterally strained by about +4.8% and +5.1%, and it has two interfaces per periodic cell. Its preliminary PBE jobs were aborted before convergence because the substrate was not relaxed; those results are not used.

A fixed-cell bulk PBE single point converged, but the reconstructed substrate had a maximum residual force of 1.988 eV/Å. Therefore the first interface PBE attempts were stopped before SCF completion and marked ABORTED. A fixed-cell PBE atomic-position relaxation of the small substrate cell is now running. The unfinished variable-cell relaxation attempt is not used.

The 28-atom geometry is a screening cell, not yet a validated crystallographic interface. The 2.0 Å geometry was excluded from PBE because its Ag–Ti nearest-neighbor separation is 2.0 Å. The current relaxed-substrate step is required before any interface force fit is meaningful.

## Next gates

1. Finish and inspect the fixed-cell PBE relaxation. Require a small residual substrate force and check that the relaxed motif remains structurally reasonable.
2. Rebuild the periodic interface from that relaxed motif. Add representative Ti-, Si-, and C-contact environments; Ti termination alone cannot validate all Ag cross interactions.
3. Calculate PBE energies and forces for a small set of interface separations and local distortions. Compare the same configurations against calibration v0 and the MACE pilot.
4. Only if a held-out periodic configuration improves should those labels be used to fine-tune an environment-dependent MACE model. Keep at least one separation/environment out of training.
5. Before any production or TTM run, validate the MACE LAMMPS coupling with periodic ghost atoms. The current local compatibility shim explicitly requires a zero-ghost serial box, so it cannot yet drive the production periodic model.

The composition-locked candidate remains unchanged. The current step is static DFT and run-0 analysis only; no MD steps have been added.

## Integrity and execution evidence

- Candidate structure SHA256: `cec19e765c25ee932ea0296d7c6f768d58e521edc1e107abf62e7249a2f3b80c` (unchanged).
- Calibration-v0 cross-term include SHA256: `34deced5e08174ba369290b87f5c3bfd2b284b272991adf3029b2b0d28c12815f` (unchanged).
- The local MACE/LAMMPS compatibility shim contains an explicit `ntotal != nlocal` failure for ghost atoms; this is why its earlier successful LAMMPS check was only a zero-ghost serial check.

### 2026-10-01 update

- MACE-MP-0b3 was used only to pre-relax the 12-atom Ti3SiC2 motif at fixed cell. It converged in 5 ionic steps to Fmax 0.0191 eV/Å. This is a geometry seed, not a PBE result.
- A strict periodic PBE single point on that seed is running with the original bulk settings (PBE/LCAO-DZP, 1×4×2 k-points, 1e-4 SCF thresholds). Its residual force will determine whether another PBE ionic step is needed.
- A second interface builder is prepared to use the PBE-checked bulk coordinates, a reversed Ag stacking registry that can align both Ti terminations, and a fixed supercell length for the 2.3/2.6/2.9 Å complementary-gap scan.

The first high-k-point PBE restart on the MACE seed was stopped after 8 SCF cycles when density convergence remained far from threshold and iteration cost became excessive. It did not produce a force result and is not treated as a failed structure. A lower-cost 1×2×1, 1e-3-threshold PBE screening single point is running now; any geometry selected from it still needs the planned 1×4×2, 1e-4 confirmation.

The 1×2×1 PBE screen on the MACE-seeded bulk geometry converged electronically, but its residual Fmax is 1.135 eV/Å (Ti atom 11). That geometry is still not accepted. A fixed-cell PBE position relaxation, initialized from this converged PBE state, is now running at the same screening settings; its final structure must pass a tighter/higher-k-point PBE check.

### Continuation update — 2026-10-01 13:05 UTC

- Five orphaned GPAW interface scans were still consuming CPU even though their status files marked them ABORTED due to the unrelaxed substrate. They were sent SIGTERM; their partial logs remain intact. They are no longer doing useful work.
- The fixed-cell 1×2×1 PBE BFGS relaxation reached 11 completed ionic steps. Fmax oscillated between 0.181 and 0.406 eV/Å over the last six steps, so that run was stopped and its full trajectory retained at `periodic_interface_v1/bulk_pbe_relaxed_1x2x1/relax.traj`.
- A separate damped FIRE continuation has started from the last saved BFGS geometry, with a 0.02 Å maximum step and a 0.10 eV/Å screening target. Its outputs are isolated under `periodic_interface_v1/bulk_pbe_fire_1x2x1/`.
- Neither the reconstructed substrate nor an Ag/Ti3SiC2 periodic interface has passed strict PBE validation yet. The interface scan and any MACE fitting remain gated on that result. The composition-locked production candidate remains unchanged; no MD was run.

### Higher-grid geometry check — 2026-10-01 13:44 UTC

- The low-grid FIRE substrate relaxation reached Fmax 0.08764 eV/Å after 7 steps at 1×2×1 k-points and 1e-3 SCF thresholds. This is a screening result only.
- A frozen-geometry PBE/LCAO-DZP single point converged at 1×4×2 k-points and 1e-4 thresholds, but its Fmax is 1.68359 eV/Å on Ti atom 3. Therefore the low-grid-relaxed geometry fails transfer to the stricter sampling and is not accepted for interface building.
- A new fixed-cell FIRE relaxation is now running directly at 1×4×2, initialized from that converged high-grid PBE state; its maximum atomic step is 0.02 Å. Output is isolated in `periodic_interface_v1/bulk_pbe_fire_1x4x2_relax/`.
- No periodic Ag/Ti3SiC2 force data have been calculated at a vetted relaxed substrate, and no replacement potential has passed a held-out periodic test. The candidate structure and calibration-v0 files remain untouched; no MD steps were run.

### Screening-cell composition correction — 2026-10-01

- The preliminary v2 periodic structure is `Ag6Ti12Si2C8`, not a stoichiometric bulk mixture, and its actual Ag mass fraction is 47.108 wt%. The earlier 62.314 wt% figure was incorrect because it used Ti6Si2C4 in the denominator. The old files are retained as archival, unvalidated screening artifacts.
- The unexecuted v3 builder had the same formula-counting error. It is corrected to compute mass fractions from the generated atom counts and to use five Ag layers (10 Ag atoms), giving 59.749 wt% Ag for this small integer-atom screening cell. The cut Ti-terminated substrate is explicitly labeled nonstoichiometric (`Ti12Si2C8`). The v3 structures have not yet been generated or sent to DFT.
- The 59.8775 wt% lock remains unchanged for the production candidate; it is not claimed for these small periodic DFT screening cells. The composition-locked candidate file remains byte-for-byte unchanged.

### High-grid FIRE progress — 2026-10-01 14:28 UTC

- Strict-grid fixed-cell relaxation has completed four atomic updates. Fmax decreased from 1.6836 to 1.4505 eV/Å, but remains far above the 0.10 eV/Å gate. The fifth high-grid step is running.
- This is slow but numerically progressing; no interface DFT points, MACE fine-tuning, LAMMPS TTM run, or MD steps have been made.
- The v3 builder now waits for a converged high-grid substrate, uses the actual `Ti12Si2C8` slab counts, calculates Ag wt% from generated atom numbers, and writes a five-layer (10-atom) Ag screening film. These structures have not yet been generated.

### High-grid FIRE progress — 2026-10-01 14:53 UTC

- The fixed-cell PBE/LCAO-DZP 1×4×2 FIRE relaxation has completed seven ionic updates. Fmax has decreased monotonically from 1.68359 to 1.04798 eV/Å; the eighth electronic minimization is in progress.
- The strict-grid structure remains above the 0.10 eV/Å gate, so the v3 interface builder has not been run. There are still no periodic Ag/interface PBE labels and no trained replacement potential.
- This is an unfinished geometry optimization, not a force-field result. The supplied production candidate and calibration-v0 files remain unchanged; no MD was run.

### High-grid FIRE progress — 2026-10-01 15:02 UTC

- Eight ionic updates are complete. Fmax decreased monotonically to 0.88879 eV/Å (energy −95.022851 eV/cell); step 9 is running.
- The 0.10 eV/Å convergence gate is not met. Interface construction and replacement-potential fitting remain blocked on the strict-grid substrate relaxation.

### High-grid FIRE progress — 2026-10-01 15:10 UTC

- Nine ionic updates are complete. Fmax decreased to 0.72475 eV/Å and the cell energy to −95.054627 eV; the decrease remains monotonic.
- The strict-grid relaxation is still above its 0.10 eV/Å gate. The periodic interface structures have not yet been generated or evaluated with DFT.

### High-grid FIRE progress — 2026-10-01 15:18 UTC

- Ten ionic updates are complete. Fmax decreased to 0.55619 eV/Å and the cell energy to −95.079322 eV; the decrease remains monotonic.
- Step 11 is proceeding. The substrate has not met the 0.10 eV/Å gate, so no interface DFT labels or replacement-potential results are available yet.

### High-grid FIRE progress — 2026-10-01 15:28 UTC

- Eleven ionic updates are complete. Fmax decreased to 0.39041 eV/Å and the cell energy to −95.097319 eV. Step 12 is in progress.
- The residual force remains above the 0.10 eV/Å gate; no periodic Ag interface has been evaluated yet.

### High-grid FIRE progress — 2026-10-01 15:38 UTC

- Twelve ionic updates are complete. Fmax is 0.32738 eV/Å and the cell energy is −95.109363 eV. It continues to decrease, though more slowly than during steps 8–11.
- Step 13 is underway. The fixed-cell strict-grid target remains 0.10 eV/Å; no interface DFT labels or refitted potential exist yet.

### High-grid FIRE progress — 2026-10-01 15:50 UTC

- Step 13 completed with Fmax 0.37450 eV/Å, up from 0.32738 eV/Å at step 12; the cell energy decreased to −95.116440 eV.
- This is a force rebound, not enough by itself to establish divergence. Step 14 is being monitored. The strict-grid convergence gate remains unmet and no interface labels have been calculated.
- Offline inspection of the saved trajectory shows the maximum moved to C atom 5; its shortest periodic Ti neighbors are 2.062–2.064 Å. No new unusually short contact was found in this small substrate motif.

### High-grid FIRE progress — 2026-10-01 16:11 UTC

- Step 15 completed with Fmax 0.38803 eV/Å, slightly below step 14's 0.39616 eV/Å. The hottest atom changed from C5 to C6; the largest ionic displacement in step 15 was 0.0090 Å.
- Across steps 12–15, Fmax oscillates around 0.33–0.40 eV/Å while energy continues to decrease. The fixed-cell optimization has not reached 0.10 eV/Å. A cell-stress check may be needed before extending or rebuilding the substrate.

### High-grid FIRE progress — 2026-10-01 16:17 UTC

- Step 16 completed with Fmax 0.38209 eV/Å; the total energy continues to decrease. The force is nearly plateaued around 0.38 eV/Å over steps 13–16.
- The 30-step fixed-cell run is continuing. If the force remains on this plateau, the next diagnostic is a DFT stress calculation on the saved geometry before choosing a variable-cell relaxation.

### High-grid FIRE progress — 2026-10-01 16:25 UTC

- Step 17 completed with Fmax 0.36445 eV/Å, down from 0.38209 eV/Å at step 16; energy continues to decrease.
- The force plateau persists but is not diverging. Step 18 is underway; the planned stress review remains gated on the end of this fixed-cell run.

### High-grid FIRE progress — 2026-10-01 16:33 UTC

- Step 18 completed with Fmax 0.34035 eV/Å, down from 0.36445 eV/Å. Energy continues to decrease.
- The fixed-cell force plateau is easing slowly but the 0.10 eV/Å convergence gate is still unmet. Step 19 is in progress.

### High-grid FIRE progress — 2026-10-01 16:42 UTC

- Step 19 completed with Fmax 0.30809 eV/Å, down from 0.34035 eV/Å. Energy continues to decrease.
- The fixed-cell relaxation is moving off its previous ~0.38 eV/Å plateau but remains above the 0.10 eV/Å gate; step 20 is underway.

### High-grid FIRE progress — 2026-10-01 16:49 UTC

- Step 20 completed with Fmax 0.27414 eV/Å, down from 0.30809 eV/Å. Energy continues to decrease.
- The fixed-cell relaxation is improving again but has not met the 0.10 eV/Å gate. Step 21 is underway.

### High-grid FIRE progress — 2026-10-01 16:56 UTC

- Step 21 completed with Fmax 0.23156 eV/Å, down from 0.27414 eV/Å; the cell energy continues to decrease.
- The high-grid fixed-cell relaxation remains above the 0.10 eV/Å gate. Step 22 is underway.

### High-grid FIRE progress — 2026-10-01 17:02 UTC

- Step 22 completed with Fmax 0.18724 eV/Å, down from 0.23156 eV/Å; the cell energy continues to decrease.
- The strict-grid relaxation is approaching but has not yet reached the 0.10 eV/Å gate. Step 23 is underway.

### High-grid FIRE progress — 2026-10-01 17:08 UTC

- Step 23 completed with Fmax 0.13013 eV/Å, down from 0.18724 eV/Å; the cell energy continues to decrease.
- The fixed-cell strict-grid relaxation is close to, but remains above, the 0.10 eV/Å gate. Step 24 is underway.

### Progress update — 2026-10-01 17:29 UTC

- Fixed-cell PBE/LCAO-DZP at 1×4×2 converged after 24 FIRE updates (25 log records): Fmax 0.06669 eV/Å, RMS force 0.03010 eV/Å. The high-grid SCF converged at every logged step.
- The corrected v3 builder generated three 32-atom periodic screening cells with `Ag10 Ti12 Si2 C8`; actual Ag mass fraction is 59.74943 wt%, 0.12807 percentage points below the 59.8775 production target. This is a small screening cell, not the composition-locked production candidate.
- A direct LCAO stress request failed because GPAW's `FDPotentialCalculator` in this configuration does not implement `stress`; no stress value was inferred from that failed call.
- A separate 500 eV plane-wave PBE single point at the same 1×4×2 grid converged electronically. It reports mean stress −8.16954 GPa (compressive), stress tensor in `bulk_pbe_fire_1x4x2_relax/stress_check_pw/summary.json`, and max force 0.1100 eV/Å on the LCAO-relaxed coordinates. The original fixed cell therefore is not mechanically pressure-relaxed.
- A variable-cell plane-wave PBE relaxation has started from an isolated copy. It allows all six strain components and atomic positions to relax; the production candidate remains untouched.

### Plane-wave variable-cell relaxation — 2026-10-01 17:38 UTC

- After 12 FIRE updates, the combined force/stress convergence metric fell from 0.6487 to 0.5553. Cell lengths expanded about 0.2% from the LCAO-relaxed starting cell.
- The diagonal stress components decreased from approximately (−8.34, −8.85, −7.32) GPa to (−7.07, −7.53, −6.22) GPa. The cell remains under substantial compression; variable-cell relaxation is continuing.

### Plane-wave variable-cell relaxation — 2026-10-01 17:41 UTC

- After 16 FIRE updates, the combined force/stress metric is 0.4254. The cell axes expanded 0.4–0.5% from the starting cell.
- The diagonal stresses decreased further to approximately (−5.35, −5.72, −4.74) GPa; maximum atomic force is about 0.096 eV/Å. Cell pressure remains substantial, so the variable-cell run continues.

### Plane-wave variable-cell relaxation — 2026-10-01 17:44 UTC

- After 20 FIRE updates, the combined force/stress metric is 0.2644. Cell lengths are about 0.9% larger than the initial cell.
- Diagonal stresses are now approximately (−3.29, −3.52, −2.92) GPa and maximum atomic force is 0.0907 eV/Å. Pressure is decreasing substantially; the variable-cell run continues.

### Plane-wave variable-cell relaxation — 2026-10-01 17:48 UTC

- The first 25-step PW-PBE/FrechetCellFilter segment hit its step limit with combined Fmax 0.09279 eV/Å, so it is not yet a converged cell.
- On that geometry, maximum atomic force is 0.03006 eV/Å, diagonal stresses are (−0.965, −0.950, −0.863) GPa, and the largest shear component is 0.743 GPa. Cell lengths are (8.9526, 3.0733, 5.3249) Å.
- This is a large reduction from the initial mean compression of −8.17 GPa. A separate continuation is being prepared from the saved end structure; no interface DFT or potential fit has started yet.

### Plane-wave variable-cell relaxation — continuation converged

- The PW-PBE/FrechetCellFilter continuation converged after 17 updates with combined Fmax 0.04345 eV/Å.
- The final maximum atomic force is 0.00652 eV/Å; the largest absolute stress component is 0.478 GPa. Final cell lengths are (8.96674, 3.07777, 5.33260) Å, with a small xz shear.
- The substrate is now mechanically relaxed under 500 eV plane-wave PBE at 1×4×2. Its motif is still reconstructed from the supplied model and has not been independently CIF-validated. The composition-locked production candidate remains unchanged.
- The Ag/Ti3SiC2 screen structures have been rebuilt from this final substrate as three 32-atom cells, retaining `Ag10Ti12Si2C8` and 59.74943 wt% Ag. The Ag layer is about 6.4% strained relative to the builder's experimental a0=4.09 Å assumption; this large coherent strain is recorded and must be assessed before interpreting interface energies.

### Ag PBE equation of state and interface DFT started — 2026-10-01

- A five-point fcc Ag PBE plane-wave EOS (500 eV, 6×6×6 k-grid, 1e-5 SCF thresholds) converged electronically at all five lattice constants. Birch–Murnaghan fit gives cubic a0 = 4.15200 Å and B = 90.13 GPa. This is an initial EOS; cutoff and k-point convergence have not been checked.
- Relative to this PBE a0, the coherent interface cell requires about +4.83% and +4.87% Ag in-plane strain along its two substrate vectors. This remains a significant finite-cell limitation.
- Periodic PBE single-point calculations are now running for the three 32-atom Ti-terminated gap structures (2.3, 2.6, 2.9 Å), using PW500 eV, k-points 1×4×2, and SCF thresholds 1e-5. Each output is isolated under `periodic_interface_v4/pbe_singlepoints_500eV/`; no production structure was modified, and no MD was run.
- These calculations are a local force/energy screening step only. The substrate motif is model-derived rather than independently crystallographically validated; the cells are not composition-locked to 59.8775 wt% Ag; only Ti-terminated contacts are included; and the cross potential is still unvalidated.

### Interface PBE SCF progress — 2026-10-01 18:37 UTC

- The first 32-atom interface single point (Ag–Ti gap 2.3 Å; PW-PBE, 500 eV, 1×4×2) is still running. At iteration 35, the reported energy is −207.467262 eV/cell; the density-change indicator is about 10^-2.27 and the eigenstate indicator about 10^-4.04. It has not met the requested 1e-5 SCF thresholds, so no final force or stress result is available yet.
- The process has not reported an error. Its current rate is about 34 seconds per SCF iteration. The other two gap structures have not started.
- The independent bulk Ag EOS result is available: PBE a0=4.15200 Å, B=90.13 GPa; the present coherent film requires +4.83%/+4.87% lateral strain. This EOS uses a finite five-point volume grid and has not been cutoff/k-point convergence checked.

### d=2.3 Å interface single point recovered; d=2.6 Å launched — 2026-10-01 23:04 UTC

- The d=2.3 Å PW-PBE single point converged in 76 SCF steps at the specified 1e-5 thresholds. Total energy is −207.463968 eV/cell; free energy is −207.660618 eV/cell. Forces and stress are present in the extxyz. Maximum force is 3.2453 eV/Å on interfacial Ti atom 22, with a minimum Ag–Ti separation of 2.3000 Å; this indicates strong short-range repulsion at this sampled gap. The missing aggregate summary was reconstructed from the extxyz and original GPAW log at `periodic_interface_v4/pbe_singlepoints_500eV/summary_recovered_from_extxyz.json`.
- This is usable as one converged PBE reference configuration for later fitting or comparison, but not as validation of the cross potential by itself. It is an unrelaxed 32-atom cell with about 4.8% in-plane Ag strain, model-derived substrate motif, and only Ti-terminated contacts.
- A separate d=2.6 Å single point has started in `periodic_interface_v4/pbe_singlepoint_d2.6_500eV_run2/`, using the same 500 eV PW-PBE, 1×4×2 k-grid, 0.1 eV smearing, and 1e-5 SCF thresholds. At 23:04 UTC it was initializing the LCAO-to-plane-wave calculation; no d=2.6 result is available yet.
- No candidate or production potential was changed, no fitting or MD has been run.

### d=2.6 Å interface SCF progress — 2026-10-01 23:14 UTC

- The separate d=2.6 Å PW-PBE calculation is active and has reached SCF iteration 17. The latest reported energy is −231.640514 eV/cell; the density-change indicator is about 10^-1.11, so it is not near the 1e-5 convergence threshold yet. No final energy/force result is available.
- A serial launcher is waiting for the d=2.6 run to finish. It will start the d=2.9 calculation only if d=2.6 produces a summary marked SCF-converged; otherwise it will stop and record the reason.

### Clarification on v4 two-interface gap geometry — 2026-10-01 23:25 UTC

- The v4 builder fixes the sum of the two interface gaps at 5.2 Å. Thus the nominal d=2.3 cell has gaps (2.3, 2.9) Å, d=2.6 has (2.6, 2.6) Å, and d=2.9 has (2.9, 2.3) Å. d=2.3 and d=2.9 exchange the short and long sides; they are paired two-interface configurations, not three independent single-interface binding-energy points.
- The d=2.3 force data remains useful as a local periodic reference for its actual two-interface geometry. Compare d=2.3/d=2.9 as a side-swap consistency check, and do not interpret the three total energies as a single-interface binding-energy curve. Any such curve requires an explicitly defined separated reference and a geometry series with the desired gap held at both equivalent interfaces (or a one-interface slab).
- The single-structure PBE runner now records both top and bottom nominal gaps in its summary for future runs. The already running d=2.6 process was started before that metadata patch; its gap pair is still unambiguous from the builder JSON (2.6, 2.6) Å.

### d=2.6 Å progress — 2026-10-01 23:34 UTC

- SCF iteration 63 completed at −208.718139 eV/cell. The density-change indicator is about 10^-3.74; this remains above the configured 1e-5 threshold, so the run has not converged and no force result is available.
- The d=2.6 GPAW process remains active. The serial launcher has not started d=2.9 because the convergence summary does not exist yet.

### d=2.6 Å converged; d=2.9 Å and alternate terminations queued — 2026-10-01 23:43 UTC

- The d=2.6 Å periodic PW-PBE single point converged at the requested SCF thresholds in 84 iterations. The 32-atom cell energy is −208.7181625 eV (−6.5224426 eV/atom); Fmax is 0.95175 eV/Å on interfacial Ti atom 22, and RMS force is 0.35567 eV/Å. Minimum Ag–Ti distance is 2.6000 Å; minimum Ag–C distance is 4.0925 Å. The stress tensor and per-atom forces are in the result summary/extxyz.
- The d=2.9 Å side-swapped cell has started with the same 500 eV PW-PBE, 1×4×2 k-grid, 0.1 eV smearing, and 1e-5 SCF criteria. At 23:43 UTC it has reached SCF iteration 3 after initialization; it is not converged and has no final force result yet.
- A serial queue is waiting for the d=2.9 calculation to finish, then it will run the thin Si-terminated and C-terminated contact cells sequentially if each preceding job converges. These are additional screening structures with direct Ag–Si or Ag–C contact, not production candidates.
- No MACE fit or MD has started. The production candidate and calibration-v0 potential remain unchanged. The new results remain small-cell, unrelaxed PBE force labels; they are inputs to a later grouped train/held-out evaluation, not yet proof that a replacement potential is accurate.

### Serial data expansion and MACE evaluation queued — 2026-10-01 23:58 UTC

- The d=2.9 Å Ti-terminated PW-PBE calculation is still active. It has reached SCF iteration 32; the latest energy is −208.852088 eV/cell and the density-change indicator is about 10^-2.40. These are progress values only; the calculation is not converged yet.
- The serial workflow is now chained with explicit convergence gates: finish the d=2.9 Ti check; run Si- and C-terminated 2.6 Å PBE checks; scan Si/C at 2.3 and 2.9 Å; then fill in 2.4 and 2.8 Å points. A failed stage writes STOP and prevents later stages from launching.
- The additional Si/C gap structures were generated in independent folders. Their periodic-image-aware shortest Ag–Si/Ag–C contacts match the requested distances (2.3, 2.4, 2.8, and 2.9 Å); the underlying substrate motif remains fixed for this screening series.
- Once all labels converge, the queued MACE v5 dataset uses only the uniform 500 eV PW-PBE label set. The training split contains Ti contacts plus Si/C at 2.4, 2.6, and 2.8 Å; 2.3 Å Si/C is validation, and 2.9 Å Si/C is held out for test. An additional PBE/LCAO cluster-transfer check is reported separately and is not mixed into training.
- The MACE job is queued on CPU after the DFT gates. It applies explicit preliminary force, contact-force, energy, and force-sign thresholds; a failed check stops before any LAMMPS or MD stage. The production candidate and calibration-v0 files remain untouched.

### d=2.9 Å SCF progress — 2026-10-02 00:12 UTC

- The d=2.9 Å PW-PBE job is still the active calculation, at SCF iteration 72. The latest energy is −208.850467 eV/cell and the density-change indicator is about 10^-4.11. It has not reached the configured 1e-5 density threshold, so there is not yet a final energy/force summary.
- The Si/C and MACE queues are still waiting on this Ti scan; no later DFT job or MACE fit has started. The DFT runner stops the serial chain if SCF does not converge. Available workspace disk is about 21 GiB, so storage is not currently blocking the queued screening calculations.

### d=2.9 Å converged; Si contact checks started — 2026-10-02 00:16 UTC

- The Ti-terminated d=2.9 Å PW-PBE single point converged in 83 SCF iterations. Energy is −208.8504151 eV/cell; Fmax is 0.64702 eV/Å on C atom 19; RMS force is 0.23764 eV/Å. The actual paired interface gaps are top 2.9 Å and bottom 2.3 Å. Minimum Ag–Ti distance is 2.8930 Å and Ag–C is 3.8241 Å. Total recorded GPAW time is 2142.8 s (about 35.7 min).
- The serial queue passed the d=2.9 convergence gate and launched the 20-atom Si-terminated 2.6 Å PW-PBE single point. At 08:16 Shanghai time it was initializing/starting SCF; no Si result is available yet. C-terminated and additional gap scans have not started.
- The MACE training job remains queued after all planned DFT labels. No MACE model has yet been fit on these periodic labels, and no MD has run.

### Si/C distance scans; C 2.4 Å active — 2026-10-02 01:13 UTC

- Eleven of the 13 planned periodic interface PBE structures have converged: all three Ti paired-gap structures; Si at 2.3, 2.4, 2.6, 2.8, and 2.9 Å; and C at 2.3, 2.6, and 2.9 Å. The Si/C end-point scans completed without SCF errors.
- The C-terminated 2.4 Å calculation is active at SCF iteration 5 (about 1.5 minutes elapsed). The remaining C 2.8 Å point will run next if this calculation converges.
- Preliminary maxima across the converged Si scan are 0.715–1.539 eV/Å; across the converged C scan they are 2.448–2.571 eV/Å. These are unrelaxed fixed-geometry single-point forces, not stability verdicts.
- MACE training has not begun. It remains queued until the final C 2.8 Å label converges and dataset assembly verifies every method and file.

### C 2.4 Å SCF update — 2026-10-02 01:18 UTC

- The C-terminated 2.4 Å PW-PBE calculation reached SCF iteration 31. Energy has stabilized near −118.4755 eV/cell, while the density-change indicator is about 10^-3.92, still above the required 1e-5 criterion. The process is active and has not produced a summary yet.
- The Si 2.4 and 2.8 Å intermediate points both converged (Fmax 0.715 and 0.843 eV/Å). The remaining C 2.8 Å point is queued behind C 2.4 Å. Shell/Python pipeline files passed syntax compilation; the MACE job remains gated on all labels.

### C 2.4 Å converged; final DFT point started — 2026-10-02 01:19 UTC

- The C-terminated 2.4 Å PW-PBE point converged in 44 SCF iterations at −118.4754893 eV/cell. Its Fmax is 2.58182 eV/Å on Ti atom 12. This is a fixed-geometry interface force and will be included in later DFT-vs-MACE force checks.
- Twelve of 13 planned interface structures now have converged PBE labels. The final C-terminated 2.8 Å point has started; its log is initializing. The MACE queue remains gated on that run and subsequent dataset assembly.
