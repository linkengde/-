from pathlib import Path
import csv

import numpy as np
from ase.io import read, write
from mace.calculators import mace_mp


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "candidate_pair_scan_mace"
if OUT.exists():
    raise SystemExit(f"Refusing to reuse existing output directory: {OUT}")
OUT.mkdir()
MODEL = Path("/workspace/.local/cache/mace/mace-mp-0b3-medium.model")
SOURCE = ROOT / "composition_candidate_c_pair_R6.extxyz"
ID_A, ID_B = 520183, 520177
calculator = mace_mp(model=str(MODEL), device="cpu", default_dtype="float64")
rows = []

for target in (2.0, 1.8, 1.5):
    name = f"pair_d{target:.1f}".replace(".", "p")
    atoms = read(SOURCE)
    ids = atoms.arrays["lammps_id"].astype(int)
    ia, ib = (int(np.flatnonzero(ids == atom_id)[0]) for atom_id in (ID_A, ID_B))
    vector = atoms.positions[ib] - atoms.positions[ia]
    distance = float(np.linalg.norm(vector))
    unit = vector / distance
    half_shift = 0.5 * (distance - target) * unit
    atoms.positions[ia] += half_shift
    atoms.positions[ib] -= half_shift
    write(OUT / f"{name}.extxyz", atoms, format="extxyz")
    atoms.calc = calculator
    energy = float(atoms.get_potential_energy())
    forces = atoms.get_forces()
    norms = np.linalg.norm(forces, axis=1)
    separating = float(np.dot(forces[ib] - forces[ia], unit))
    rows.append(
        {
            "frame": name,
            "atoms": len(atoms),
            "MACE_energy_eV": energy,
            "C_pair_distance_A": float(np.linalg.norm(atoms.positions[ib] - atoms.positions[ia])),
            "C_pair_separating_force_eV_per_A": separating,
            "max_force_norm_eV_per_A": float(norms.max()),
        }
    )
    with (OUT / f"{name}_forces.csv").open("x", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["lammps_id", "symbol", "fx_eV_A", "fy_eV_A", "fz_eV_A", "force_norm_eV_A"])
        for atom_id, atom, force, norm in zip(ids, atoms, forces, norms):
            writer.writerow([int(atom_id), atom.symbol, *map(float, force), float(norm)])
    print(rows[-1], flush=True)

with (OUT / "mace_summary.csv").open("x", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=rows[0].keys())
    writer.writeheader()
    writer.writerows(rows)
