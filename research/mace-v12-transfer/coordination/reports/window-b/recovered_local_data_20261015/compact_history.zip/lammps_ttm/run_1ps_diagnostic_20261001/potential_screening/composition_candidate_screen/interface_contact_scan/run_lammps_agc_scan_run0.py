#!/usr/bin/env python3
"""Run calibration-v0 and zero-cross static forces on completed Ag-C PBE scans."""
from pathlib import Path
import json
import subprocess

import numpy as np
from ase.io import read

ROOT = Path(__file__).resolve().parent
SCAN = ROOT / "AgC_environment_distance_scans_PBE_v1"
OUT = ROOT / "AgC_environment_distance_scans_LAMMPS_v0_v2"
BASE = Path("/workspace/.local/lammps-ttm/composition_locked_candidate_20260930")
LMP = Path("/workspace/.local/lammps-ttm/bin/lmp_mpi")
SPECS = {
    "primary": (732149, 197404),
    "secondary": (688433, 604804),
}
MORSE = {
    (1, 4): (0.94814194, 2.0, 2.33708864),
    (2, 4): (0.93944948, 2.0, 2.40407837),
    (3, 4): (1.35077230, 2.0, 2.15255924),
}
MASS = {1: 47.8670000, 2: 28.0855000, 3: 12.0107000, 4: 107.8682000}
OUT.mkdir(exist_ok=True)
all_results = []

for env, (ag_id, c_id) in SPECS.items():
    for distance in (2.0, 2.4):
        tag = f"d{distance:.1f}"
        input_xyz = SCAN / env / tag / "input.extxyz"
        pbe_summary = SCAN / env / tag / "summary.json"
        if not input_xyz.exists() or not pbe_summary.exists():
            continue
        target = OUT / env / tag
        target.mkdir(parents=True, exist_ok=False)
        atoms = read(input_xyz)
        types = np.asarray(atoms.arrays["lammps_type"], dtype=int)
        ids = np.asarray(atoms.arrays["lammps_id"], dtype=int)
        ia = int(np.flatnonzero(ids == ag_id)[0])
        ic = int(np.flatnonzero(ids == c_id)[0])
        u = atoms.positions[ia] - atoms.positions[ic]
        u /= np.linalg.norm(u)
        data = target / "cluster.data"
        with data.open("w") as f:
            f.write("PBE Ag-C scan cluster\n\n")
            f.write(f"{len(atoms)} atoms\n4 atom types\n\n")
            f.write("0 28 xlo xhi\n0 28 ylo yhi\n0 28 zlo zhi\n\nMasses\n\n")
            for typ, mass in MASS.items():
                f.write(f"{typ} {mass}\n")
            f.write("\nAtoms # atomic\n\n")
            for i, (typ, pos) in enumerate(zip(types, atoms.positions), 1):
                f.write(f"{i} {int(typ)} {pos[0]:.12f} {pos[1]:.12f} {pos[2]:.12f}\n")

        result = {"environment": env, "target_distance_A": distance, "PBE": json.loads(pbe_summary.read_text())}
        forces_by_variant = {}
        for variant, scale in (("calibration_v0", 1.0), ("cross_terms_zero", 0.0)):
            d = target / variant
            d.mkdir()
            dump = d / "forces.dump"
            lines = ["units metal", "atom_style atomic", "boundary f f f", f"read_data {data}",
                     "pair_style hybrid eam tersoff morse 8.0",
                     f"pair_coeff 4 4 eam {BASE}/potentials/Ag_u3.eam",
                     f"pair_coeff * * tersoff {BASE}/potentials/TSCBOP.tersoff Ti Si C NULL"]
            for (i, j), (d0, alpha, r0) in MORSE.items():
                lines.append(f"pair_coeff {i} {j} morse {d0 * scale:.12g} {alpha:.12g} {r0:.12g} 8.0")
            lines += ["neighbor 2.0 bin", "neigh_modify every 1 delay 0 check yes",
                      "variable fnorm atom sqrt(fx*fx+fy*fy+fz*fz)", "compute fmax all reduce max v_fnorm",
                      "thermo 1", "thermo_style custom step atoms pe c_fmax", "thermo_modify flush yes lost error",
                      f"dump f all custom 1 {dump} id type x y z fx fy fz", "dump_modify f sort id", "run 0", ""]
            inp = d / "in.run0"
            inp.write_text("\n".join(lines))
            log = d / "log.lammps"
            with (d / "run.stdout").open("w") as stdout:
                subprocess.run([str(LMP), "-in", str(inp), "-log", str(log)], cwd=d, check=True,
                               stdout=stdout, stderr=subprocess.STDOUT)
            rows = np.loadtxt(dump, comments="#", skiprows=9)
            forces = rows[:, 5:8]
            values = [line.split() for line in log.read_text().splitlines()
                      if line.strip().startswith("0 ") and len(line.split()) == 4]
            result[variant] = {"PE_eV": float(values[-1][2]),
                               "pair_separating_force_eV_A": float(np.dot(forces[ia] - forces[ic], u)),
                               "Fmax_eV_A": float(np.linalg.norm(forces, axis=1).max())}
            forces_by_variant[variant] = forces
        delta = forces_by_variant["calibration_v0"] - forces_by_variant["cross_terms_zero"]
        result["all_cross_Morse_pair_projection_eV_A"] = float(np.dot(delta[ia] - delta[ic], u))
        (target / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
        all_results.append(result)
        print(json.dumps({k: v for k, v in result.items() if k != "PBE"} | {"PBE_force": result["PBE"]["Ag_C_separating_force_eV_A"]}), flush=True)

(OUT / "summary.json").write_text(json.dumps(all_results, indent=2) + "\n")
