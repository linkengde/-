from pathlib import Path
import csv
import json

import numpy as np
from ase.io import read
from mace.calculators import mace_mp


ROOT = Path(__file__).resolve().parent
SCAN = ROOT / "interface_contact_scan" / "AgC_secondary"
OUT = SCAN / "mace"
MODEL = Path("/workspace/.local/cache/mace/mace-mp-0b3-medium.model")
if OUT.exists():
    raise SystemExit(f"Refusing to reuse existing output directory: {OUT}")
OUT.mkdir()
atoms = read(SCAN / "candidate_Ag_C_R6.extxyz")
ids = atoms.arrays["lammps_id"].astype(int)
pair = atoms.arrays["central_pair"].astype(bool)
symbols = atoms.get_chemical_symbols()
ag_i = int(np.flatnonzero(pair & (np.asarray(symbols) == "Ag"))[0])
c_i = int(np.flatnonzero(pair & (np.asarray(symbols) == "C"))[0])
vector = atoms.positions[c_i] - atoms.positions[ag_i]
distance = float(np.linalg.norm(vector))
calc = mace_mp(model=str(MODEL), device="cpu", default_dtype="float64")
atoms.calc = calc
energy = float(atoms.get_potential_energy())
forces = atoms.get_forces()
norms = np.linalg.norm(forces, axis=1)
summary = {
    "atoms": len(atoms), "Ag_id": int(ids[ag_i]), "C_id": int(ids[c_i]),
    "distance_A": distance, "MACE_energy_eV": energy,
    "MACE_pair_separating_force_eV_per_A": float(np.dot(forces[c_i] - forces[ag_i], vector / distance)),
    "max_force_norm_eV_per_A": float(norms.max()),
    "max_force_id": int(ids[int(norms.argmax())]),
}
with (OUT / "forces.csv").open("x", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["lammps_id", "symbol", "fx_eV_A", "fy_eV_A", "fz_eV_A", "force_norm_eV_A"])
    for atom_id, atom, force, norm in zip(ids, atoms, forces, norms):
        writer.writerow([int(atom_id), atom.symbol, *map(float, force), float(norm)])
(OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
