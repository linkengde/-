from pathlib import Path
import csv
import json
import os

import numpy as np
import gpaw_data
from ase.io import read


ROOT = Path(__file__).resolve().parent
SCAN = ROOT / "interface_contact_scan" / "AgC_secondary"
OUT = SCAN / "pbe"
SETUP = Path(gpaw_data.datapath())
os.environ["GPAW_SETUP_PATH"] = str(SETUP)

from gpaw import GPAW
from gpaw.mixer import Mixer
from gpaw.occupations import FermiDirac

if OUT.exists():
    raise SystemExit(f"Refusing to reuse existing output directory: {OUT}")
OUT.mkdir()
atoms = read(SCAN / "candidate_Ag_C_R6.extxyz")
ids = atoms.arrays["lammps_id"].astype(int)
pair = atoms.arrays["central_pair"].astype(bool)
symbols = atoms.get_chemical_symbols()
ag_i = int(np.flatnonzero(pair & (np.asarray(symbols) == "Ag"))[0])
c_i = int(np.flatnonzero(pair & (np.asarray(symbols) == "C"))[0])
vector = atoms.positions[c_i] - atoms.positions[ag_i]
distance = float(np.linalg.norm(vector))
atoms.calc = GPAW(
    mode="lcao",
    basis="dzp",
    xc="PBE",
    occupations=FermiDirac(0.1),
    mixer=Mixer(beta=0.05, nmaxold=8, weight=100.0),
    convergence={"energy": 1e-4, "density": 1e-4, "eigenstates": 1e-4},
    maxiter=120,
    txt=str(OUT / "gpaw.log"),
)
energy = float(atoms.get_potential_energy())
forces = atoms.get_forces()
norms = np.linalg.norm(forces, axis=1)
summary = {
    "atoms": len(atoms), "Ag_id": int(ids[ag_i]), "C_id": int(ids[c_i]),
    "distance_A": distance, "PBE_energy_eV": energy,
    "PBE_pair_separating_force_eV_per_A": float(np.dot(forces[c_i] - forces[ag_i], vector / distance)),
    "Ag_force_norm_eV_per_A": float(norms[ag_i]),
    "C_force_norm_eV_per_A": float(norms[c_i]),
    "max_force_norm_eV_per_A": float(norms.max()),
    "max_force_id": int(ids[int(norms.argmax())]),
}
with (OUT / "forces.csv").open("x", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["lammps_id", "symbol", "fx_eV_A", "fy_eV_A", "fz_eV_A", "force_norm_eV_per_A"])
    for atom_id, atom, force, norm in zip(ids, atoms, forces, norms):
        writer.writerow([int(atom_id), atom.symbol, *map(float, force), float(norm)])
atoms.calc.write(str(OUT / "state.gpw"), mode="all")
(OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2), flush=True)
