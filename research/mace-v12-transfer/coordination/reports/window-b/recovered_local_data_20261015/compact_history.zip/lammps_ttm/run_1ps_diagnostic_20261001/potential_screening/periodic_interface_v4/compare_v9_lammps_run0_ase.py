#!/usr/bin/env python3
"""Compare v9 LAMMPS serial run-0 energies/forces to ASE on the same cell."""
import json
import re
from pathlib import Path

import numpy as np
import torch
from ase.io import read
from mace.calculators import MACECalculator

ROOT = Path(__file__).resolve().parent
OUT = Path.cwd()
STRUCTURE = Path.cwd() / 'cluster_periodic.extxyz'
MODEL = ROOT / 'mace_periodic_v9_forceonly/models/Ag_Ti_Si_C_MACE_periodic_v9_forceonly.model'
atoms = read(STRUCTURE)
atoms.pbc = True
torch.set_default_dtype(torch.float64)
model = torch.load(MODEL, map_location='cpu', weights_only=False).double().eval()
atoms.calc = MACECalculator(models=[model], device='cpu', default_dtype='float64')
ase_e = float(atoms.get_potential_energy())
ase_f = np.asarray(atoms.get_forces())
lines = (OUT / 'forces.run0.dump').read_text().splitlines()
start = next(i for i, line in enumerate(lines) if line.startswith('ITEM: ATOMS'))
columns = lines[start].split()[2:]
force_cols = [columns.index(key) for key in ('fx', 'fy', 'fz')]
lmp_f = np.zeros_like(ase_f)
rows = lines[start + 1:start + 1 + len(atoms)]
if len(rows) != len(atoms):
    raise RuntimeError('LAMMPS force dump does not contain exactly 49 atoms')
for line in rows:
    v = line.split()
    lmp_f[int(v[0]) - 1] = [float(v[j]) for j in force_cols]
log = (OUT / 'log.run0').read_text().splitlines()
header_i = next(i for i, line in enumerate(log)
                if line.split()[:2] == ['Step', 'Atoms'] and 'PotEng' in line)
header = log[header_i].split()
row = next(line.split() for line in log[header_i + 1:]
           if len(line.split()) == len(header) and line.split()[0].isdigit())
lmp_e = float(row[header.index('PotEng')])
delta = lmp_f - ase_f
screen = (OUT / 'screen.run0').read_text(errors='replace')
stdout = (OUT / 'stdout.run0').read_text(errors='replace')
result = {
    'atoms': len(atoms), 'step': 0,
    'lammps_PE_eV': lmp_e, 'ase_PE_eV': ase_e,
    'energy_abs_error_eV': abs(lmp_e - ase_e),
    'force_component_max_abs_error_eV_A': float(np.abs(delta).max()),
    'force_component_RMSE_eV_A': float(np.sqrt(np.mean(delta ** 2))),
    'force_vector_max_abs_error_eV_A': float(np.linalg.norm(delta, axis=1).max()),
    'force_vector_RMSE_eV_A': float(np.sqrt(np.mean(np.sum(delta ** 2, axis=1)))),
    'lammps_ghost_map_marker': bool(re.search(r'MACE_PERIODIC_SERIAL_GHOST_MAP[^\n]*nghost=[1-9]', screen + stdout)),
}
(OUT / 'run0_parity.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
