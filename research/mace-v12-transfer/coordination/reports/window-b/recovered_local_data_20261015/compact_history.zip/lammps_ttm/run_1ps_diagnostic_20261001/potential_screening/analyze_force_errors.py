from pathlib import Path
import csv
import json

import numpy as np


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "force_error_analysis.json"
if OUT.exists():
    raise SystemExit(f"Refusing to overwrite existing file: {OUT}")

def read_forces(path):
    rows = {}
    with path.open() as f:
        for row in csv.DictReader(f):
            atom_id = int(row["lammps_id"])
            rows[atom_id] = {
                "symbol": row["symbol"],
                "force": np.array([float(row[f"f{x}_eV_A"]) for x in "xyz"]),
            }
    return rows

def pair_separating_force(rows):
    reference = read_forces(ROOT / "mace_forces_step0.csv")
    xyz = {}
    with (ROOT / "c_pair_step0_R6.extxyz").open() as f:
        lines = f.readlines()[2:]
    for line in lines:
        fields = line.split()
        xyz[int(fields[4])] = np.array([float(v) for v in fields[1:4]])
    ia, ib = 520183, 520177
    unit = (xyz[ib] - xyz[ia]) / np.linalg.norm(xyz[ib] - xyz[ia])
    return float(np.dot(rows[ib]["force"] - rows[ia]["force"], unit))

cases = {
    "step0": {
        "pbe": ROOT / "gpaw_step0_R6" / "forces.csv",
        "mace": ROOT / "mace_forces_step0.csv",
        "chgnet": ROOT / "chgnet_forces_step0.csv",
    },
    "step1000": {
        "pbe": ROOT / "gpaw_step1000_R6_restart" / "forces.csv",
        "mace": ROOT / "mace_forces_step1000.csv",
        "chgnet": ROOT / "chgnet_forces_step1000.csv",
    },
}

results = []
element_results = []
for frame, paths in cases.items():
    references = read_forces(paths["pbe"])
    for model, path in paths.items():
        if model == "pbe":
            continue
        predicted = read_forces(path)
        common_ids = sorted(set(references) & set(predicted))
        if len(common_ids) != 73 or any(
            references[i]["symbol"] != predicted[i]["symbol"] for i in common_ids
        ):
            raise SystemExit(f"Atom identity mismatch in {frame} {model}")
        delta = np.array([predicted[i]["force"] - references[i]["force"] for i in common_ids])
        vectors = np.array([predicted[i]["force"] for i in common_ids])
        target_vectors = np.array([references[i]["force"] for i in common_ids])
        result = {
            "frame": frame,
            "model": model,
            "atoms": len(common_ids),
            "force_component_rmse_eV_per_A": float(np.sqrt(np.mean(delta**2))),
            "force_vector_rmse_eV_per_A": float(np.sqrt(np.mean(np.sum(delta**2, axis=1)))),
            "force_vector_mae_eV_per_A": float(np.mean(np.linalg.norm(delta, axis=1))),
            "force_vector_max_error_eV_per_A": float(np.linalg.norm(delta, axis=1).max()),
            "relative_force_norm_rmse": float(
                np.sqrt(np.mean(np.sum(delta**2, axis=1)))
                / np.sqrt(np.mean(np.sum(target_vectors**2, axis=1)))
            ),
        }
        if frame == "step0":
            result["pair_separating_force_eV_per_A"] = pair_separating_force(predicted)
        results.append(result)
        for symbol in ("Ag", "C", "Si", "Ti"):
            indices = [j for j, atom_id in enumerate(common_ids) if predicted[atom_id]["symbol"] == symbol]
            if not indices:
                continue
            symbol_delta = delta[indices]
            element_results.append(
                {
                    "frame": frame,
                    "model": model,
                    "element": symbol,
                    "atoms": len(indices),
                    "force_vector_rmse_eV_per_A": float(
                        np.sqrt(np.mean(np.sum(symbol_delta**2, axis=1)))
                    ),
                }
            )

OUT.write_text(json.dumps({"all_atom_summary": results, "by_element": element_results}, indent=2) + "\n")
print(json.dumps({"all_atom_summary": results, "by_element": element_results}, indent=2))
