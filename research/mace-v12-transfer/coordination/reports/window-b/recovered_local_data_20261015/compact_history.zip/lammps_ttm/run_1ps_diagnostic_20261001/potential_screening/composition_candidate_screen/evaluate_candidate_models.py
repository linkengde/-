from pathlib import Path
import csv

import numpy as np
from ase.io import read
from mace.calculators import mace_mp
from chgnet.model.dynamics import CHGNetCalculator
from chgnet.model import CHGNet


ROOT = Path(__file__).resolve().parent
MODEL = Path("/workspace/.local/cache/mace/mace-mp-0b3-medium.model")
ID_A, ID_B = 520183, 520177
if (ROOT / "model_summary.csv").exists():
    raise SystemExit("Refusing to overwrite model_summary.csv")

mace_calc = mace_mp(model=str(MODEL), device="cpu", default_dtype="float64")
chgnet_calc = CHGNetCalculator(model=CHGNet.load(), use_device="cpu")
summary = []

for radius in (6, 7):
    atoms = read(ROOT / f"composition_candidate_c_pair_R{radius}.extxyz")
    ids = atoms.arrays["lammps_id"].astype(int)
    ia, ib = (int(np.flatnonzero(ids == atom_id)[0]) for atom_id in (ID_A, ID_B))
    vector = atoms.positions[ib] - atoms.positions[ia]
    distance = float(np.linalg.norm(vector))
    unit = vector / distance

    for name, calculator in (("MACE", mace_calc), ("CHGNet", chgnet_calc)):
        atoms.calc = calculator
        energy = float(atoms.get_potential_energy())
        forces = atoms.get_forces()
        norms = np.linalg.norm(forces, axis=1)
        separating = float(np.dot(forces[ib] - forces[ia], unit))
        summary.append(
            {
                "model": name,
                "radius_A": radius,
                "atoms": len(atoms),
                "Ti": int(np.count_nonzero(atoms.symbols == "Ti")),
                "Si": int(np.count_nonzero(atoms.symbols == "Si")),
                "C": int(np.count_nonzero(atoms.symbols == "C")),
                "Ag": int(np.count_nonzero(atoms.symbols == "Ag")),
                "energy_eV": energy,
                "C_pair_distance_A": distance,
                "C_pair_separating_force_eV_per_A": separating,
                "C520183_force_norm_eV_per_A": float(norms[ia]),
                "C520177_force_norm_eV_per_A": float(norms[ib]),
                "max_force_norm_eV_per_A": float(norms.max()),
                "max_force_lammps_id": int(ids[int(norms.argmax())]),
            }
        )
        path = ROOT / f"{name.lower()}_forces_R{radius}.csv"
        with path.open("x", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["lammps_id", "symbol", "x_A", "y_A", "z_A", "fx_eV_A", "fy_eV_A", "fz_eV_A", "force_norm_eV_A"])
            for atom_id, atom, pos, force, norm in zip(ids, atoms, atoms.positions, forces, norms):
                writer.writerow([int(atom_id), atom.symbol, *map(float, pos), *map(float, force), float(norm)])
        print(summary[-1], flush=True)

with (ROOT / "model_summary.csv").open("x", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=summary[0].keys())
    writer.writeheader()
    writer.writerows(summary)
