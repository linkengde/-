from pathlib import Path
import json

import numpy as np
from ase import Atoms
from ase.io import write


CANDIDATE = Path(
    "/workspace/.local/lammps-ttm/composition_locked_candidate_20260930/"
    "stage65_model_fcc_ag_59p8775wt_candidate.data"
)
OUT = Path(__file__).resolve().parent / "composition_candidate_screen"
PAIR_IDS = (520183, 520177)
BOX = np.array([150.1, 300.0, 300.0])
CELL = np.eye(3) * 28.0
CELL_CENTER = np.full(3, 14.0)
SYMBOL = {1: "Ti", 2: "Si", 3: "C", 4: "Ag"}


def read_atoms(path):
    ids, types, coords = [], [], []
    in_atoms = False
    with path.open() as stream:
        for line in stream:
            stripped = line.strip()
            if stripped.startswith("Atoms"):
                in_atoms = True
                continue
            if not in_atoms:
                continue
            fields = stripped.split()
            if len(fields) == 5 and fields[0].isdigit():
                ids.append(int(fields[0]))
                types.append(int(fields[1]))
                coords.append([float(value) for value in fields[2:5]])
            elif stripped and not stripped.startswith("#"):
                if ids:
                    break
    return np.asarray(ids, dtype=np.int64), np.asarray(types, dtype=np.int64), np.asarray(coords)


if OUT.exists():
    raise SystemExit(f"Refusing to reuse existing output directory: {OUT}")
OUT.mkdir()
ids, types, xyz = read_atoms(CANDIDATE)
index = {int(atom_id): i for i, atom_id in enumerate(ids)}
ia, ib = (index[atom_id] for atom_id in PAIR_IDS)
pair_delta = xyz[ib] - xyz[ia]
pair_delta -= BOX * np.rint(pair_delta / BOX)
pair_distance = float(np.linalg.norm(pair_delta))
center = (xyz[ia] + 0.5 * pair_delta) % BOX
relative = xyz - center
relative -= BOX * np.rint(relative / BOX)
distances = np.linalg.norm(relative, axis=1)

nearest_ag = {}
for atom_id in PAIR_IDS:
    i = index[atom_id]
    mask = types == 4
    delta = xyz[mask] - xyz[i]
    delta -= BOX * np.rint(delta / BOX)
    ag_ids = ids[mask]
    ag_distances = np.linalg.norm(delta, axis=1)
    order = np.argsort(ag_distances)[:10]
    nearest_ag[str(atom_id)] = [
        {"id": int(ag_ids[j]), "distance_A": float(ag_distances[j])}
        for j in order
    ]

manifest = {
    "candidate_data": str(CANDIDATE),
    "candidate_atoms_read": int(len(ids)),
    "central_pair_ids": list(PAIR_IDS),
    "central_pair_distance_A": pair_distance,
    "nearest_Ag_by_C_id": nearest_ag,
    "clusters": [],
}

for radius in (6.0, 7.0):
    chosen = distances <= radius
    selected_ids = ids[chosen]
    selected_types = types[chosen]
    selected_xyz = relative[chosen] + CELL_CENTER
    atoms = Atoms(
        [SYMBOL[int(t)] for t in selected_types],
        positions=selected_xyz,
        cell=CELL,
        pbc=False,
    )
    atoms.new_array("lammps_id", selected_ids)
    atoms.new_array("lammps_type", selected_types)
    atoms.new_array("central_pair", np.isin(selected_ids, PAIR_IDS).astype(np.int32))
    out = OUT / f"composition_candidate_c_pair_R{int(radius)}.extxyz"
    write(out, atoms, format="extxyz")
    counts = {SYMBOL[int(t)]: int(np.count_nonzero(selected_types == t)) for t in np.unique(selected_types)}
    manifest["clusters"].append(
        {"radius_A": radius, "atoms": len(atoms), "element_counts": counts, "file": out.name}
    )

manifest_path = OUT / "cluster_manifest.json"
manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps(manifest, indent=2))
