#!/usr/bin/env python3
from pathlib import Path
import json,os
import numpy as np
import gpaw_data
from ase.io import read,write
from ase.optimize import BFGS
os.environ['GPAW_SETUP_PATH']=str(gpaw_data.datapath())
from gpaw import GPAW
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'bulk_pbe_relaxed_1x2x1';OUT.mkdir(exist_ok=False)
a=read(ROOT/'mace_seed_pbe_1x2x1/Ti3SiC2_pbe_screened.extxyz')
a.calc=GPAW(str(ROOT/'mace_seed_pbe_1x2x1/state.gpw'),txt=str(OUT/'gpaw_relax.log'))
opt=BFGS(a,trajectory=str(OUT/'relax.traj'),logfile=str(OUT/'opt.log'),maxstep=.08)
conv=opt.run(fmax=.05,steps=80)
f=np.asarray(a.get_forces());e=float(a.get_potential_energy());n=np.linalg.norm(f,axis=1)
np.savetxt(OUT/'forces.csv',np.column_stack((np.arange(1,len(a)+1),f)),delimiter=',',header='atom_index,fx_eV_A,fy_eV_A,fz_eV_A',comments='')
write(OUT/'Ti3SiC2_PBE_relaxed_1x2x1.extxyz',a,format='extxyz');a.calc.write(OUT/'state.gpw')
r={'optimizer_converged':bool(conv),'atoms':len(a),'cell_A':a.cell.array.tolist(),'kpts':[1,2,1],'scf_thresholds':'1e-3','energy_eV':e,'energy_eV_atom':e/len(a),'max_force_eV_A':float(n.max()),'max_force_atom_index':int(n.argmax()+1),'max_force_element':a[int(n.argmax())].symbol,'force_RMS_eV_A':float(np.sqrt(np.mean(f*f))),'steps':max(0,sum(1 for _ in open(OUT/'opt.log'))-1),'note':'PBE fixed-cell atomic-position relaxation. Requires a final stricter/higher-k-point single point before use as DFT training reference.'}
(OUT/'summary.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
