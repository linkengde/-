#!/usr/bin/env python3
"""Rebuild Ag on a commensurate FCC lattice inside the uploaded Ag voxel mask.
All Ti/Si/C IDs and coordinates are copied exactly. The original model is read-only.
"""
import hashlib
import itertools
import json
from pathlib import Path
import shutil
import numpy as np
from scipy.spatial import cKDTree

SRC = Path('/workspace/.local/lammps-ttm/run-upload-20260930/stage65_model_150x300x300.data')
SRC_DIR = SRC.parent
OUT = Path(__file__).resolve().parent
BOX = np.array([150.1, 300.0, 300.0])
MIN_AG_SKELETON_A = 1.50

rows = []
inside = False
with SRC.open() as f:
    for line in f:
        if line.startswith('Atoms #'):
            inside = True
            continue
        if inside:
            fields = line.split()
            if len(fields) < 5:
                continue
            try:
                rows.append((int(fields[0]), int(fields[1]), float(fields[2]), float(fields[3]), float(fields[4])))
            except ValueError:
                break
A = np.asarray(rows, dtype=np.float64)
ids = A[:, 0].astype(np.int64)
types = A[:, 1].astype(np.int64)
xyz = A[:, 2:5]
sc_mask = types != 4
skeleton = xyz[sc_mask]
ag_old = xyz[types == 4]
sc_type = types[sc_mask]
assert len(A) == 682587 and len(ag_old) == 212904

# The old Ag coordinates are points on a 2 A grid. Use their occupied voxels
# as a coarse mask for the same macroscopic fill envelope.
mask = np.zeros((75, 150, 150), dtype=bool)
ix = np.rint((ag_old[:, 0] - 0.4) / 2.0).astype(int)
iy = np.rint((ag_old[:, 1] - 0.8) / 2.0).astype(int) % 150
iz = np.rint((ag_old[:, 2] - 0.4) / 2.0).astype(int) % 150
valid = (ix >= 0) & (ix < mask.shape[0])
mask[ix[valid], iy[valid], iz[valid]] = True

# Fit the FCC conventional lattice to integer repeats across the periodic box.
# This is a 0.8% compression from the file's 4.090 A unstrained Ag value.
lat = np.array([BOX[0] / 37.0, BOX[1] / 74.0, BOX[2] / 74.0])
I, J, K = np.indices((37, 74, 74))
base = np.stack((I.ravel() * lat[0], J.ravel() * lat[1], K.ravel() * lat[2]), axis=1)
basis = np.array([[0, 0, 0], [0, 0.5, 0.5], [0.5, 0, 0.5], [0.5, 0.5, 0]])
tree = cKDTree(skeleton, boxsize=BOX)
best = None
phase_results = []
for phase in itertools.product((0.0, 0.25, 0.5, 0.75), repeat=3):
    points = (base[:, None, :] + lat * (np.asarray(phase)[None, None, :] + basis[None, :, :])).reshape(-1, 3) % BOX
    gx = np.rint((points[:, 0] - 0.4) / 2.0).astype(int)
    gy = np.rint((points[:, 1] - 0.8) / 2.0).astype(int) % 150
    gz = np.rint((points[:, 2] - 0.4) / 2.0).astype(int) % 150
    in_x = (gx >= 0) & (gx < mask.shape[0])
    in_mask = np.zeros(len(points), dtype=bool)
    in_mask[in_x] = mask[gx[in_x], gy[in_x], gz[in_x]]
    raw = points[in_mask]
    distances, _ = tree.query(raw, k=1, workers=-1)
    kept = raw[distances >= MIN_AG_SKELETON_A]
    phase_results.append((len(kept), phase, len(raw), float(distances.min()) if len(distances) else None))
    key = (len(kept), tuple(-v for v in phase))
    if best is None or key > best[0]:
        best = (key, phase, raw, distances, kept)

_, phase, raw, raw_distances, ag_new = best
assert len(ag_new) > 10000
# Hard geometric gates after selection.
dmin_sc, nearest = tree.query(ag_new, k=1, workers=-1)
assert np.all(dmin_sc >= MIN_AG_SKELETON_A - 1e-10)

# Preserve the exact original type-1/2/3 IDs and coordinates; replace Ag only.
sc_rows = A[sc_mask]
new_ids = np.arange(int(ids.max()) + 1, int(ids.max()) + len(ag_new) + 1, dtype=np.int64)
all_ids = np.concatenate((sc_rows[:, 0].astype(np.int64), new_ids))
all_types = np.concatenate((sc_rows[:, 1].astype(np.int64), np.full(len(ag_new), 4, dtype=np.int64)))
all_xyz = np.vstack((sc_rows[:, 2:5], ag_new))
order = np.argsort(all_ids)
all_ids, all_types, all_xyz = all_ids[order], all_types[order], all_xyz[order]
assert len(np.unique(all_ids)) == len(all_ids)

out_data = OUT / 'stage65_model_fcc_ag_candidate.data'
with out_data.open('w') as f:
    f.write('LAMMPS data file: candidate FCC Ag infill; Ti/Si/C coordinates copied verbatim\n\n')
    f.write(f'{len(all_ids)} atoms\n4 atom types\n\n')
    f.write(f'0 {BOX[0]:.10f} xlo xhi\n0 {BOX[1]:.10f} ylo yhi\n0 {BOX[2]:.10f} zlo zhi\n\n')
    f.write('Masses\n\n1 47.867\n2 28.0855\n3 12.0107\n4 107.87\n\n')
    f.write('Atoms # atomic\n\n')
    for atom_id, atom_type, r in zip(all_ids, all_types, all_xyz):
        f.write(f'{atom_id:d} {atom_type:d} {r[0]:.12f} {r[1]:.12f} {r[2]:.12f}\n')

for filename in ('potential.interface_calibration_v0.inc',):
    shutil.copy2(SRC_DIR / filename, OUT / filename)
for filename in ('Ag_u3.eam', 'TSCBOP.tersoff'):
    shutil.copy2(SRC_DIR / 'potentials' / filename, OUT / 'potentials' / filename)

summary = {
    'source': str(SRC),
    'source_sha256': hashlib.sha256(SRC.read_bytes()).hexdigest(),
    'candidate_data': out_data.name,
    'source_atoms': len(A),
    'source_type_counts': {str(t): int((types == t).sum()) for t in (1, 2, 3, 4)},
    'candidate_atoms': len(all_ids),
    'candidate_type_counts': {str(t): int((all_types == t).sum()) for t in (1, 2, 3, 4)},
    'backbone_type123_coordinates_copied_verbatim': True,
    'backbone_atom_count': int(sc_mask.sum()),
    'source_ag_lattice_spacing_A': 2.0,
    'Ag_EAM_reference_lattice_parameter_A': 4.09,
    'candidate_lattice_A': lat.tolist(),
    'candidate_lattice_strain_vs_4p09': (lat / 4.09 - 1).tolist(),
    'Ag_mask_occupied_voxels': int(mask.sum()),
    'Ag_mask_voxel_volume_A3': 8.0,
    'phase_scan': {'grid': [0, 0.25, 0.5, 0.75], 'number_of_phases': len(phase_results), 'selected_phase': list(phase), 'retained_site_count': len(ag_new), 'raw_in_mask_site_count': len(raw), 'retained_min_Ag_to_skeleton_A': float(dmin_sc.min()), 'retained_median_Ag_to_skeleton_A': float(np.median(dmin_sc)), 'minimum_clearance_gate_A': MIN_AG_SKELETON_A},
    'all_phase_retained_counts': [{'count': n, 'phase': list(p), 'raw': raw_n, 'pre_filter_min_distance_A': dmin} for n, p, raw_n, dmin in phase_results],
    'potential_status': 'Inherited calibration v0 Morse cross terms; not validated for production.',
    'scope': 'Static geometric candidate only; no MD steps; no TTM heat source.'
}
(OUT / 'candidate_geometry_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({k: summary[k] for k in ('source_atoms', 'source_type_counts', 'candidate_atoms', 'candidate_type_counts', 'backbone_type123_coordinates_copied_verbatim', 'candidate_lattice_A', 'candidate_lattice_strain_vs_4p09', 'Ag_mask_occupied_voxels', 'phase_scan', 'potential_status')}, indent=2))
