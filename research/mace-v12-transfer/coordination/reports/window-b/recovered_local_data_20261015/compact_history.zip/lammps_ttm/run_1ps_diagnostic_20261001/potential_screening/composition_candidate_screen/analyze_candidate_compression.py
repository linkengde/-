from pathlib import Path
import csv
import json

import numpy as np
from ase.io import read


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "candidate_compression_comparison.json"
if OUT.exists():
    raise SystemExit(f"Refusing to overwrite existing file: {OUT}")


def forces_by_id(path):
    with path.open() as f:
        return {
            int(r["lammps_id"]): {
                "symbol": r["symbol"],
                "force": np.array([float(r[f"f{x}_eV_A"]) for x in "xyz"]),
            }
            for r in csv.DictReader(f)
        }


def pair_unit(extxyz):
    atoms = read(extxyz)
    ids = atoms.arrays["lammps_id"].astype(int)
    ia, ib = (int(np.flatnonzero(ids == atom_id)[0]) for atom_id in (520183, 520177))
    vector = atoms.positions[ib] - atoms.positions[ia]
    return float(np.linalg.norm(vector)), vector / np.linalg.norm(vector)


configs = [
    {
        "name": "initial",
        "distance_A": 2.2646254409864515,
        "pbe_summary": ROOT / "gpaw_R6" / "summary.json",
        "pbe_forces": ROOT / "gpaw_R6" / "forces.csv",
        "mace_summary": ROOT / "model_summary.csv",
        "mace_forces": ROOT / "mace_forces_R6.csv",
        "extxyz": ROOT / "composition_candidate_c_pair_R6.extxyz",
    },
    {
        "name": "d1p8",
        "distance_A": 1.8,
        "pbe_summary": ROOT / "pbe_pair_d1p8" / "summary.json",
        "pbe_forces": ROOT / "pbe_pair_d1p8" / "forces.csv",
        "mace_summary": ROOT / "candidate_pair_scan_mace" / "mace_summary.csv",
        "mace_forces": ROOT / "candidate_pair_scan_mace" / "pair_d1p8_forces.csv",
        "extxyz": ROOT / "candidate_pair_scan_mace" / "pair_d1p8.extxyz",
    },
    {
        "name": "d1p5",
        "distance_A": 1.5,
        "pbe_summary": ROOT / "pbe_pair_d1p5" / "summary.json",
        "pbe_forces": ROOT / "pbe_pair_d1p5" / "forces.csv",
        "mace_summary": ROOT / "candidate_pair_scan_mace" / "mace_summary.csv",
        "mace_forces": ROOT / "candidate_pair_scan_mace" / "pair_d1p5_forces.csv",
        "extxyz": ROOT / "candidate_pair_scan_mace" / "pair_d1p5.extxyz",
    },
]

def energy_from(summary):
    return float(summary.get("energy_eV", summary.get("GPAW_energy_eV")))


baseline_pbe_energy = energy_from(json.loads(configs[0]["pbe_summary"].read_text()))
baseline_mace_energy = -428.8720158014336
rows = []
for cfg in configs:
    pbe_summary = json.loads(cfg["pbe_summary"].read_text())
    pbe = forces_by_id(cfg["pbe_forces"])
    mace = forces_by_id(cfg["mace_forces"])
    common = sorted(set(pbe) & set(mace))
    if len(common) != 63 or any(pbe[i]["symbol"] != mace[i]["symbol"] for i in common):
        raise SystemExit(f"Atom ID/type mismatch at {cfg['name']}: {len(common)} common IDs")
    dist, unit = pair_unit(cfg["extxyz"])
    delta = np.array([mace[i]["force"] - pbe[i]["force"] for i in common])
    pbe_array = np.array([pbe[i]["force"] for i in common])
    pbe_pair = float(np.dot(pbe[520177]["force"] - pbe[520183]["force"], unit))
    mace_pair = float(np.dot(mace[520177]["force"] - mace[520183]["force"], unit))
    with cfg["mace_summary"].open() as f:
        records = list(csv.DictReader(f))
    record = next(r for r in records if abs(float(r["C_pair_distance_A"]) - cfg["distance_A"]) < 0.01)
    mace_energy = float(record.get("MACE_energy_eV", record.get("energy_eV")))
    rows.append(
        {
            "configuration": cfg["name"],
            "C_pair_distance_A": dist,
            "PBE_energy_eV": energy_from(pbe_summary),
            "MACE_energy_eV": mace_energy,
            "PBE_delta_energy_from_initial_eV": energy_from(pbe_summary) - baseline_pbe_energy,
            "MACE_delta_energy_from_initial_eV": mace_energy - baseline_mace_energy,
            "PBE_pair_separating_force_eV_per_A": pbe_pair,
            "MACE_pair_separating_force_eV_per_A": mace_pair,
            "pair_force_abs_error_eV_per_A": abs(mace_pair - pbe_pair),
            "force_vector_rmse_eV_per_A": float(np.sqrt(np.mean(np.sum(delta**2, axis=1)))),
            "PBE_force_vector_rms_eV_per_A": float(np.sqrt(np.mean(np.sum(pbe_array**2, axis=1)))),
            "normalized_force_vector_rmse": float(
                np.sqrt(np.mean(np.sum(delta**2, axis=1)))
                / np.sqrt(np.mean(np.sum(pbe_array**2, axis=1)))
            ),
        }
    )

OUT.write_text(json.dumps({"configurations": rows}, indent=2) + "\n")
print(json.dumps({"configurations": rows}, indent=2))
