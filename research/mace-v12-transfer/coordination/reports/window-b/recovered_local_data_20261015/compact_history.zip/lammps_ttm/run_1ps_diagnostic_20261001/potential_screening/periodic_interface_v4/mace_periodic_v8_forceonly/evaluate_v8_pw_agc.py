#!/usr/bin/env python3
"""Evaluate v7 on the untouched converged PW-PBE Ag-C secondary cluster."""
from pathlib import Path
import json
import numpy as np
import torch
from ase.io import read
from mace.calculators import MACECalculator

ROOT=Path(__file__).resolve().parent
PROJECT=ROOT.parent
OUT=ROOT/'evaluation_agc_pw_holdout.json'
if OUT.exists(): raise SystemExit(f'Refusing to overwrite {OUT}')
refdir=PROJECT/'pbe_cluster_transfer_pw_20261002_run3_mixer_retry2'
ref=read(refdir/'AgC_cluster_PW_PBE.extxyz')
meta=json.loads((refdir/'summary.json').read_text())
ids=np.asarray(ref.arrays['lammps_id'],int)
symbols=np.asarray(ref.get_chemical_symbols())
marked=np.flatnonzero(np.asarray(ref.arrays['central_pair'],bool))
ag_i=next(i for i in marked if symbols[i]=='Ag')
c_i=next(i for i in marked if symbols[i]=='C')
sep=ref.positions[ag_i]-ref.positions[c_i]
d=float(np.linalg.norm(sep)); u=sep/d
fref=np.asarray(ref.get_forces()); eref=float(ref.get_potential_energy())
basefile=refdir/'mace_transfer_summary.json'
base=json.loads(basefile.read_text()) if basefile.exists() else {'models':{}}
models={k:{x:v for x,v in base.get('models',{}).get(k,{}).items() if x in (
  'force_RMSE_eV_A','force_MAE_eV_A','central_pair_separating_force_eV_A','central_pair_force_error_eV_A','energy_error_meV_atom')}
  for k in ('v5','v6')}
torch.set_default_dtype(torch.float64)
path=ROOT/'models/Ag_Ti_Si_C_MACE_periodic_v8_forceonly.model'
model=torch.load(path,map_location='cpu',weights_only=False).double().eval()
a=ref.copy(); a.calc=MACECalculator(models=[model],device='cpu',default_dtype='float64')
e=float(a.get_potential_energy()); f=np.asarray(a.get_forces()); delta=f-fref
pair=float(np.dot(f[ag_i]-f[c_i],u)); norms=np.linalg.norm(f,axis=1)
imax=int(norms.argmax())
per_element={}
for el in sorted(set(symbols)):
 m=symbols==el
 per_element[el]={'count':int(m.sum()),'force_RMSE_eV_A':float(np.sqrt(np.mean(delta[m]**2))),
                   'force_MAE_eV_A':float(np.mean(np.abs(delta[m])))}
models['v8_forceonly']={'model':str(path),'energy_eV_cell':e,'energy_error_eV_cell':e-eref,
 'energy_error_meV_atom':(e-eref)*1000/len(ref),
 'force_RMSE_eV_A':float(np.sqrt(np.mean(delta**2))),
 'force_MAE_eV_A':float(np.mean(np.abs(delta))),
 'force_vector_max_error_eV_A':float(np.linalg.norm(delta,axis=1).max()),
 'predicted_Fmax_eV_A':float(norms.max()),'predicted_Fmax_source_id':int(ids[imax]),
 'central_pair_separating_force_eV_A':pair,
 'reference_pair_force_eV_A':float(meta['central_pair_separating_force_eV_A']),
 'central_pair_force_error_eV_A':pair-float(meta['central_pair_separating_force_eV_A']),
 'per_element_force_metrics':per_element}
summary={'reference':str(refdir/'AgC_cluster_PW_PBE.extxyz'),
 'reference_method':'PBE plane wave, 500 eV, Gamma, periodic 28 A cell; SCF converged in 60 iterations',
 'atoms':len(ref),'AgC_distance_A':d,'reference_Fmax_eV_A':float(np.linalg.norm(fref,axis=1).max()),
 'reference_pair_separating_force_eV_A':float(meta['central_pair_separating_force_eV_A']),
 'reference_pair_source_ids':{'Ag':int(ids[ag_i]),'C':int(ids[c_i])},
 'untouched_external_holdout':True,'models':models,
 'screen_thresholds':{'force_RMSE_eV_A':0.25,'pair_force_abs_error_eV_A':0.30},
 'v8_forceonly_passes_agc_force_screen':bool(np.sqrt(np.mean(delta**2))<=0.25 and abs(pair-float(meta['central_pair_separating_force_eV_A']))<=0.30),
 'limitations':['This holdout is a 2.203 A Ag-C contact in the secondary local cluster and tests distance interpolation after training on its 2.0 and 2.4 A endpoints; it does not test a new local motif, finite-temperature Ag, or TTM.',
 'LCAO training labels and PW-PBE holdout use different basis/boundary settings.']}
OUT.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
