from pathlib import Path
import sys, torch
root = Path(__file__).resolve().parent
integration = root.parent / 'lammps_mace_integration'
sys.path.insert(0, str(integration))
from mliap_serial_compat import LAMMPS_MLIAP_MACE_SerialCompat
model_path = root/'mace_periodic_v6/models/Ag_Ti_Si_C_MACE_periodic_v6.model'
out = root/'lammps_v6_serial_run0_20261002/mace_v6_mliap_serial_compat.pt'
if out.exists(): raise SystemExit(f'Refusing to overwrite {out}')
model = torch.load(model_path, map_location='cpu', weights_only=False).double().cpu()
model.lammps_mliap = True
wrapper = LAMMPS_MLIAP_MACE_SerialCompat(model, head='Default')
torch.save(wrapper, out)
print('model=', model_path)
print('wrapper=', out)
print('elements=', wrapper.element_types)
print('cutoff_A=', float(model.r_max))
