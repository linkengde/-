Status: ABORTED before SCF completion.
Reason: The companion model-derived Ti3SiC2 bulk cell converged at fixed geometry with a maximum residual atomic force of 1.99 eV/A. This is too large to treat the unrelaxed cell as a physical reference. These interface attempts were stopped; their partial GPAW logs are retained. The next calculations will use a PBE-relaxed substrate.
