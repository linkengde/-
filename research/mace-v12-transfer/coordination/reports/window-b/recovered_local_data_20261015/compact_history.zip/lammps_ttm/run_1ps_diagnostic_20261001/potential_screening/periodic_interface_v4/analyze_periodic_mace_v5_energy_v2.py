from pathlib import Path
import json
import numpy as np

root = Path(__file__).resolve().parent
run = root / 'mace_periodic_v5'
eval_dir = run / 'evaluation_retry2'
records = json.loads((eval_dir / 'summary.json').read_text())['records']
manifest = json.loads((run / 'dataset_manifest.json').read_text())
formula_by_name = {c['config_type']: c['composition'] for c in manifest['cases']}
model = 'finetuned_v5'

def formula(name):
    return ''.join(f'{el}{n}' for el, n in sorted(formula_by_name[name].items()))
def cell_error(r):
    return float(r[f'{model}_energy_error_eV_atom'] * r['atoms'])
train = [r for r in records if r['split'] == 'train']
test = [r for r in records if r['split'] == 'test']
by_formula = {}
for r in train:
    by_formula.setdefault(formula(r['config_type']), []).append(cell_error(r))
train_bias = {f: float(np.mean(e)) for f, e in by_formula.items()}
corrected = []
for r in test:
    f = formula(r['config_type'])
    err = cell_error(r)
    corrected.append({'config_type': r['config_type'], 'formula': f,
      'train_structures_for_bias': len(by_formula[f]), 'train_only_mean_bias_eV_cell': train_bias[f],
      'raw_test_error_eV_cell': err, 'raw_test_error_eV_atom': r[f'{model}_energy_error_eV_atom'],
      'offset_corrected_error_eV_cell': err-train_bias[f],
      'offset_corrected_error_eV_atom': (err-train_bias[f])/r['atoms']})

def get(name):
    return next(r for r in records if r['config_type'] == name)
profiles=[]
for contact in ('Si','C'):
    for a_name,b_name,label in [(f'{contact}_gap_2p4',f'{contact}_gap_2p3','valid_short'),
                                (f'{contact}_gap_2p8',f'{contact}_gap_2p9','test_long')]:
        a,b=get(a_name),get(b_name)
        delta_ref=b['reference_energy_eV_cell']-a['reference_energy_eV_cell']
        delta_pred=delta_ref + cell_error(b)-cell_error(a)
        profiles.append({'contact':contact,'comparison':label,'from':a_name,'to':b_name,
          'DFT_delta_E_eV_cell':delta_ref,'MACE_delta_E_eV_cell':delta_pred,
          'delta_E_error_eV_cell':delta_pred-delta_ref,
          'delta_E_error_eV_atom':(delta_pred-delta_ref)/b['atoms']})
result={
 'purpose':'Training-only formula-class energy-offset diagnostic; offsets are constants and do not change forces.',
 'train_formula_bias_eV_cell':train_bias,
 'raw_test_energy_MAE_eV_atom':float(np.mean([abs(r[f'{model}_energy_error_eV_atom']) for r in test])),
 'formula_offset_corrected_test_energy_MAE_eV_atom':float(np.mean([abs(r['offset_corrected_error_eV_atom']) for r in corrected])),
 'offset_corrected_test_records':corrected,
 'heldout_relative_energy_profiles':profiles,
 'limitations':['The offset is fit from train structures sharing each formula; it is diagnostic and is not applied to the MACE model.',
                'The test set has only two configurations (one Si and one C termination).',
                'All structures are small, coherent, unrelaxed screening cells.']}
(eval_dir/'energy_profile_analysis_v2.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('raw_test_energy_MAE_eV_atom','formula_offset_corrected_test_energy_MAE_eV_atom','train_formula_bias_eV_cell','offset_corrected_test_records','heldout_relative_energy_profiles')},indent=2))
