from pathlib import Path
import csv
import json

import numpy as np
from ase.io import read


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "candidate_force_error_analysis.json"
if OUT.exists():
    raise SystemExit(f"Refusing to overwrite existing file: {OUT}")

def load(path, force_keys):
    result = {}
    with path.open() as f:
        for row in csv.DictReader(f):
            atom_id = int(row["lammps_id"])
            result[atom_id] = {
                "symbol": row["symbol"],
                "force": np.array([float(row[key]) for key in force_keys]),
            }
    return result

pbe = load(ROOT / "gpaw_R6" / "forces.csv", [f"f{x}_eV_A" for x in "xyz"])
models = {
    "MACE": load(ROOT / "mace_forces_R6.csv", [f"f{x}_eV_A" for x in "xyz"]),
    "CHGNet": load(ROOT / "chgnet_forces_R6.csv", [f"f{x}_eV_A" for x in "xyz"]),
}
common = sorted(pbe)
if len(common) != 63:
    raise SystemExit(f"Expected 63 PBE atoms, found {len(common)}")

atoms = read(ROOT / "composition_candidate_c_pair_R6.extxyz")
ids = atoms.arrays["lammps_id"].astype(int)
ia, ib = (int(np.flatnonzero(ids == atom_id)[0]) for atom_id in (520183, 520177))
vector = atoms.positions[ib] - atoms.positions[ia]
unit = vector / np.linalg.norm(vector)
pbe_pair = float(np.dot(pbe[520177]["force"] - pbe[520183]["force"], unit))
summary = []
by_element = []

for name, model in models.items():
    if any(pbe[i]["symbol"] != model[i]["symbol"] for i in common):
        raise SystemExit(f"Element mapping mismatch for {name}")
    delta = np.array([model[i]["force"] - pbe[i]["force"] for i in common])
    pbe_vectors = np.array([pbe[i]["force"] for i in common])
    pair_force = float(np.dot(model[520177]["force"] - model[520183]["force"], unit))
    summary.append(
        {
            "model": name,
            "atoms": len(common),
            "PBE_pair_separating_force_eV_per_A": pbe_pair,
            "model_pair_separating_force_eV_per_A": pair_force,
            "pair_force_abs_error_eV_per_A": abs(pair_force - pbe_pair),
            "force_vector_rmse_eV_per_A": float(np.sqrt(np.mean(np.sum(delta**2, axis=1)))),
            "force_vector_mae_eV_per_A": float(np.mean(np.linalg.norm(delta, axis=1))),
            "force_vector_max_error_eV_per_A": float(np.linalg.norm(delta, axis=1).max()),
            "relative_force_norm_rmse": float(
                np.sqrt(np.mean(np.sum(delta**2, axis=1)))
                / np.sqrt(np.mean(np.sum(pbe_vectors**2, axis=1)))
            ),
        }
    )
    for element in ("Ag", "C", "Si", "Ti"):
        selected = [j for j, atom_id in enumerate(common) if pbe[atom_id]["symbol"] == element]
        d = delta[selected]
        by_element.append(
            {
                "model": name,
                "element": element,
                "atoms": len(selected),
                "force_vector_rmse_eV_per_A": float(np.sqrt(np.mean(np.sum(d**2, axis=1)))),
            }
        )

result = {"summary": summary, "by_element": by_element}
OUT.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
