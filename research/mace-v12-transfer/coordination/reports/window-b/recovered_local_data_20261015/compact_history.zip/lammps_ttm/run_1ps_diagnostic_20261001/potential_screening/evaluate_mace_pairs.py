from pathlib import Path
import csv

import numpy as np
from ase.io import read
from mace.calculators import mace_mp

ROOT = Path(__file__).resolve().parent
MODEL = Path("/workspace/.local/cache/mace/mace-mp-0b3-medium.model")
PAIR_IDS = (520183, 520177)
calculator = mace_mp(model=str(MODEL), device="cpu", default_dtype="float64")
summary = []

for frame in ("step0", "step1000"):
    atoms = read(ROOT / f"c_pair_{frame}_R6.extxyz")
    atoms.calc = calculator
    energy = atoms.get_potential_energy()
    forces = atoms.get_forces()
    ids = atoms.arrays["lammps_id"]
    ia = int(np.flatnonzero(ids == PAIR_IDS[0])[0])
    ib = int(np.flatnonzero(ids == PAIR_IDS[1])[0])
    vec = atoms.positions[ib] - atoms.positions[ia]
    distance = np.linalg.norm(vec)
    separating = float(np.dot(forces[ib] - forces[ia], vec / distance))
    fnorm = np.linalg.norm(forces, axis=1)
    row = {
        "frame": frame,
        "atoms": len(atoms),
        "MACE_model": MODEL.name,
        "MACE_energy_eV": energy,
        "C_pair_distance_A": distance,
        "C_pair_separating_force_eV_per_A": separating,
        "C520183_force_norm_eV_per_A": fnorm[ia],
        "C520177_force_norm_eV_per_A": fnorm[ib],
        "max_force_norm_eV_per_A": fnorm.max(),
        "max_force_lammps_id": int(ids[int(fnorm.argmax())]),
    }
    summary.append(row)
    with (ROOT / f"mace_forces_{frame}.csv").open("w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["lammps_id", "type", "symbol", "x_A", "y_A", "z_A", "fx_eV_A", "fy_eV_A", "fz_eV_A", "force_norm_eV_A"])
        for i, (aid, typ, pos, force, norm) in enumerate(
            zip(ids, atoms.arrays["lammps_type"], atoms.positions, forces, fnorm)
        ):
            writer.writerow([int(aid), int(typ), atoms[i].symbol, *map(float, pos), *map(float, force), float(norm)])

with (ROOT / "mace_pair_summary.csv").open("w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=summary[0].keys())
    writer.writeheader()
    writer.writerows(summary)

for row in summary:
    print(row, flush=True)
