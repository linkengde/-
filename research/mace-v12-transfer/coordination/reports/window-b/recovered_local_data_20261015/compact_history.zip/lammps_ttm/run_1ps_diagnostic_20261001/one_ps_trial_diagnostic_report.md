# 1 ps 试跑诊断（提前停止）

## 结论

没有完成 1 ps。计算从已验证可读的 step 10 TTM restart 继续，最后 thermo 记录到 step 1130；按 `timestep = 0.0001 ps`，记录到约 0.112 ps 的新增运行。发现 Ti3SiC2 骨架内一对 C 原子在前 0.1 ps 内显著靠近，因此停止后续推进。磁盘上最近的完整 checkpoint 是 step 1000（累计 0.100 ps），不是 step 1130。

这是一段 300 K 冷态稳定性试跑：输入没有熔池热源，也不是熔池 checkpoint。它不能证明已形成熔池或熔坑。

## 主要异常

- C 原子 ID 520183 与 C 原子 ID 520177 的最小镜像距离：step 0 为 **2.264658 Å**，step 10 为 **2.259910 Å**，step 1000 为 **1.246880 Å**。距离在约 0.099 ps 内缩短约 45%。step 1000 的 dump 中，ID 520183 合力模为 **23.1725 eV/Å**，是该帧最大合力原子。
- 该局部 pair 的逐帧坐标、距离和力见 [local_pair_evolution.csv](local_pair_evolution.csv)。step 0 和 step 10 数据来自既有 run 0 单帧 dump；step 1000 来自本次运行单帧 dump。
- thermo 中 Fmax 峰值为 **34.6276 eV/Å（step 760）**；step 1000 在 run 分段边界出现两行，前一段结束值为22.9588、后一段起始值为22.2196 eV/Å；step 1130 最后一行是19.5293 eV/Å。step1000 dump 的最大单原子力模为23.1725 eV/Å。两种输出保留各自原始定义；当前输出没有分离保守势力和 TTM 随机力的分量。
- 无热源条件下，Ag 组温度由 step 10 的约 **300.7 K** 升到 step 1000 的约 **729.9 K**，最后一行 step 1130 达约 **799.9 K**；骨架组由约301.8 K升至约374.5 K。这个升温和局部 C–C 压缩需要解释，不能当作稳定或物理正确的结果。
- step 10 总能量约−4,053,419 eV；step 1000 约−4,053,819 eV；step 1130 约−4,053,964 eV。输入包含 NVT thermostat 与 TTM 耦合，不能仅凭总能量变化做闭合判定。
- step 1000 TTM 网格有 13,500 个有限值；网格温度 min/mean/max 约 **237.95 / 315.51 / 410.85 K**。

## 运行状态

- 原子数始终为 **682,587**。日志中没有 LAMMPS `ERROR`、lost atoms 或 NaN/Inf。
- 计算由我在异常出现后手动停止；终止不是 LAMMPS 数值错误。前台信号没有及时停止所有 MPI rank，随后已直接终止 rank 并确认它们不再运行。
- step 1000 checkpoint、原子 dump 和 TTM 网格输出已经写完。后续 step 1130 的 thermo 行没有对应 checkpoint 或 dump。
- 日志只有 restart 处理相关警告：restart 的处理器数从1变为4；hybrid pair style 不在 restart 中保存势信息，势函数由本次输入文件重新加载。

## 使用的模型和限制

- 起点：step 10 restart，SHA256 `48be18946b400d27b309c5f8272a2b01f42d9e673c1bf9e6d5dccfb575e0742f`。
- 体系：682,587 atoms，类型映射 type 1/2/3/4 = Ti/Si/C/Ag；盒子150.1×300×300 Å，周期边界。
- 势：Ag–Ti/Si/C 交叉 Morse 仍是 calibration v0，尚无独立验证。起点已知存在固定层 Ag–Ti **1.000209 Å** 近接触。
- 输入使用 300 K thermostat、dynamic-layer NVE 和 `ttm/thermal`；没有热源。因模型有已知近接触、交叉势未验证，且现在发现骨架局部距离明显塌缩，本次短跑只能作为数值故障筛查。

## 文件

- 本次输入：[run_to_step10000.in](run_to_step10000.in)
- 完整屏幕日志：[screen.lammps](screen.lammps)
- LAMMPS log：[log.lammps](log.lammps)
- step 1000 restart：[checkpoints/step1000.restart](checkpoints/step1000.restart)（SHA256 `2b45de23cc7c8376e2ac3af171c83c191c8b9b6f709a59e133619f943cdf303b`）
- step 1000 原子 dump：[dumps/all.1000.dump](dumps/all.1000.dump)（SHA256 `9d8badba406f55f3a8a271b4fe0af41ace57752b42106c2fb0b533a5439fc846`）
- step 1000 TTM 网格：[dumps/electron_temperature_grid.dat.1000](dumps/electron_temperature_grid.dat.1000)
- 先前 step 0/10 dump：[step0_forces.dump](/workspace/.local/lammps-ttm/overnight_TTM_diagnostic_20261001/stage2_step0/step0_forces.dump)、[step10_forces.dump](/workspace/.local/lammps-ttm/overnight_TTM_diagnostic_20261001/stage2_step10/step10_forces.dump)

**判定：1 ps 未完成；在约0.1 ps处发现局部骨架结构异常，当前候选不应直接继续长跑。根因尚未确认。**

后续只做了静态 `run 0` 力分解，没有继续 MD。该检查显示 Ag–C Morse 交叉项在 step0/10 帧会把 C520183/C520177 的相对力从排斥翻成吸引；详见[根因追查报告](root_cause_analysis.md)和[力分量 CSV](force_component_attribution.csv)。
