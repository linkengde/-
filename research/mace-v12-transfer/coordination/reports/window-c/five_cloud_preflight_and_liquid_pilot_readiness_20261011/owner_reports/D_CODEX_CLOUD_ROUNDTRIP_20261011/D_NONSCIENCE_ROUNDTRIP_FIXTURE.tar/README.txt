Codex Cloud D non-science backup/restore fixture. No simulation data.
