# Ag64 segment checkpoint

Immutable checkpoint in signed global-step segment 2000->3000.
The scientific source identity is preserved as provenance; this bundle's execution code hash is recorded separately.
No EAM potential bytes are included.
